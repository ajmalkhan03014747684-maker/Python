-- Python 3.x backend setup. Paste into Supabase -> SQL Editor -> Run. Safe to run twice.
-- Only the PUBLIC anon key goes in the app. Never put the service_role key anywhere in the app.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  role text not null default 'user' check (role in ('user','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.app_settings (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default now()
);

create table if not exists public.events (
  id bigint generated always as identity primary key,
  user_id uuid default auth.uid() references auth.users(id) on delete set null,
  name text not null check (name ~ '^[a-z_]{1,40}$'),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.app_settings enable row level security;
alter table public.events enable row level security;

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin');
$$;

-- profiles: you can read your own row; admins can read all. Nobody can change a role from the app.
drop policy if exists "read own profile" on public.profiles;
create policy "read own profile" on public.profiles for select using (id = auth.uid() or public.is_admin());

-- app_settings: everyone may read (ad unit ids are public identifiers); only admins may write.
drop policy if exists "read settings" on public.app_settings;
create policy "read settings" on public.app_settings for select using (true);
drop policy if exists "admin insert settings" on public.app_settings;
create policy "admin insert settings" on public.app_settings for insert with check (public.is_admin());
drop policy if exists "admin update settings" on public.app_settings;
create policy "admin update settings" on public.app_settings for update using (public.is_admin()) with check (public.is_admin());

-- events: anyone may add a simple named event (no content); only admins may read them.
drop policy if exists "insert events" on public.events;
create policy "insert events" on public.events for insert with check (user_id is null or user_id = auth.uid());
drop policy if exists "admin read events" on public.events;
create policy "admin read events" on public.events for select using (public.is_admin());

-- Make a profile row for every new sign-up (role is always 'user').
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email) values (new.id, new.email) on conflict do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- Dashboard numbers, admins only.
create or replace function public.admin_stats() returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'admin only' using errcode = '42501'; end if;
  return jsonb_build_object(
    'users', (select count(*) from public.profiles),
    'new_users_7d', (select count(*) from public.profiles where created_at > now() - interval '7 days'),
    'events_7d', (select count(*) from public.events where created_at > now() - interval '7 days'),
    'active_users_7d', (select count(distinct user_id) from public.events where created_at > now() - interval '7 days' and user_id is not null),
    'ad_unlocks_7d', (select count(*) from public.events where name = 'ad_unlock' and created_at > now() - interval '7 days'),
    'app_opens_7d', (select count(*) from public.events where name = 'app_open' and created_at > now() - interval '7 days')
  );
end $$;
revoke all on function public.admin_stats() from public, anon;
grant execute on function public.admin_stats() to authenticated;

-- Existing users (if you ran this late) get a profile too.
insert into public.profiles (id, email) select id, email from auth.users on conflict do nothing;
