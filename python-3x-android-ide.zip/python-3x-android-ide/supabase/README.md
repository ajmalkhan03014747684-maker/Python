# Backend setup (Supabase)

1. Create a free project at supabase.com.
2. SQL Editor -> paste `setup.sql` -> Run.
3. Authentication -> Providers -> Email: keep enabled (turn "Confirm email" on or off as you prefer).
4. Sign up once inside the app, then make yourself admin in the SQL Editor:
   `update public.profiles set role = 'admin' where email = 'you@example.com';`
5. Project Settings -> API: copy **Project URL** and the **anon public** key.
   In GitHub: repo -> Settings -> Secrets and variables -> Actions -> Variables:
   `PY3X_SUPABASE_URL` and `PY3X_SUPABASE_ANON_KEY`. Rebuild.

Never use or share the `service_role` key. The app refuses it, and it is not needed.
