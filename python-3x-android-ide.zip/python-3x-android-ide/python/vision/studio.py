"""Image processing pipeline for the OpenCV Studio screen.

Works on image files inside a project. OpenCV (``cv2``) is imported lazily: if it is not bundled in
the build, every call fails with a clear message instead of pretending to work.
Only operations that need no GUI window are offered (no ``imshow``).
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".bmp", ".webp"}
MAX_PIXELS = 20_000_000  # refuse to load huge images that could exhaust phone memory
MAX_STEPS = 20


class VisionError(ValueError):
    pass


# name -> label, parameters (name -> (default, min, max, step)), description
OPERATIONS: dict[str, dict[str, Any]] = {
    "grayscale": {"label": "Grayscale", "params": {}},
    "blur": {"label": "Gaussian blur", "params": {"size": (5, 1, 51, 2)}},
    "median": {"label": "Median blur", "params": {"size": (5, 3, 31, 2)}},
    "edges": {"label": "Canny edges", "params": {"low": (80, 0, 500, 5), "high": (160, 0, 500, 5)}},
    "threshold": {"label": "Threshold", "params": {"value": (127, 0, 255, 1)}},
    "adaptive": {"label": "Adaptive threshold", "params": {"block": (11, 3, 51, 2), "c": (2, 0, 20, 1)}},
    "invert": {"label": "Invert", "params": {}},
    "equalize": {"label": "Equalize contrast", "params": {}},
    "brightness": {"label": "Brightness / contrast", "params": {"brightness": (0, -100, 100, 5), "contrast": (100, 20, 300, 10)}},
    "sharpen": {"label": "Sharpen", "params": {"amount": (1, 0, 5, 1)}},
    "erode": {"label": "Erode", "params": {"size": (3, 1, 15, 2)}},
    "dilate": {"label": "Dilate", "params": {"size": (3, 1, 15, 2)}},
    "resize": {"label": "Resize (percent)", "params": {"percent": (50, 5, 300, 5)}},
    "rotate": {"label": "Rotate (degrees)", "params": {"angle": (90, -180, 180, 15)}},
    "flip": {"label": "Flip horizontally", "params": {}},
}


def _cv():
    try:
        import cv2  # noqa: PLC0415
        import numpy as np  # noqa: PLC0415
    except ImportError as exc:
        raise VisionError(
            "OpenCV (opencv-python) is not available in this Python. It lives in the Python 3.x Packs app "
            "(Package Manager -> Install) or must be added to py3xPacksPackages and rebuilt."
        ) from exc
    return cv2, np


def _param(op: str, params: dict, name: str) -> int:
    default, lo, hi, _ = OPERATIONS[op]["params"][name]
    raw = params.get(name, default)
    if isinstance(raw, bool) or not isinstance(raw, (int, float)):
        raise VisionError(f"'{name}' must be a number.")
    return int(max(lo, min(hi, raw)))


def _odd(n: int) -> int:
    return n if n % 2 else n + 1


def validate_pipeline(steps: Any) -> list[dict[str, Any]]:
    if not isinstance(steps, list):
        raise VisionError("The pipeline must be a list of steps.")
    if len(steps) > MAX_STEPS:
        raise VisionError(f"At most {MAX_STEPS} steps are allowed.")
    clean = []
    for s in steps:
        if not isinstance(s, dict) or s.get("op") not in OPERATIONS:
            raise VisionError(f"Unknown operation: {s.get('op') if isinstance(s, dict) else s!r}")
        params = s.get("params", {})
        if not isinstance(params, dict):
            raise VisionError("Step parameters must be an object.")
        clean.append({"op": s["op"], "params": {k: _param(s["op"], params, k) for k in OPERATIONS[s["op"]]["params"]}})
    return clean


class VisionStudio:
    def __init__(self, project_root: Path):
        self.root = Path(project_root).resolve()

    # ------------------------------------------------------------- files
    def _image_path(self, rel: str, must_exist: bool = True) -> Path:
        path = (self.root / rel).resolve()
        if not path.is_relative_to(self.root):
            raise VisionError("The image must be inside the project.")
        if path.suffix.lower() not in IMAGE_SUFFIXES:
            raise VisionError("Supported image types: " + ", ".join(sorted(IMAGE_SUFFIXES)))
        if must_exist and not path.is_file():
            raise VisionError("Image not found.")
        return path

    def operations(self) -> list[dict[str, Any]]:
        return [
            {"op": k, "label": v["label"],
             "params": [{"name": n, "default": d, "min": lo, "max": hi, "step": st} for n, (d, lo, hi, st) in v["params"].items()]}
            for k, v in OPERATIONS.items()
        ]

    def info(self, rel: str) -> dict[str, Any]:
        cv2, _ = _cv()
        img = cv2.imread(str(self._image_path(rel)), cv2.IMREAD_UNCHANGED)
        if img is None:
            raise VisionError("Could not read this image.")
        h, w = img.shape[:2]
        return {"width": int(w), "height": int(h), "channels": 1 if img.ndim == 2 else int(img.shape[2])}

    # ----------------------------------------------------------- process
    def process(self, rel: str, steps: Any, out_rel: str) -> dict[str, Any]:
        cv2, np = _cv()
        pipeline = validate_pipeline(steps)
        src, dst = self._image_path(rel), self._image_path(out_rel, must_exist=False)
        img = cv2.imread(str(src), cv2.IMREAD_COLOR)
        if img is None:
            raise VisionError("Could not read this image.")
        if img.shape[0] * img.shape[1] > MAX_PIXELS:
            raise VisionError("This image is too large to process on a phone (limit 20 megapixels).")
        for step in pipeline:
            img = self._apply(cv2, np, img, step["op"], step["params"])
        dst.parent.mkdir(parents=True, exist_ok=True)
        if not cv2.imwrite(str(dst), img):
            raise VisionError("Could not save the result.")
        h, w = img.shape[:2]
        return {"out": str(dst.relative_to(self.root)), "width": int(w), "height": int(h), "steps": len(pipeline)}

    @staticmethod
    def _as_gray(cv2, img):
        return img if img.ndim == 2 else cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    def _apply(self, cv2, np, img, op: str, p: dict[str, int]):
        if op == "grayscale":
            return self._as_gray(cv2, img)
        if op == "blur":
            k = _odd(p["size"])
            return cv2.GaussianBlur(img, (k, k), 0)
        if op == "median":
            return cv2.medianBlur(img, _odd(p["size"]))
        if op == "edges":
            return cv2.Canny(self._as_gray(cv2, img), p["low"], max(p["high"], p["low"]))
        if op == "threshold":
            return cv2.threshold(self._as_gray(cv2, img), p["value"], 255, cv2.THRESH_BINARY)[1]
        if op == "adaptive":
            return cv2.adaptiveThreshold(self._as_gray(cv2, img), 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                         cv2.THRESH_BINARY, _odd(max(3, p["block"])), p["c"])
        if op == "invert":
            return cv2.bitwise_not(img)
        if op == "equalize":
            if img.ndim == 2:
                return cv2.equalizeHist(img)
            ycrcb = cv2.cvtColor(img, cv2.COLOR_BGR2YCrCb)
            ycrcb[:, :, 0] = cv2.equalizeHist(ycrcb[:, :, 0])
            return cv2.cvtColor(ycrcb, cv2.COLOR_YCrCb2BGR)
        if op == "brightness":
            return cv2.convertScaleAbs(img, alpha=p["contrast"] / 100.0, beta=p["brightness"])
        if op == "sharpen":
            a = p["amount"]
            kernel = np.array([[0, -a, 0], [-a, 1 + 4 * a, -a], [0, -a, 0]], dtype=np.float32)
            return cv2.filter2D(img, -1, kernel)
        if op in ("erode", "dilate"):
            kernel = np.ones((p["size"], p["size"]), np.uint8)
            return (cv2.erode if op == "erode" else cv2.dilate)(img, kernel)
        if op == "resize":
            f = p["percent"] / 100.0
            h, w = img.shape[:2]
            return cv2.resize(img, (max(1, int(w * f)), max(1, int(h * f))), interpolation=cv2.INTER_AREA if f < 1 else cv2.INTER_LINEAR)
        if op == "rotate":
            h, w = img.shape[:2]
            m = cv2.getRotationMatrix2D((w / 2, h / 2), p["angle"], 1.0)
            return cv2.warpAffine(img, m, (w, h))
        if op == "flip":
            return cv2.flip(img, 1)
        raise VisionError(f"Unknown operation: {op}")  # unreachable: validated earlier
