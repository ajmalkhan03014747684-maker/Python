"""Package visibility and honest compatibility information.

Android cannot run ``pip install`` for arbitrary packages at runtime: native wheels must be built for
Android and bundled into the APK at build time (Chaquopy). This module therefore never "installs"
anything. It reports (a) what is importable right now and (b) what the catalog knows about a name.

Catalog statuses
  stdlib       ships with Python itself
  bundled      verified present in this build (importable right now)
  in-packs     not in this app, but present in the companion "Python 3.x Packs" app (Python 3.10)
  packs        needs Python 3.10 wheels: can only be used by installing the companion Packs app
  buildable    listed in the Chaquopy package repository: can be bundled by adding it to the Gradle
               ``py3xPackages`` property and rebuilding. Not guaranteed for every version/ABI.
  pure-python  pure Python code usually works if bundled, but is not checked by this app
  unsupported  known not to work on Android
  unknown      not in the catalog; nothing is claimed
"""

from __future__ import annotations

import importlib.metadata as md
import importlib.util
import re
import sys
from typing import Any

# name -> (status, note). Names are normalised (lowercase, '-' and '_' equal).
CATALOG: dict[str, tuple[str, str]] = {
    # Native packages with a Python 3.12 Android wheel (this app's Python): bundled at build time.
    "numpy": ("buildable", "Chaquopy wheel for Python 3.12 (1.26.x)."),
    "pandas": ("buildable", "Chaquopy wheel for Python 3.12 (2.1.x)."),
    "matplotlib": ("buildable", "Chaquopy wheel (3.8.x). No desktop window: use savefig() with the Agg backend."),
    "pillow": ("buildable", "Chaquopy wheel for Python 3.12."),
    "lxml": ("buildable", "Chaquopy wheel for Python 3.12."),
    "pyyaml": ("buildable", "Chaquopy wheel for Python 3.12."),
    # Only built for Python 3.10: provided by the companion Packs app.
    "scipy": ("packs", "Android wheel exists only for Python 3.10 (1.8.x): provided by the Packs app."),
    "scikit-learn": ("packs", "Android wheel exists only for Python 3.10 (1.3.x): provided by the Packs app."),
    "scikit-image": ("packs", "Android wheel exists only for Python 3.10 (0.18.x): provided by the Packs app."),
    "opencv-python": ("packs", "Android wheel exists only for Python 3.10 (full build, no GUI windows: use imread/imwrite): provided by the Packs app."),
    "cryptography": ("packs", "Android wheel exists only for Python 3.10 (3.4.x, an old release): provided by the Packs app."),
    "statsmodels": ("packs", "Android wheel exists only for Python 3.10: provided by the Packs app."),
    # Pure Python: no native code, so they work when bundled. Network ones also need the INTERNET permission.
    "sympy": ("pure-python", "Pure Python."),
    "mpmath": ("pure-python", "Pure Python."),
    "beautifulsoup4": ("pure-python", "Pure Python."),
    "jinja2": ("pure-python", "Pure Python."),
    "rich": ("pure-python", "Pure Python."),
    "tqdm": ("pure-python", "Pure Python."),
    "click": ("pure-python", "Pure Python."),
    "requests": ("pure-python", "Pure Python. Needs the INTERNET permission, which this build does not request."),
    "flask": ("pure-python", "Pure Python. Needs networking permission to be useful."),
    # Known not to work with this app.
    "torch": ("unsupported", "The Chaquopy repository only has Python 3.8 wheels (very old); not usable with the Python 3.12 or 3.10 apps."),
    "tensorflow": ("unsupported", "The Chaquopy repository only has Python 3.8 wheels (TensorFlow 2.1); not usable with these apps."),
    "h5py": ("unsupported", "No Python 3.10 or 3.12 wheel in the Chaquopy repository."),
    "pygame": ("unsupported", "No Android wheel in the Chaquopy repository; Pygame Studio is therefore not available."),
    "opencv-python-headless": ("unsupported", "Not in the Chaquopy repository; use 'opencv-python' instead."),
    "tkinter": ("unsupported", "No desktop GUI toolkit on Android."),
    "pyqt5": ("unsupported", "No desktop GUI toolkit on Android."),
    "kivy": ("unsupported", "Needs its own Android toolchain; not usable inside this app."),
}


def normalise(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name.strip().lower())


class PackageCatalog:
    def installed(self) -> list[dict[str, str]]:
        seen: dict[str, str] = {}
        for dist in md.distributions():
            name = dist.metadata["Name"] if dist.metadata else None
            if name:
                seen[normalise(name)] = dist.version or ""
        return [{"name": n, "version": v} for n, v in sorted(seen.items())]

    def check(self, name: str, packs: list[dict[str, str]] | None = None) -> dict[str, Any]:
        """``packs`` is the package list reported by the companion Packs app, if it is installed."""
        key = normalise(name)
        if not key or not re.fullmatch(r"[a-z0-9][a-z0-9-]*", key):
            raise ValueError("Enter a package name such as numpy.")
        module = key.replace("-", "_")
        installed = {p["name"]: p["version"] for p in self.installed()}
        importable = key in sys.stdlib_module_names or module in sys.stdlib_module_names
        if importable:
            return {"name": key, "status": "stdlib", "version": sys.version.split()[0],
                    "note": "Part of Python's standard library.", "action": ""}
        if key in installed:
            return {"name": key, "status": "bundled", "version": installed[key],
                    "note": "Bundled in this build.", "action": ""}
        packs_installed = {normalise(p["name"]): p.get("version", "") for p in (packs or [])}
        if key in packs_installed:
            return {"name": key, "status": "in-packs", "version": packs_installed[key],
                    "note": "Available in the Python 3.x Packs app (Python 3.10). Use Run with Packs in the editor.",
                    "action": ""}
        # Not installed: report what is known, without claiming it works.
        status, note = CATALOG.get(key, ("unknown", "Not in the compatibility catalog. Nothing is claimed about it."))
        if status == "bundled":  # catalog says bundled but it is not here -> not true for this build
            status = "buildable"
        action = ""
        if status == "packs":
            action = "Install the Python 3.x Packs companion app to use it."
        if status in ("buildable", "pure-python"):
            action = f'Add "{key}" to the py3xPackages Gradle property and rebuild the app.'
        return {"name": key, "status": status, "version": "", "note": note, "action": action}

    def search(self, query: str, packs: list[dict[str, str]] | None = None) -> list[dict[str, Any]]:
        q = normalise(query)
        names = sorted(n for n in CATALOG if q in n)
        return [self.check(n, packs) for n in names]

    def catalog(self, packs: list[dict[str, str]] | None = None) -> list[dict[str, Any]]:
        return [self.check(n, packs) for n in sorted(CATALOG)]
