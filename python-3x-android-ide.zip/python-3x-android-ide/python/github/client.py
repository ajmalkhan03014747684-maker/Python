"""Minimal GitHub REST client (api.github.com only). The token is passed per call and never stored here."""

from __future__ import annotations

import base64
import json
import re
from typing import Any

from netutil import HttpClient, NetError, Response

API = "https://api.github.com"
HOSTS = {"api.github.com", "codeload.github.com"}
_NAME = re.compile(r"^[A-Za-z0-9_.-]{1,100}$")
_BRANCH = re.compile(r"^[A-Za-z0-9._/-]{1,100}$")


class GitHubError(ValueError):
    pass


def check_name(value: str, what: str) -> str:
    value = (value or "").strip()
    if not _NAME.match(value) or value in {".", ".."}:
        raise GitHubError(f"Invalid {what}.")
    return value


def check_branch(value: str) -> str:
    value = (value or "").strip()
    if not _BRANCH.match(value) or ".." in value or value.startswith(("/", "-")) or value.endswith(("/", ".lock")) or "//" in value:
        raise GitHubError("Invalid branch name.")
    return value


class GitHubClient:
    def __init__(self, token: str, http: HttpClient | None = None):
        token = (token or "").strip()
        if not token:
            raise GitHubError("Add your GitHub token first (Settings -> GitHub).")
        if any(c.isspace() for c in token):
            raise GitHubError("The token must not contain spaces.")
        self._token = token
        self.http = http or HttpClient(HOSTS)

    # ----------------------------------------------------------------- core
    def _headers(self, json_body: bool = False) -> dict:
        h = {
            "Authorization": f"Bearer {self._token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": "Python-3x-IDE",
        }
        if json_body:
            h["Content-Type"] = "application/json"
        return h

    @staticmethod
    def _fail(resp: Response) -> GitHubError:
        try:
            message = json.loads(resp.body or b"{}").get("message", "")
        except (ValueError, AttributeError):
            message = ""
        if resp.status == 401:
            return GitHubError("GitHub rejected the token. Check that it is correct and has not expired.")
        if resp.status == 403:
            return GitHubError(f"GitHub refused the request: {message or 'permission denied or rate limit reached'}.")
        if resp.status == 404:
            return GitHubError("Not found. Check the repository name and that your token can access it.")
        if resp.status in (409, 422):
            return GitHubError(f"GitHub could not apply that: {message or 'conflict'}.")
        return GitHubError(f"GitHub error {resp.status}: {message or 'unexpected response'}.")

    def call(self, method: str, path: str, payload: Any = None) -> Any:
        body = json.dumps(payload).encode() if payload is not None else None
        resp = self.http.request(method, API + path, self._headers(payload is not None), body)
        if resp.status not in (200, 201):
            raise self._fail(resp)
        try:
            return json.loads(resp.body or b"null")
        except ValueError as exc:
            raise GitHubError("GitHub sent an unreadable answer.") from exc

    # ------------------------------------------------------------- endpoints
    def user(self) -> dict:
        u = self.call("GET", "/user")
        return {"login": u.get("login", ""), "name": u.get("name") or ""}

    def repos(self, limit: int = 100) -> list[dict]:
        rows = self.call("GET", f"/user/repos?per_page={min(max(limit, 1), 100)}&sort=pushed&affiliation=owner,collaborator")
        return [
            {"owner": r["owner"]["login"], "name": r["name"], "private": bool(r.get("private")),
             "default_branch": r.get("default_branch", "main"), "description": r.get("description") or ""}
            for r in rows
        ]

    def default_branch(self, owner: str, repo: str) -> str:
        return self.call("GET", f"/repos/{owner}/{repo}")["default_branch"]

    def branch_head(self, owner: str, repo: str, branch: str) -> str:
        return self.call("GET", f"/repos/{owner}/{repo}/git/ref/heads/{branch}")["object"]["sha"]

    def commit_tree(self, owner: str, repo: str, commit: str) -> str:
        return self.call("GET", f"/repos/{owner}/{repo}/git/commits/{commit}")["tree"]["sha"]

    def zipball(self, owner: str, repo: str, ref: str) -> bytes:
        resp = self.http.request("GET", f"{API}/repos/{owner}/{repo}/zipball/{ref}", self._headers(), None, timeout=120)
        if resp.status != 200:
            raise self._fail(resp)
        return resp.body

    def create_blob(self, owner: str, repo: str, data: bytes) -> str:
        r = self.call("POST", f"/repos/{owner}/{repo}/git/blobs", {"content": base64.b64encode(data).decode(), "encoding": "base64"})
        return r["sha"]

    def create_tree(self, owner: str, repo: str, base_tree: str, entries: list[dict]) -> str:
        return self.call("POST", f"/repos/{owner}/{repo}/git/trees", {"base_tree": base_tree, "tree": entries})["sha"]

    def create_commit(self, owner: str, repo: str, message: str, tree: str, parent: str) -> str:
        return self.call("POST", f"/repos/{owner}/{repo}/git/commits", {"message": message, "tree": tree, "parents": [parent]})["sha"]

    def update_ref(self, owner: str, repo: str, branch: str, sha: str) -> None:
        self.call("PATCH", f"/repos/{owner}/{repo}/git/refs/heads/{branch}", {"sha": sha, "force": False})

    def create_branch(self, owner: str, repo: str, branch: str, sha: str) -> None:
        self.call("POST", f"/repos/{owner}/{repo}/git/refs", {"ref": f"refs/heads/{branch}", "sha": sha})


__all__ = ["GitHubClient", "GitHubError", "NetError", "check_branch", "check_name"]
