"""GitHub integration (REST over HTTPS, token supplied per call)."""

from .client import GitHubClient, GitHubError
from .sync import GitHubSync

__all__ = ["GitHubClient", "GitHubError", "GitHubSync"]
