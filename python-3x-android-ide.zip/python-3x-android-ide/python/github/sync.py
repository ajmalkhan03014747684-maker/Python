"""Clone / status / push / pull between a project and a GitHub repository.

No merging: push refuses when the branch moved on GitHub, pull refuses when the project has local changes.
Change detection is exact and offline: files are compared by git blob SHA-1.
"""

from __future__ import annotations

import hashlib
import io
import json
import zipfile
from pathlib import Path, PurePosixPath

from projects.paths import HIDDEN_DIRS, PathError, resolve_inside

from .client import GitHubClient, GitHubError, check_branch, check_name

MAX_FILE_BYTES = 5 * 1024 * 1024
MAX_TOTAL_BYTES = 50 * 1024 * 1024
MAX_FILES = 3000


def blob_sha(data: bytes) -> str:
    return hashlib.sha1(b"blob %d\0" % len(data) + data).hexdigest()  # noqa: S324 - git object id, not security


class GitHubSync:
    def __init__(self, projects, autosave, data_dir: str | Path):
        self.projects = projects
        self.autosave = autosave
        self.links_dir = Path(data_dir) / "github_links"
        self.links_dir.mkdir(parents=True, exist_ok=True)

    # ----------------------------------------------------------------- links
    def _link_path(self, project_id: int) -> Path:
        return self.links_dir / f"{int(project_id)}.json"

    def link(self, project_id: int) -> dict | None:
        p = self._link_path(project_id)
        return json.loads(p.read_text()) if p.exists() else None

    def _save_link(self, project_id: int, link: dict) -> None:
        self._link_path(project_id).write_text(json.dumps(link))

    def unlink(self, project_id: int) -> None:
        self._link_path(project_id).unlink(missing_ok=True)

    def _need_link(self, project_id: int) -> dict:
        link = self.link(project_id)
        if not link:
            raise GitHubError("This project is not linked to a GitHub repository. Clone one first.")
        return link

    # -------------------------------------------------------------- snapshot
    def _snapshot(self, project_id: int) -> tuple[dict[str, str], dict[str, bytes], list[str]]:
        """Returns (rel -> blob sha, rel -> bytes, ignored too-large files)."""
        root = self.projects.project_dir(project_id)
        shas: dict[str, str] = {}
        data: dict[str, bytes] = {}
        ignored: list[str] = []
        total = 0
        for path in sorted(root.rglob("*")):
            rel = path.relative_to(root)
            if any(part in HIDDEN_DIRS for part in rel.parts) or path.is_symlink() or not path.is_file():
                continue
            if path.stat().st_size > MAX_FILE_BYTES:
                ignored.append(rel.as_posix())
                continue
            content = path.read_bytes()
            total += len(content)
            if total > MAX_TOTAL_BYTES or len(shas) >= MAX_FILES:
                raise GitHubError("The project is too large to sync (limit 50 MB or 3000 files).")
            shas[rel.as_posix()] = blob_sha(content)
            data[rel.as_posix()] = content
        return shas, data, ignored

    @staticmethod
    def _diff(base: dict[str, str], now: dict[str, str]) -> dict[str, list[str]]:
        return {
            "added": sorted(p for p in now if p not in base),
            "modified": sorted(p for p in now if p in base and base[p] != now[p]),
            "deleted": sorted(p for p in base if p not in now),
        }

    # ---------------------------------------------------------------- status
    def status(self, project_id: int) -> dict:
        link = self.link(project_id)
        if not link:
            return {"linked": False}
        self.autosave.commit_all_drafts(project_id, "github-status")
        shas, _, ignored = self._snapshot(project_id)
        diff = self._diff(link["files"], shas)
        return {
            "linked": True, "owner": link["owner"], "repo": link["repo"], "branch": link["branch"],
            "commit": link["commit"][:7], "ignored": ignored, **diff,
            "clean": not any(diff.values()),
        }

    # ----------------------------------------------------------------- clone
    @staticmethod
    def _remote_files(zip_bytes: bytes) -> dict[str, bytes]:
        try:
            zf = zipfile.ZipFile(io.BytesIO(zip_bytes))
        except zipfile.BadZipFile as exc:
            raise GitHubError("GitHub sent a damaged archive.") from exc
        out: dict[str, bytes] = {}
        total = 0
        with zf:
            infos = [i for i in zf.infolist() if not i.is_dir()]
            if len(infos) > MAX_FILES * 2:
                raise GitHubError("The repository has too many files for this app.")
            for info in infos:
                parts = PurePosixPath(info.filename.replace("\\", "/")).parts[1:]  # drop "owner-repo-sha/"
                if not parts or ".." in parts or any(p in HIDDEN_DIRS for p in parts) or info.filename.startswith("/"):
                    continue
                if (info.external_attr >> 28) == 0xA:  # symlink
                    continue
                if info.file_size > MAX_FILE_BYTES:
                    continue
                total += info.file_size
                if total > MAX_TOTAL_BYTES:
                    raise GitHubError("The repository is too large for this app (limit 50 MB).")
                out["/".join(parts)] = zf.read(info)
        return out

    def clone(self, gh: GitHubClient, owner: str, repo: str, branch: str | None, name: str | None) -> dict:
        owner, repo = check_name(owner, "owner"), check_name(repo, "repository")
        branch = check_branch(branch) if branch else gh.default_branch(owner, repo)
        head = gh.branch_head(owner, repo, branch)
        files = self._remote_files(gh.zipball(owner, repo, head))
        if not files:
            raise GitHubError("The repository has no files this app can open.")
        project = self.projects.create_project(name or repo, template=False)
        directory = self.projects.project_dir(project["id"])
        try:
            for rel, content in files.items():
                target = resolve_inside(directory, rel)
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(content)
        except PathError as exc:
            self.projects.delete_project(project["id"])
            self.projects.purge_project(project["id"])
            raise GitHubError(f"The repository contains an unsafe path: {exc}") from exc
        main = "main.py" if (directory / "main.py").exists() else self.projects._first_py(directory)
        if main:
            self.projects.set_main_file(project["id"], main)
        self._save_link(project["id"], {
            "owner": owner, "repo": repo, "branch": branch, "commit": head,
            "files": {rel: blob_sha(c) for rel, c in files.items()},
        })
        return self.projects.get_project(project["id"])

    # ------------------------------------------------------------------ push
    def push(self, gh: GitHubClient, project_id: int, message: str, new_branch: str | None = None) -> dict:
        link = self._need_link(project_id)
        message = (message or "").strip()
        if not message:
            raise GitHubError("Write a commit message.")
        if len(message) > 2000:
            raise GitHubError("The commit message is too long.")
        self.autosave.commit_all_drafts(project_id, "github-push")
        shas, data, _ = self._snapshot(project_id)
        diff = self._diff(link["files"], shas)
        if not any(diff.values()):
            raise GitHubError("Nothing to push: no files changed since the last pull or push.")

        owner, repo, branch, base = link["owner"], link["repo"], link["branch"], link["commit"]
        if new_branch:
            new_branch = check_branch(new_branch)
            if new_branch == branch:
                raise GitHubError("Choose a different branch name.")
            gh.create_branch(owner, repo, new_branch, base)
            branch = new_branch
        elif gh.branch_head(owner, repo, branch) != base:
            raise GitHubError(
                "The branch has new commits on GitHub. This app cannot merge: push to a new branch instead, or clone the repository again."
            )

        entries = []
        for rel in diff["added"] + diff["modified"]:
            entries.append({"path": rel, "mode": "100644", "type": "blob", "sha": gh.create_blob(owner, repo, data[rel])})
        for rel in diff["deleted"]:
            entries.append({"path": rel, "mode": "100644", "type": "blob", "sha": None})
        tree = gh.create_tree(owner, repo, gh.commit_tree(owner, repo, base), entries)
        commit = gh.create_commit(owner, repo, message, tree, base)
        gh.update_ref(owner, repo, branch, commit)
        link.update(branch=branch, commit=commit, files=shas)
        self._save_link(project_id, link)
        return {"commit": commit[:7], "branch": branch, **{k: len(v) for k, v in diff.items()}}

    # ------------------------------------------------------------------ pull
    def pull(self, gh: GitHubClient, project_id: int) -> dict:
        link = self._need_link(project_id)
        self.autosave.commit_all_drafts(project_id, "github-pull")
        shas, _, _ = self._snapshot(project_id)
        if any(self._diff(link["files"], shas).values()):
            raise GitHubError("This project has local changes. Push them to a new branch first; this app cannot merge.")
        owner, repo, branch = link["owner"], link["repo"], link["branch"]
        head = gh.branch_head(owner, repo, branch)
        if head == link["commit"]:
            return {"updated": 0, "removed": 0, "commit": head[:7]}
        files = self._remote_files(gh.zipball(owner, repo, head))
        directory = self.projects.project_dir(project_id)
        updated = 0
        for rel, content in files.items():
            if link["files"].get(rel) != blob_sha(content):
                target = resolve_inside(directory, rel)
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(content)
                updated += 1
        removed = 0
        for rel in link["files"]:
            if rel not in files:
                try:
                    self.projects.delete(project_id, rel)  # soft delete: recoverable from the trash
                    removed += 1
                except PathError:
                    pass
        link.update(commit=head, files={rel: blob_sha(c) for rel, c in files.items()})
        self._save_link(project_id, link)
        return {"updated": updated, "removed": removed, "commit": head[:7]}
