"""Local admin gate and ad configuration.

Honest scope: this app is offline-first, so the admin gate here is a *local* gate protecting the
admin panel on this device. Only a salted PBKDF2 hash of the password is stored (never the
password itself). Server-side admin auth (Supabase roles + RLS) arrives with the backend milestone.
Anyone who clears the app's data resets the password to the default, which is expected for a
local-only gate.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import re
import re
import secrets
import time
from typing import Any, Callable

ITERATIONS = 200_000
# Salted PBKDF2-HMAC-SHA256 of the initial admin password. Change it from the admin panel.
DEFAULT_SALT = "b3a1f09c4d7e52a86f10c2e95d3b7a41"
DEFAULT_HASH = "95c3e1555a07f49d8b4206dc095a5f5aabfae865514128b1e2312ada07ee8688"

SESSION_SECONDS = 15 * 60
MAX_FAILS_BEFORE_LOCK = 5
MIN_PASSWORD_LENGTH = 8

DEFAULT_ADS_CONFIG: dict[str, Any] = {
    "ads_enabled": False,  # master switch; coding never depends on ads
    "provider": "none",  # none | admob | unity
    "banner_enabled": True,
    "rewarded_enabled": True,
    "banner_unit_id": "",
    "rewarded_unit_id": "",
    "rewarded_unlock_minutes": 60,
    "admob_app_id": "",  # informational at runtime: Google reads the app id from the manifest at build time
    "unity_game_id": "",
    "unity_placement_id": "",
    "unity_test_mode": False,
}
_PROVIDERS = {"none", "admob", "unity"}
_ADMOB_APP = re.compile(r"^ca-app-pub-\d{16}~\d{10}$")
_ADMOB_UNIT = re.compile(r"^ca-app-pub-\d{16}/\d{10}$")
_UNITY_GAME = re.compile(r"^\d{5,12}$")
_UNITY_PLACEMENT = re.compile(r"^[A-Za-z0-9_.-]{1,64}$")


class AdminError(ValueError):
    pass


def _hash(password: str, salt_hex: str, iterations: int = ITERATIONS) -> str:
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt_hex), iterations).hex()


class AdminService:
    def __init__(
        self,
        db,
        clock: Callable[[], float] = time.time,
        default_salt: str = DEFAULT_SALT,
        default_hash: str = DEFAULT_HASH,
        iterations: int = ITERATIONS,
    ):
        self.db = db
        self._clock = clock
        self._default = (default_salt, default_hash)
        self._iterations = iterations
        self._sessions: dict[str, float] = {}

    # ------------------------------------------------------------ password
    def _credentials(self) -> tuple[str, str, int]:
        raw = self.db.get_setting("admin.credentials")
        if raw:
            c = json.loads(raw)
            return c["salt"], c["hash"], int(c["iterations"])
        return self._default[0], self._default[1], self._iterations

    def _check(self, password: str) -> bool:
        salt, expected, iters = self._credentials()
        return hmac.compare_digest(_hash(password, salt, iters), expected)

    def lock_remaining(self) -> int:
        until = float(self.db.get_setting("admin.locked_until", "0") or 0)
        return max(0, int(until - self._clock() + 0.999))

    def login(self, password: str) -> str:
        wait = self.lock_remaining()
        if wait:
            raise AdminError(f"Too many attempts. Try again in {wait} seconds.")
        if self._check(password or ""):
            self.db.set_setting("admin.fails", "0")
            token = secrets.token_urlsafe(24)
            self._sessions[token] = self._clock() + SESSION_SECONDS
            return token
        fails = int(self.db.get_setting("admin.fails", "0") or 0) + 1
        self.db.set_setting("admin.fails", str(fails))
        if fails >= MAX_FAILS_BEFORE_LOCK:
            # 30s, 60s, 120s ... capped at 15 minutes.
            step = fails - MAX_FAILS_BEFORE_LOCK
            self.db.set_setting("admin.locked_until", str(self._clock() + min(900, 30 * (2**step))))
            raise AdminError("Incorrect password. Admin access is temporarily locked.")
        raise AdminError(f"Incorrect password. {MAX_FAILS_BEFORE_LOCK - fails} attempts left before a lock-out.")

    def require(self, token: str | None) -> None:
        until = self._sessions.get(token or "")
        if until is None or until < self._clock():
            self._sessions.pop(token or "", None)
            raise AdminError("Admin session expired. Please sign in again.")
        self._sessions[token] = self._clock() + SESSION_SECONDS  # sliding expiry

    def logout(self, token: str | None) -> None:
        self._sessions.pop(token or "", None)

    def change_password(self, token: str, current: str, new: str) -> None:
        self.require(token)
        if not self._check(current or ""):
            raise AdminError("Current password is incorrect.")
        if len(new or "") < MIN_PASSWORD_LENGTH:
            raise AdminError(f"New password must be at least {MIN_PASSWORD_LENGTH} characters.")
        if new == current:
            raise AdminError("New password must be different from the current one.")
        salt = secrets.token_hex(16)
        self.db.set_setting(
            "admin.credentials",
            json.dumps({"salt": salt, "hash": _hash(new, salt, self._iterations), "iterations": self._iterations}),
        )
        self._sessions.clear()  # everyone must sign in again

    # ----------------------------------------------------------------- ads
    def get_ads_config(self) -> dict[str, Any]:
        cfg = dict(DEFAULT_ADS_CONFIG)
        raw = self.db.get_setting("ads.config")
        if raw:
            cfg.update({k: v for k, v in json.loads(raw).items() if k in DEFAULT_ADS_CONFIG})
        return cfg

    def set_ads_config(self, token: str, updates: dict[str, Any]) -> dict[str, Any]:
        self.require(token)
        return self._apply(updates)

    def apply_remote_config(self, remote: dict[str, Any]) -> dict[str, Any]:
        """Apply the ads config published by the backend. Unknown keys are ignored; bad values rejected."""
        return self._apply({k: v for k, v in remote.items() if k in DEFAULT_ADS_CONFIG})

    def _apply(self, updates: dict[str, Any]) -> dict[str, Any]:
        cfg = self.get_ads_config()
        for key, value in updates.items():
            if key not in DEFAULT_ADS_CONFIG:
                raise AdminError(f"Unknown ad setting '{key}'.")
            default = DEFAULT_ADS_CONFIG[key]
            if isinstance(default, bool) != isinstance(value, bool) or (
                not isinstance(default, bool) and type(value) is not type(default)
            ):
                raise AdminError(f"Wrong type for '{key}'.")
            cfg[key] = value
        if cfg["provider"] not in _PROVIDERS:
            raise AdminError("Provider must be none, admob or unity.")
        if not 5 <= cfg["rewarded_unlock_minutes"] <= 1440:
            raise AdminError("Unlock time must be between 5 and 1440 minutes.")
        for key in ("banner_unit_id", "rewarded_unit_id"):
            v = cfg[key].strip()
            if v and not _ADMOB_UNIT.match(v):
                raise AdminError("An AdMob ad unit ID looks like ca-app-pub-1234567890123456/1234567890.")
            cfg[key] = v
        for key, rx, hint in (
            ("admob_app_id", _ADMOB_APP, "An AdMob app ID looks like ca-app-pub-1234567890123456~1234567890."),
            ("unity_game_id", _UNITY_GAME, "A Unity Game ID is a number (5 to 12 digits)."),
            ("unity_placement_id", _UNITY_PLACEMENT, "A Unity placement ID uses letters, digits, _ . - only."),
        ):
            v = cfg[key].strip()
            if v and not rx.match(v):
                raise AdminError(hint)
            cfg[key] = v
        app_id = cfg["admob_app_id"].strip()
        if app_id and not re.fullmatch(r"ca-app-pub-\d{16}~\d{10}", app_id):
            raise AdminError("AdMob app id looks like ca-app-pub-1234567890123456~1234567890.")
        cfg["admob_app_id"] = app_id
        game = cfg["unity_game_id"].strip()
        if game and not re.fullmatch(r"\d{4,12}", game):
            raise AdminError("Unity Game ID is a number such as 1234567.")
        cfg["unity_game_id"] = game
        place = cfg["unity_placement_id"].strip()
        if place and not re.fullmatch(r"[A-Za-z0-9_\-]{1,64}", place):
            raise AdminError("Unity Placement ID may contain letters, numbers, - and _ only.")
        cfg["unity_placement_id"] = place
        if cfg["ads_enabled"] and cfg["provider"] == "unity" and not (game and place):
            raise AdminError("Enter both the Unity Game ID and Placement ID before turning Unity on.")
        if cfg["ads_enabled"] and cfg["provider"] == "none":
            raise AdminError("Choose an ad provider before enabling ads.")
        self.db.set_setting("ads.config", json.dumps(cfg))
        return cfg

    # ------------------------------------------------------- reward unlock
    def unlock_status(self) -> dict[str, Any]:
        until = float(self.db.get_setting("ads.unlock_until", "0") or 0)
        remaining = max(0, int(until - self._clock()))
        return {"unlocked": remaining > 0, "remaining_seconds": remaining}

    def grant_unlock(self, minutes: int | None = None) -> dict[str, Any]:
        """Called by an ad provider's reward callback (or the admin test button)."""
        minutes = minutes or self.get_ads_config()["rewarded_unlock_minutes"]
        self.db.set_setting("ads.unlock_until", str(self._clock() + minutes * 60))
        return self.unlock_status()

    def admin_test_unlock(self, token: str) -> dict[str, Any]:
        self.require(token)
        return self.grant_unlock()
