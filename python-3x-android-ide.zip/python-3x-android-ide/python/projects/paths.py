"""Path validation. Every file operation in the app goes through here."""

from __future__ import annotations

import os
import re
from pathlib import Path

TRASH_DIR = ".py3x_trash"
HIDDEN_DIRS = {TRASH_DIR, "__pycache__", ".git"}

TEXT_EXTENSIONS = {
    ".py", ".pyw", ".pyi", ".txt", ".md", ".json", ".xml", ".yaml", ".yml",
    ".csv", ".html", ".htm", ".css", ".js", ".ts", ".toml", ".ini", ".cfg",
    ".sh", ".sql", ".rst", ".log", ".env", ".gitignore", ".tsv",
}
MAX_TEXT_BYTES = 2 * 1024 * 1024  # editor refuses larger files (large-file handling)

_BAD_NAME = re.compile(r"[\x00-\x1f/\\]")


class PathError(ValueError):
    """Raised for any path or name that is unsafe or invalid."""


def validate_name(name: str) -> str:
    name = (name or "").strip()
    if not name or name in {".", ".."}:
        raise PathError("Name cannot be empty, '.' or '..'.")
    if _BAD_NAME.search(name):
        raise PathError("Name contains invalid characters.")
    if len(name.encode("utf-8")) > 255:
        raise PathError("Name is too long.")
    if name == TRASH_DIR:
        raise PathError("That name is reserved.")
    return name


def resolve_inside(root: Path, rel: str, *, allow_root: bool = False) -> Path:
    """Resolve ``rel`` under ``root`` and refuse anything that escapes it."""
    if rel is None:
        raise PathError("Path is required.")
    rel = rel.replace("\\", "/").strip("/")
    if not rel:
        if allow_root:
            return root
        raise PathError("Path is required.")
    if rel.startswith("~") or os.path.isabs(rel) or re.match(r"^[A-Za-z]:", rel):
        raise PathError("Absolute paths are not allowed.")
    parts = rel.split("/")
    for part in parts:
        if part in {"..", ""}:
            raise PathError("Path may not contain '..' or empty segments.")
        validate_name(part)
    if parts[0] == TRASH_DIR:
        raise PathError("That path is reserved.")
    real_root = root.resolve()
    target = (real_root / rel).resolve()
    if target != real_root and real_root not in target.parents:
        raise PathError("Path escapes the project folder.")
    return target


def is_text_name(name: str) -> bool:
    suffix = Path(name).suffix.lower()
    return suffix in TEXT_EXTENSIONS or Path(name).name in {"Makefile", "LICENSE", "README"}


def slugify(name: str) -> str:
    slug = re.sub(r"[^A-Za-z0-9_-]+", "-", name.strip()).strip("-").lower()
    return slug or "project"
