"""Project and file management.

Projects live under ``<root>/<slug>/``. Deleting never destroys data: files and
projects move to a trash and can be restored until the user purges them.
"""

from __future__ import annotations

import hashlib
import os
import shutil
import tempfile
import zipfile
from pathlib import Path
from typing import Any

from storage.db import Database, now

from .paths import (
    HIDDEN_DIRS,
    MAX_TEXT_BYTES,
    TRASH_DIR,
    PathError,
    is_text_name,
    resolve_inside,
    slugify,
    validate_name,
)

MAIN_TEMPLATE = '''"""{name}"""


def main():
    print("Hello from Python 3.x!")


if __name__ == "__main__":
    main()
'''

MAX_IMPORT_FILES = 5000
MAX_IMPORT_BYTES = 200 * 1024 * 1024
SORT_KEYS = ("name", "modified", "size", "type")


def content_hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def write_atomic(path: Path, text: str) -> None:
    """Write via temp file + rename so a crash never leaves a half-written file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=".tmp-", suffix=".part")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


class ProjectManager:
    def __init__(self, db: Database, root: str | Path):
        self.db = db
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        (self.root / ".trash").mkdir(exist_ok=True)

    # ------------------------------------------------------------ projects
    def _row_to_dict(self, row: Any) -> dict[str, Any]:
        return {
            "id": row["id"],
            "name": row["name"],
            "slug": row["slug"],
            "main_file": row["main_file"],
            "created_at": row["created_at"],
            "modified_at": row["modified_at"],
            "deleted": row["deleted_at"] is not None,
        }

    def _unique_slug(self, base: str) -> str:
        slug, n = base, 2
        while self.db.query_one("SELECT 1 FROM projects WHERE slug = ?", (slug,)) or (
            self.root / slug
        ).exists():
            slug = f"{base}-{n}"
            n += 1
        return slug

    def create_project(self, name: str, main_file: str = "main.py", template: bool = True) -> dict:
        name = validate_name(name)
        validate_name(main_file)
        slug = self._unique_slug(slugify(name))
        directory = self.root / slug
        directory.mkdir(parents=True)
        if template:
            write_atomic(directory / main_file, MAIN_TEMPLATE.format(name=name))
        ts = now()
        pid = self.db.execute(
            "INSERT INTO projects(name, slug, main_file, created_at, modified_at) "
            "VALUES(?,?,?,?,?)",
            (name, slug, main_file, ts, ts),
        )
        return self.get_project(pid)

    def get_project(self, project_id: int) -> dict:
        row = self.db.query_one("SELECT * FROM projects WHERE id = ?", (project_id,))
        if row is None:
            raise PathError(f"Project {project_id} not found.")
        return self._row_to_dict(row)

    def list_projects(self) -> list[dict]:
        rows = self.db.query(
            "SELECT * FROM projects WHERE deleted_at IS NULL ORDER BY modified_at DESC"
        )
        return [self._row_to_dict(r) for r in rows]

    def project_dir(self, project_id: int) -> Path:
        row = self.db.query_one(
            "SELECT slug FROM projects WHERE id = ? AND deleted_at IS NULL", (project_id,)
        )
        if row is None:
            raise PathError(f"Project {project_id} not found.")
        return self.root / row["slug"]

    def rename_project(self, project_id: int, new_name: str) -> dict:
        new_name = validate_name(new_name)
        self.project_dir(project_id)
        self.db.execute(
            "UPDATE projects SET name = ?, modified_at = ? WHERE id = ?",
            (new_name, now(), project_id),
        )
        return self.get_project(project_id)

    def set_main_file(self, project_id: int, rel: str) -> dict:
        target = resolve_inside(self.project_dir(project_id), rel)
        if not target.is_file():
            raise PathError("Main file must be an existing file.")
        self.db.execute("UPDATE projects SET main_file = ? WHERE id = ?", (rel, project_id))
        return self.get_project(project_id)

    def _touch(self, project_id: int) -> None:
        self.db.execute("UPDATE projects SET modified_at = ? WHERE id = ?", (now(), project_id))

    def delete_project(self, project_id: int) -> None:
        """Soft delete: the folder moves to ``.trash`` and can be restored."""
        directory = self.project_dir(project_id)
        dest = self.root / ".trash" / f"{directory.name}-{int(now())}"
        if directory.exists():
            shutil.move(str(directory), str(dest))
        self.db.execute(
            "UPDATE projects SET deleted_at = ?, slug = ? WHERE id = ?",
            (now(), f".trash/{dest.name}", project_id),
        )

    def list_deleted_projects(self) -> list[dict]:
        rows = self.db.query(
            "SELECT * FROM projects WHERE deleted_at IS NOT NULL ORDER BY deleted_at DESC"
        )
        return [self._row_to_dict(r) for r in rows]

    def restore_project(self, project_id: int) -> dict:
        row = self.db.query_one(
            "SELECT * FROM projects WHERE id = ? AND deleted_at IS NOT NULL", (project_id,)
        )
        if row is None:
            raise PathError("Project is not in the trash.")
        trash_dir = self.root / row["slug"]
        base = slugify(row["name"])
        slug = self._unique_slug(base)
        if trash_dir.exists():
            shutil.move(str(trash_dir), str(self.root / slug))
        else:
            (self.root / slug).mkdir()
        self.db.execute(
            "UPDATE projects SET deleted_at = NULL, slug = ?, modified_at = ? WHERE id = ?",
            (slug, now(), project_id),
        )
        return self.get_project(project_id)

    def purge_project(self, project_id: int) -> None:
        """Permanent delete. Only call after explicit user confirmation."""
        row = self.db.query_one(
            "SELECT * FROM projects WHERE id = ? AND deleted_at IS NOT NULL", (project_id,)
        )
        if row is None:
            raise PathError("Only projects in the trash can be permanently deleted.")
        shutil.rmtree(self.root / row["slug"], ignore_errors=True)
        for table in ("recent_files", "favorites", "drafts", "file_versions", "trash"):
            self.db.execute(f"DELETE FROM {table} WHERE project_id = ?", (project_id,))
        self.db.execute("DELETE FROM projects WHERE id = ?", (project_id,))

    def duplicate_project(self, project_id: int, new_name: str | None = None) -> dict:
        src = self.project_dir(project_id)
        info = self.get_project(project_id)
        name = validate_name(new_name or f"{info['name']} copy")
        slug = self._unique_slug(slugify(name))
        shutil.copytree(
            src, self.root / slug, ignore=shutil.ignore_patterns(TRASH_DIR, "__pycache__")
        )
        ts = now()
        pid = self.db.execute(
            "INSERT INTO projects(name, slug, main_file, created_at, modified_at) "
            "VALUES(?,?,?,?,?)",
            (name, slug, info["main_file"], ts, ts),
        )
        return self.get_project(pid)

    # ------------------------------------------------------- import / export
    def export_project(self, project_id: int, dest_zip: str | Path) -> str:
        src = self.project_dir(project_id)
        dest = Path(dest_zip)
        dest.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as zf:
            for path in sorted(src.rglob("*")):
                rel = path.relative_to(src)
                if any(part in HIDDEN_DIRS for part in rel.parts) or not path.is_file():
                    continue
                if path.is_symlink():
                    continue
                zf.write(path, rel.as_posix())
        return str(dest)

    def import_project(self, zip_path: str | Path, name: str | None = None) -> dict:
        zip_path = Path(zip_path)
        if not zipfile.is_zipfile(zip_path):
            raise PathError("Not a valid zip file.")
        with zipfile.ZipFile(zip_path) as zf:
            infos = [i for i in zf.infolist() if not i.is_dir()]
            if len(infos) > MAX_IMPORT_FILES:
                raise PathError(f"Archive has too many files (max {MAX_IMPORT_FILES}).")
            if sum(i.file_size for i in infos) > MAX_IMPORT_BYTES:
                raise PathError("Archive is too large when extracted.")
            members: list[tuple[zipfile.ZipInfo, str]] = []
            for info in infos:
                rel = info.filename.replace("\\", "/").strip("/")
                if (info.external_attr >> 28) == 0xA:  # symlink entry
                    continue
                resolve_inside(Path("/_check_"), rel)  # rejects zip-slip, abs, reserved
                members.append((info, rel))
            project = self.create_project(name or zip_path.stem, template=False)
            directory = self.project_dir(project["id"])
            for info, rel in members:
                target = resolve_inside(directory, rel)
                target.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(info) as src, open(target, "wb") as out:
                    shutil.copyfileobj(src, out)
        main = "main.py" if (directory / "main.py").exists() else self._first_py(directory)
        if main:
            self.db.execute("UPDATE projects SET main_file = ? WHERE id = ?", (main, project["id"]))
        return self.get_project(project["id"])

    @staticmethod
    def _first_py(directory: Path) -> str | None:
        for path in sorted(directory.rglob("*.py")):
            return path.relative_to(directory).as_posix()
        return None

    # ----------------------------------------------------------------- files
    def _target(self, project_id: int, rel: str, **kw: Any) -> Path:
        return resolve_inside(self.project_dir(project_id), rel, **kw)

    def list_dir(self, project_id: int, rel: str = "", sort: str = "name") -> list[dict]:
        """One level of the tree (lazy loading keeps big projects fast)."""
        if sort not in SORT_KEYS:
            raise PathError(f"Unknown sort '{sort}'.")
        base = self._target(project_id, rel, allow_root=True)
        if not base.is_dir():
            raise PathError("Not a folder.")
        entries = []
        for entry in os.scandir(base):
            if entry.name in HIDDEN_DIRS or entry.name.startswith(".tmp-"):
                continue
            stat = entry.stat(follow_symlinks=False)
            is_dir = entry.is_dir(follow_symlinks=False)
            entries.append(
                {
                    "name": entry.name,
                    "rel": f"{rel.strip('/')}/{entry.name}".lstrip("/"),
                    "is_dir": is_dir,
                    "size": 0 if is_dir else stat.st_size,
                    "modified": stat.st_mtime,
                    "editable": (not is_dir) and is_text_name(entry.name),
                }
            )
        keyfn = {
            "name": lambda e: e["name"].lower(),
            "modified": lambda e: -e["modified"],
            "size": lambda e: -e["size"],
            "type": lambda e: (Path(e["name"]).suffix.lower(), e["name"].lower()),
        }[sort]
        entries.sort(key=lambda e: (not e["is_dir"], keyfn(e)))
        return entries

    def read_file(self, project_id: int, rel: str) -> dict:
        path = self._target(project_id, rel)
        if not path.is_file():
            raise PathError("File not found.")
        size = path.stat().st_size
        if size > MAX_TEXT_BYTES:
            raise PathError(
                f"File is {size // 1024} KB; the editor opens text files up to "
                f"{MAX_TEXT_BYTES // 1024} KB."
            )
        raw = path.read_bytes()
        if b"\x00" in raw[:8192]:
            raise PathError("This looks like a binary file and cannot be edited as text.")
        try:
            text = raw.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise PathError("File is not valid UTF-8 text.") from exc
        text = text.replace("\r\n", "\n").replace("\r", "\n")
        return {"content": text, "hash": content_hash(text), "size": size}

    def write_file(self, project_id: int, rel: str, content: str) -> str:
        path = self._target(project_id, rel)
        if path.is_dir():
            raise PathError("That path is a folder.")
        write_atomic(path, content)
        self._touch(project_id)
        return content_hash(content)

    def create_file(self, project_id: int, rel: str, content: str = "") -> dict:
        path = self._target(project_id, rel)
        if path.exists():
            raise PathError("A file or folder with that name already exists.")
        write_atomic(path, content)
        self._touch(project_id)
        return {"rel": rel.strip("/"), "hash": content_hash(content)}

    def create_folder(self, project_id: int, rel: str) -> dict:
        path = self._target(project_id, rel)
        if path.exists():
            raise PathError("A file or folder with that name already exists.")
        path.mkdir(parents=True)
        self._touch(project_id)
        return {"rel": rel.strip("/")}

    def rename(self, project_id: int, rel: str, new_name: str) -> dict:
        new_name = validate_name(new_name)
        src = self._target(project_id, rel)
        if not src.exists():
            raise PathError("Item not found.")
        dest = src.with_name(new_name)
        if dest.exists():
            raise PathError("An item with that name already exists.")
        src.rename(dest)
        base = self.project_dir(project_id)
        new_rel = dest.relative_to(base.resolve()).as_posix()
        self._move_metadata(project_id, rel.strip("/"), new_rel)
        self._touch(project_id)
        return {"rel": new_rel}

    def move(self, project_id: int, rel: str, dest_dir_rel: str) -> dict:
        src = self._target(project_id, rel)
        dest_dir = self._target(project_id, dest_dir_rel, allow_root=True)
        if not src.exists() or not dest_dir.is_dir():
            raise PathError("Source or destination not found.")
        if src.is_dir() and (dest_dir == src or src in dest_dir.parents):
            raise PathError("Cannot move a folder into itself.")
        dest = dest_dir / src.name
        if dest.exists():
            raise PathError("An item with that name already exists in the destination.")
        shutil.move(str(src), str(dest))
        new_rel = dest.relative_to(self.project_dir(project_id).resolve()).as_posix()
        self._move_metadata(project_id, rel.strip("/"), new_rel)
        self._touch(project_id)
        return {"rel": new_rel}

    def copy(self, project_id: int, rel: str, dest_dir_rel: str) -> dict:
        """Copy (paste). A name clash becomes 'name copy.ext', 'name copy 2.ext'."""
        src = self._target(project_id, rel)
        dest_dir = self._target(project_id, dest_dir_rel, allow_root=True)
        if not src.exists() or not dest_dir.is_dir():
            raise PathError("Source or destination not found.")
        if src.is_dir() and (dest_dir == src or src in dest_dir.parents):
            raise PathError("Cannot copy a folder into itself.")
        dest = dest_dir / src.name
        n = 1
        while dest.exists():
            suffix = " copy" if n == 1 else f" copy {n}"
            dest = dest_dir / (src.stem + suffix + src.suffix if src.is_file() else src.name + suffix)
            n += 1
        if src.is_dir():
            shutil.copytree(src, dest, ignore=shutil.ignore_patterns(TRASH_DIR, "__pycache__"))
        else:
            shutil.copy2(src, dest)
        self._touch(project_id)
        return {"rel": dest.relative_to(self.project_dir(project_id).resolve()).as_posix()}

    def delete(self, project_id: int, rel: str) -> int:
        """Move to the project's trash. Returns the trash id (for undo)."""
        src = self._target(project_id, rel)
        if not src.exists():
            raise PathError("Item not found.")
        base = self.project_dir(project_id)
        ts = now()
        trash_id = self.db.execute(
            "INSERT INTO trash(project_id, original_rel, trash_rel, is_dir, deleted_at) "
            "VALUES(?,?,?,?,?)",
            (project_id, rel.strip("/"), "", int(src.is_dir()), ts),
        )
        trash_rel = f"{TRASH_DIR}/{trash_id}/{src.name}"
        (base / TRASH_DIR / str(trash_id)).mkdir(parents=True, exist_ok=True)
        shutil.move(str(src), str(base / trash_rel))
        self.db.execute("UPDATE trash SET trash_rel = ? WHERE id = ?", (trash_rel, trash_id))
        rel_clean = rel.strip("/")
        like = rel_clean + "/%"
        # Unsaved drafts of deleted files move to version history so nothing typed is lost,
        # and so recovery never offers to "restore" a file that was deliberately deleted.
        for row in self.db.query(
            "SELECT rel_path, content FROM drafts WHERE project_id = ? AND (rel_path = ? OR rel_path LIKE ?)",
            (project_id, rel_clean, like),
        ):
            self.db.execute(
                "INSERT INTO file_versions(project_id, rel_path, content, content_hash, reason, created_at) "
                "VALUES(?,?,?,?,?,?)",
                (project_id, row["rel_path"], row["content"], content_hash(row["content"]),
                 "deleted_draft", ts),
            )
        for table in ("recent_files", "favorites", "drafts"):
            self.db.execute(
                f"DELETE FROM {table} WHERE project_id = ? AND (rel_path = ? OR rel_path LIKE ?)",
                (project_id, rel_clean, like),
            )
        self._touch(project_id)
        return trash_id

    def list_trash(self, project_id: int) -> list[dict]:
        rows = self.db.query(
            "SELECT * FROM trash WHERE project_id = ? ORDER BY deleted_at DESC", (project_id,)
        )
        return [
            {
                "id": r["id"],
                "original_rel": r["original_rel"],
                "is_dir": bool(r["is_dir"]),
                "deleted_at": r["deleted_at"],
            }
            for r in rows
        ]

    def restore_from_trash(self, project_id: int, trash_id: int) -> dict:
        row = self.db.query_one(
            "SELECT * FROM trash WHERE id = ? AND project_id = ?", (trash_id, project_id)
        )
        if row is None:
            raise PathError("Trash item not found.")
        base = self.project_dir(project_id)
        src = base / row["trash_rel"]
        dest = resolve_inside(base, row["original_rel"])
        n = 1
        while dest.exists():
            tag = " (restored)" if n == 1 else f" (restored {n})"
            dest = dest.with_name(dest.stem + tag + dest.suffix if not row["is_dir"] else dest.name + tag)
            n += 1
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(src), str(dest))
        shutil.rmtree(base / TRASH_DIR / str(trash_id), ignore_errors=True)
        self.db.execute("DELETE FROM trash WHERE id = ?", (trash_id,))
        self._touch(project_id)
        return {"rel": dest.relative_to(base.resolve()).as_posix()}

    def purge_trash(self, project_id: int) -> None:
        """Permanent delete of everything in a project's trash (explicit action)."""
        base = self.project_dir(project_id)
        shutil.rmtree(base / TRASH_DIR, ignore_errors=True)
        self.db.execute("DELETE FROM trash WHERE project_id = ?", (project_id,))

    # ---------------------------------------------------------------- search
    def search_files(
        self, project_id: int, query: str, content: bool = False, limit: int = 100
    ) -> list[dict]:
        query = (query or "").strip().lower()
        if not query:
            return []
        base = self.project_dir(project_id).resolve()
        results: list[dict] = []
        for dirpath, dirnames, filenames in os.walk(base):
            dirnames[:] = [d for d in dirnames if d not in HIDDEN_DIRS]
            for fname in sorted(filenames):
                full = Path(dirpath) / fname
                rel = full.relative_to(base).as_posix()
                if query in fname.lower():
                    results.append({"rel": rel, "line": 0, "snippet": ""})
                if content and is_text_name(fname) and full.stat().st_size < 1024 * 1024:
                    try:
                        text = full.read_text(encoding="utf-8")
                    except (UnicodeDecodeError, OSError):
                        continue
                    for lineno, line in enumerate(text.splitlines(), 1):
                        if query in line.lower():
                            results.append({"rel": rel, "line": lineno, "snippet": line.strip()[:160]})
                            if len(results) >= limit:
                                return results
                if len(results) >= limit:
                    return results
        return results

    # ------------------------------------------------ recents and favorites
    def touch_recent(self, project_id: int, rel: str) -> None:
        self.db.execute(
            "INSERT INTO recent_files(project_id, rel_path, opened_at) VALUES(?,?,?) "
            "ON CONFLICT(project_id, rel_path) DO UPDATE SET opened_at = excluded.opened_at",
            (project_id, rel.strip("/"), now()),
        )

    def recent_files(self, limit: int = 10) -> list[dict]:
        rows = self.db.query(
            "SELECT r.project_id, r.rel_path, r.opened_at, p.name FROM recent_files r "
            "JOIN projects p ON p.id = r.project_id WHERE p.deleted_at IS NULL "
            "ORDER BY r.opened_at DESC LIMIT ?",
            (limit,),
        )
        return [
            {
                "project_id": r["project_id"],
                "project_name": r["name"],
                "rel": r["rel_path"],
                "opened_at": r["opened_at"],
            }
            for r in rows
        ]

    def toggle_favorite(self, project_id: int, rel: str) -> bool:
        rel = rel.strip("/")
        existing = self.db.query_one(
            "SELECT 1 FROM favorites WHERE project_id = ? AND rel_path = ?", (project_id, rel)
        )
        if existing:
            self.db.execute(
                "DELETE FROM favorites WHERE project_id = ? AND rel_path = ?", (project_id, rel)
            )
            return False
        self.db.execute(
            "INSERT INTO favorites(project_id, rel_path, created_at) VALUES(?,?,?)",
            (project_id, rel, now()),
        )
        return True

    def favorites(self, project_id: int) -> list[str]:
        rows = self.db.query(
            "SELECT rel_path FROM favorites WHERE project_id = ? ORDER BY created_at", (project_id,)
        )
        return [r["rel_path"] for r in rows]

    def _move_metadata(self, project_id: int, old: str, new: str) -> None:
        """Keep recents/favorites/drafts pointing at renamed or moved paths."""
        for table in ("recent_files", "favorites", "drafts"):
            self.db.execute(
                f"UPDATE OR REPLACE {table} SET rel_path = ? WHERE project_id = ? AND rel_path = ?",
                (new, project_id, old),
            )
            self.db.execute(
                f"UPDATE OR REPLACE {table} SET rel_path = ? || substr(rel_path, ?) "
                "WHERE project_id = ? AND rel_path LIKE ?",
                (new, len(old) + 1, project_id, old + "/%"),
            )
