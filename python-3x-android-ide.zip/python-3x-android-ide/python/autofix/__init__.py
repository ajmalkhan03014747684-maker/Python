"""Offline error helper: explains a Python error in plain words and, when the fix is mechanical, proposes it.

No network and no API key. It only reads the error type/message/line and the source text, and returns text plus
(optionally) a one-line patch. Nothing is ever applied here; the app shows the patch and the person taps to apply it.
"""

from __future__ import annotations

import builtins
import difflib
import io
import keyword
import re
import tokenize
from typing import Any

# Well-known short names people forget to import, and what they import from.
_COMMON_IMPORTS = {
    "np": "import numpy as np", "pd": "import pandas as pd", "plt": "import matplotlib.pyplot as plt",
    "cv2": "import cv2", "sns": "import seaborn as sns",
    "math": "import math", "os": "import os", "sys": "import sys", "random": "import random", "json": "import json",
    "re": "import re", "time": "import time", "datetime": "import datetime", "statistics": "import statistics",
    "itertools": "import itertools", "collections": "import collections", "pathlib": "import pathlib",
    "Path": "from pathlib import Path", "defaultdict": "from collections import defaultdict",
    "Counter": "from collections import Counter", "deque": "from collections import deque",
    "dataclass": "from dataclasses import dataclass", "sqrt": "from math import sqrt", "pi": "from math import pi",
}
_PACKS_MODULES = {"cv2", "scipy", "sklearn", "skimage", "statsmodels"}
_BLOCK_KEYWORDS = ("def ", "class ", "if ", "elif ", "else", "for ", "while ", "try", "except", "finally", "with ", "match ", "case ")


def _result(title: str, explanation: str, *, patch: dict | None = None, steps: list[str] | None = None,
            packs: bool = False) -> dict[str, Any]:
    return {"title": title, "explanation": explanation, "steps": steps or [], "patch": patch, "packs": packs}


def _patch(lines: list[str], line: int, new: str) -> dict | None:
    if not (1 <= line <= len(lines)) or lines[line - 1] == new:
        return None
    return {"line": line, "old": lines[line - 1], "new": new}


def _identifiers(source: str) -> list[str]:
    names: list[str] = []
    try:
        for tok in tokenize.generate_tokens(io.StringIO(source).readline):
            if tok.type == tokenize.NAME and not keyword.iskeyword(tok.string):
                names.append(tok.string)
    except (tokenize.TokenError, IndentationError, SyntaxError):
        names = re.findall(r"[A-Za-z_][A-Za-z0-9_]*", source)
    seen: dict[str, None] = {}
    for n in names:
        seen.setdefault(n, None)
    return list(seen)


def _replace_word(text: str, old: str, new: str) -> str:
    return re.sub(rf"(?<![A-Za-z0-9_.]){re.escape(old)}(?![A-Za-z0-9_])", new, text, count=1)


def _syntax(lines: list[str], line: int, message: str) -> dict[str, Any]:
    text = lines[line - 1] if 1 <= line <= len(lines) else ""
    stripped = text.rstrip()
    low = message.lower()
    if "expected ':'" in low or (low == "invalid syntax" and stripped.lstrip().startswith(_BLOCK_KEYWORDS)
                                  and not stripped.endswith(":")):
        return _result("A colon is missing", "A line that starts a block (def, if, for, while, class, try…) must end with ':'.",
                       patch=_patch(lines, line, stripped + ":"))
    if "unterminated string" in low or "eol while scanning" in low:
        quote = '"' if stripped.count('"') % 2 else "'" if stripped.count("'") % 2 else '"'
        return _result("A string is not closed", f"The text on this line starts a string but never closes it with a matching {quote}.",
                       patch=_patch(lines, line, stripped + quote))
    m = re.search(r"'(\(|\[|\{)' was never closed", message)
    if m:
        close = {"(": ")", "[": "]", "{": "}"}[m.group(1)]
        return _result("A bracket is not closed", f"A '{m.group(1)}' was opened here and never closed with '{close}'.",
                       patch=_patch(lines, line, stripped + close))
    m = re.search(r"unmatched '(\)|\]|\})'", message)
    if m:
        idx = stripped.rfind(m.group(1))
        fixed = stripped[:idx] + stripped[idx + 1:] if idx >= 0 else stripped
        return _result("An extra closing bracket", f"There is a '{m.group(1)}' with nothing to close on this line.",
                       patch=_patch(lines, line, fixed))
    if "maybe you meant '=='" in low:
        fixed = re.sub(r"(?<![=!<>:])=(?!=)", "==", stripped, count=1)
        return _result("Use == to compare", "A single '=' stores a value; to compare two values in a condition use '=='.",
                       patch=_patch(lines, line, fixed))
    if "expected an indented block" in low:
        # The error points at the line that should have been indented.
        indent = re.match(r"\s*", text).group(0)
        return _result("This line needs to be indented", "After a line ending in ':' the next lines must be indented.",
                       patch=_patch(lines, line, indent + "    " + text.lstrip()))
    if "unexpected indent" in low:
        return _result("Unexpected indentation", "This line is indented more than the lines around it.",
                       patch=_patch(lines, line, text.lstrip()) if line == 1 else None,
                       steps=["Remove the extra spaces at the start of this line, or indent the line above to match."])
    if "does not match any outer indentation" in low:
        return _result("Indentation does not line up", "This line's indentation matches no earlier block.",
                       steps=["Use the same number of spaces for every line of the block (4 is the usual)."])
    if "missing parentheses in call to 'print'" in low:
        m2 = re.match(r"(\s*)print\s+(.*)$", stripped)
        return _result("print needs brackets", "In Python 3, print is a function: print(...).",
                       patch=_patch(lines, line, f"{m2.group(1)}print({m2.group(2)})") if m2 else None)
    return _result("Syntax error", f"Python could not read line {line}: {message}.",
                   steps=["Look at the marked line and the line above it: a missing bracket, quote or colon is the usual cause."])


def _name_error(source: str, lines: list[str], line: int, message: str) -> dict[str, Any]:
    m = re.search(r"name '([^']+)' is not defined", message)
    if not m:
        return _result("Name not defined", message)
    name = m.group(1)
    if name in _COMMON_IMPORTS:
        stmt = _COMMON_IMPORTS[name]
        return _result(f"'{name}' is not imported", f"'{name}' is used but was never imported.",
                       patch={"line": 0, "old": "", "new": stmt},
                       steps=[f"Add `{stmt}` at the top of the file."],
                       packs=name in _PACKS_MODULES)
    pool = [n for n in _identifiers(source) if n != name] + [b for b in dir(builtins) if not b.startswith("_")]
    close = difflib.get_close_matches(name, pool, n=1, cutoff=0.7)
    if close and 1 <= line <= len(lines):
        return _result(f"'{name}' looks misspelled", f"'{name}' does not exist. Did you mean '{close[0]}'?",
                       patch=_patch(lines, line, _replace_word(lines[line - 1], name, close[0])))
    return _result(f"'{name}' is not defined",
                   f"'{name}' is used before it is created. Names must be assigned, defined as functions, or imported first.",
                   steps=[f"Define {name} above line {line}, or import it, or fix the spelling."])


def diagnose(source: str, error_type: str, message: str, line: int) -> dict[str, Any]:
    lines = source.splitlines()
    et = error_type or ""
    if et in ("SyntaxError", "IndentationError", "TabError"):
        return _syntax(lines, line, message)
    if et == "NameError":
        return _name_error(source, lines, line, message)
    if et == "UnboundLocalError":
        return _result("Variable used before it is set in this function",
                       "A variable that is assigned anywhere inside a function is local to the whole function, so reading it before the assignment fails.",
                       steps=["Assign it before using it, or add `global name` at the top of the function if you mean the outer one."])
    if et in ("ModuleNotFoundError", "ImportError") and "No module named" in message:
        mod = (re.search(r"No module named '([^']+)'", message) or [None, ""])[1].split(".")[0]
        if mod in _PACKS_MODULES:
            return _result(f"{mod} lives in the Packs app",
                           f"{mod} only exists for Python 3.10 on Android, so it is in the Python 3.x Packs app, not in this Python.",
                           steps=["Tap PACKS instead of RUN. Install the Packs app first from Tools → Packages if it is missing."], packs=True)
        return _result(f"'{mod}' is not installed",
                       "Android cannot install packages while the app runs. Only packages bundled at build time are available.",
                       steps=["Open Tools → Packages and check the name to see whether it exists for Android.",
                              "If it is a pure-Python package, it can be added to the build list."])
    if et == "ImportError" and "cannot import name" in message:
        return _result("That name is not in the module", message + ".",
                       steps=["Check the spelling, and check the module's version: the name may have been renamed or removed."])
    if et == "ZeroDivisionError":
        return _result("Division by zero", "The divisor is 0 at this moment.",
                       steps=["Check the value before dividing: `if b != 0:`.", "Find out why it is 0 by printing it just before this line."])
    if et == "EOFError":
        return _result("The script asked for input but none was given",
                       "input() waits for you to type something. When none arrives the script stops with this error.",
                       steps=["While the script is running, type into the input box at the bottom of the Run page and tap Send.",
                              "Or replace input() with a fixed value for testing."])
    if et == "TypeError":
        if "can only concatenate str" in message or "unsupported operand type(s) for +: 'int' and 'str'" in message:
            return _result("Mixing text and numbers", "You cannot add a number and text directly.",
                           steps=["Convert the number: str(n) to join it with text, or int(text) to calculate."])
        if "not callable" in message:
            return _result("Calling something that is not a function",
                           "A name that holds a value (a number, string or list) is followed by ( ).",
                           steps=["Check you did not reuse a function name as a variable (like `list = [...]` or `sum = 0`)."])
        if "not subscriptable" in message:
            return _result("Indexing something that cannot be indexed", message + ".",
                           steps=["The value is probably None or a number. Print it to see what it really is."])
        if "positional argument" in message or "unexpected keyword" in message:
            return _result("Wrong number of arguments", message + ".", steps=["Compare the call with the function's def line."])
        return _result("Wrong type", message + ".", steps=["Print the values and their types just before this line: print(type(x))."])
    if et == "IndexError":
        return _result("Index out of range", "The list or string is shorter than the position asked for. Positions start at 0.",
                       steps=["Check len(x) before indexing.", "The last item is x[-1]."])
    if et == "KeyError":
        return _result("Missing dictionary key", f"The key {message} is not in the dictionary.",
                       steps=["Use d.get(key) to get None when missing, or check `if key in d:` first."])
    if et == "AttributeError":
        if "'NoneType'" in message:
            return _result("The value is None", message + ".",
                           steps=["A function probably returned nothing (None). Check its return statement.",
                                  "Methods like list.sort() change the list and return None; do not assign their result."])
        m = re.search(r"'(\w+)' object has no attribute '(\w+)'", message)
        if m:
            kind = getattr(builtins, m.group(1), None)
            if isinstance(kind, type):
                close = difflib.get_close_matches(m.group(2), [a for a in dir(kind) if not a.startswith("_")], n=1, cutoff=0.7)
                if close and 1 <= line <= len(lines):
                    return _result("Attribute name looks misspelled", f"{m.group(1)} has no '{m.group(2)}'. Did you mean '{close[0]}'?",
                                   patch=_patch(lines, line, _replace_word(lines[line - 1], m.group(2), close[0])))
        return _result("Missing attribute", message + ".", steps=["Check the spelling, and print(dir(obj)) to see what it has."])
    if et == "ValueError":
        if "invalid literal for int()" in message or "could not convert string to float" in message:
            return _result("Text is not a number", message + ".",
                           steps=["Check the text before converting. Remove spaces with .strip().", "Use try/except ValueError to handle bad input."])
        return _result("Bad value", message + ".", steps=["Print the value being passed and compare it with what the function expects."])
    if et in ("FileNotFoundError", "NotADirectoryError"):
        return _result("File not found", message + ".",
                       steps=["Files are looked up inside the running project's folder. Create or import the file there.",
                              "Check the name and capital letters exactly."])
    if et == "PermissionError":
        return _result("Not allowed to use that file", message + ".", steps=["Keep files inside your project folder."])
    if et == "RecursionError":
        return _result("Function calls itself forever", "A recursive function has no case that stops.",
                       steps=["Add a base case that returns without calling the function again."])
    if et == "KeyboardInterrupt":
        return _result("Stopped", "The run was stopped before it finished.")
    return _result(et or "Error", message or "The script stopped with an error.",
                   steps=["Read the line number, then print the values used on that line."])


from .assist import assist  # noqa: E402,F401
