"""Offline coding assistant: explain, fix, improve, tests, docstrings and a small question answerer.

Everything is rule based and runs on the phone. It reads code with Python's own ``ast`` module, so what it says about
the code is true of the code; it never guesses what a program is "for", and it says so when it cannot help.
"""

from __future__ import annotations

import ast
import builtins
import re
from typing import Any

from . import diagnose

MAX_SOURCE = 200_000


def _short(node: ast.AST | None, limit: int = 60) -> str:
    if node is None:
        return ""
    try:
        text = ast.unparse(node)
    except Exception:  # noqa: BLE001
        return "…"
    text = " ".join(text.split())
    return text if len(text) <= limit else text[: limit - 1] + "…"


def _call_name(node: ast.AST) -> str:
    if isinstance(node, ast.Call):
        f = node.func
        if isinstance(f, ast.Name):
            return f.id
        if isinstance(f, ast.Attribute):
            return _short(f)
    return ""


def _says(value: ast.AST) -> str:
    """Plain-words description of an expression, for the cases people meet most."""
    if isinstance(value, ast.Call):
        name = _call_name(value)
        if name == "int" and value.args and _call_name(value.args[0]) == "input":
            return "a whole number typed by the user (input() reads text, int() turns it into a number)"
        if name == "float" and value.args and _call_name(value.args[0]) == "input":
            return "a decimal number typed by the user"
        if name == "input":
            return "text typed by the user"
        if name == "len":
            return f"the length of {_short(value.args[0]) if value.args else 'something'}"
        if name == "range":
            return "a range of numbers"
        if name in ("list", "dict", "set", "tuple", "str", "int", "float", "sorted", "sum", "max", "min", "abs", "round"):
            return f"the result of {name}({_short(value.args[0]) if value.args else ''})"
        if name == "open":
            return "an opened file"
    if isinstance(value, ast.List):
        return f"a list of {len(value.elts)} item(s)"
    if isinstance(value, ast.Dict):
        return f"a dictionary with {len(value.keys)} key(s)"
    if isinstance(value, ast.Constant):
        return f"the {type(value.value).__name__} {value.value!r}"[:70]
    return f"the value of `{_short(value)}`"


def _describe(node: ast.stmt, depth: int, out: list[str]) -> None:
    pad = "  " * depth
    ln = node.lineno
    if isinstance(node, (ast.Import, ast.ImportFrom)):
        names = ", ".join(a.name for a in node.names)
        src = f"from {node.module} " if isinstance(node, ast.ImportFrom) else ""
        out.append(f"{pad}Line {ln}: loads {src}{names} so the code can use it.")
    elif isinstance(node, ast.Assign):
        targets = ", ".join(_short(t) for t in node.targets)
        out.append(f"{pad}Line {ln}: stores {_says(node.value)} in `{targets}`.")
    elif isinstance(node, ast.AugAssign):
        out.append(f"{pad}Line {ln}: changes `{_short(node.target)}` by `{type(node.op).__name__}` with {_short(node.value)}.")
    elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
        args = ", ".join(a.arg for a in node.args.args)
        doc = ast.get_docstring(node)
        out.append(f"{pad}Line {ln}: defines the function `{node.name}({args})`" + (f" — {doc.splitlines()[0]}" if doc else "") + ". It only runs when called.")
        _body(node.body, depth + 1, out)
    elif isinstance(node, ast.ClassDef):
        out.append(f"{pad}Line {ln}: defines the class `{node.name}`, a blueprint for objects.")
        _body(node.body, depth + 1, out)
    elif isinstance(node, ast.For):
        out.append(f"{pad}Line {ln}: repeats for each `{_short(node.target)}` in `{_short(node.iter)}`:")
        _body(node.body, depth + 1, out)
    elif isinstance(node, ast.While):
        out.append(f"{pad}Line {ln}: repeats while `{_short(node.test)}` is true:")
        _body(node.body, depth + 1, out)
    elif isinstance(node, ast.If):
        out.append(f"{pad}Line {ln}: if `{_short(node.test)}` is true:")
        _body(node.body, depth + 1, out)
        if node.orelse:
            out.append(f"{pad}  otherwise:")
            _body(node.orelse, depth + 1, out)
    elif isinstance(node, ast.Try):
        out.append(f"{pad}Line {ln}: tries the code below and handles errors if they happen:")
        _body(node.body, depth + 1, out)
        for h in node.handlers:
            kind = _short(h.type) if h.type else "any error"
            out.append(f"{pad}  Line {h.lineno}: if {kind} happens, runs the handler.")
    elif isinstance(node, ast.With):
        out.append(f"{pad}Line {ln}: opens `{', '.join(_short(i.context_expr) for i in node.items)}` and closes it automatically at the end:")
        _body(node.body, depth + 1, out)
    elif isinstance(node, ast.Return):
        out.append(f"{pad}Line {ln}: gives back {_says(node.value) if node.value else 'nothing'} to whoever called the function.")
    elif isinstance(node, ast.Expr) and isinstance(node.value, ast.Call):
        name = _call_name(node.value)
        if name in ("int", "float") and node.value.args and _call_name(node.value.args[0]) == "input":
            out.append(f"{pad}Line {ln}: asks the user to type a number, converts it, and then does nothing with it (store it in a variable to keep it).")
        elif name == "input":
            out.append(f"{pad}Line {ln}: waits for the user to type something and ignores it (store it in a variable to keep it).")
        elif name == "print":
            out.append(f"{pad}Line {ln}: shows {_short(ast.Tuple(elts=node.value.args, ctx=ast.Load())).strip('()') or 'a blank line'} on the screen.")
        else:
            out.append(f"{pad}Line {ln}: calls `{_short(node.value)}`.")
    elif isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
        out.append(f"{pad}Line {ln}: a text note (docstring).")
    elif isinstance(node, (ast.Pass, ast.Break, ast.Continue)):
        out.append(f"{pad}Line {ln}: `{type(node).__name__.lower()}`.")
    else:
        out.append(f"{pad}Line {ln}: `{_short(node)}`.")


def _body(stmts: list[ast.stmt], depth: int, out: list[str]) -> None:
    if depth > 4:
        out.append("  " * depth + "…")
        return
    for s in stmts[:60]:
        _describe(s, depth, out)


def explain(source: str) -> str:
    if not source.strip():
        return "There is no code to explain. Open a file (or select some code) first."
    try:
        tree = ast.parse(source)
    except SyntaxError as e:
        d = diagnose(source, type(e).__name__, e.msg, e.lineno or 1)
        return f"I can't explain this yet because Python cannot read it.\n\nLine {e.lineno}: {d['title']}. {d['explanation']}"
    out: list[str] = ["Here is what the code does, from top to bottom:", ""]
    _body(tree.body, 0, out)
    return "\n".join(out)


def _defined_names(tree: ast.AST) -> set[str]:
    names = set(dir(builtins)) | {"__file__", "__name__", "__doc__"}
    for n in ast.walk(tree):
        if isinstance(n, ast.Name) and isinstance(n.ctx, (ast.Store, ast.Del)):
            names.add(n.id)
        elif isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            names.add(n.name)
            if not isinstance(n, ast.ClassDef):
                a = n.args
                for arg in [*a.posonlyargs, *a.args, *a.kwonlyargs, a.vararg, a.kwarg]:
                    if arg:
                        names.add(arg.arg)
        elif isinstance(n, ast.Lambda):
            for arg in n.args.args:
                names.add(arg.arg)
        elif isinstance(n, (ast.Import, ast.ImportFrom)):
            for al in n.names:
                names.add((al.asname or al.name).split(".")[0])
        elif isinstance(n, ast.ExceptHandler) and n.name:
            names.add(n.name)
        elif isinstance(n, (ast.Global, ast.Nonlocal)):
            names.update(n.names)
        elif isinstance(n, ast.MatchAs) and n.name:
            names.add(n.name)
    return names


def fix(source: str, last_error: dict | None) -> dict[str, Any]:
    """Finds the first problem it can: a syntax error, the last run error, or a name used but never defined."""
    if not source.strip():
        return {"text": "There is no code to check. Open a file first.", "fix": None}
    try:
        tree = ast.parse(source)
    except SyntaxError as e:
        return _fix_text(diagnose(source, type(e).__name__, e.msg, e.lineno or 1), e.lineno or 1)
    if last_error:
        d = diagnose(source, last_error["type"], last_error["message"], int(last_error["line"]))
        return _fix_text(d, int(last_error["line"]), f"{last_error['type']}: {last_error['message']}")
    defined = _defined_names(tree)
    for n in ast.walk(tree):
        if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load) and n.id not in defined:
            d = diagnose(source, "NameError", f"name '{n.id}' is not defined", n.lineno)
            return _fix_text(d, n.lineno)
    return {"text": "I found no syntax errors and no names that are used without being defined. "
                    "Run the file; if it fails, the error helper on the Run page explains the exact error.", "fix": None}


def _fix_text(d: dict, line: int, heading: str | None = None) -> dict[str, Any]:
    lines = [heading or f"Problem near line {line}", "", f"{d['title']}.", d["explanation"]]
    lines += [f"• {s}" for s in d["steps"]]
    p = d["patch"]
    if p:
        lines += ["", "Suggested fix:" + (f" add `{p['new']}` at the top." if p["line"] == 0 else f" line {p['line']} becomes `{p['new'].strip()}`."),
                  "Tap Apply fix below to change the file (Undo takes it back)."]
    if d["packs"]:
        lines += ["", "Use the PACKS button to run this file."]
    return {"text": "\n".join(lines), "fix": {"line": p["line"], "new": p["new"]} if p else None, "packs": d["packs"]}


def improve(source: str) -> str:
    if not source.strip():
        return "There is no code to review. Open a file first."
    try:
        tree = ast.parse(source)
    except SyntaxError as e:
        return f"Fix the syntax error on line {e.lineno} first ({e.msg}); then I can review the code."
    notes: list[str] = []
    used = {n.id for n in ast.walk(tree) if isinstance(n, ast.Name)}
    for n in tree.body:
        if isinstance(n, (ast.Import, ast.ImportFrom)):
            for al in n.names:
                local = (al.asname or al.name).split(".")[0]
                if local not in used and al.name != "*":
                    notes.append(f"Line {n.lineno}: `{al.name}` is imported but never used. Remove it.")
    with_items = {id(i.context_expr) for w in ast.walk(tree) if isinstance(w, ast.With) for i in w.items}
    missing_doc = 0
    for n in ast.walk(tree):
        if isinstance(n, ast.ExceptHandler) and n.type is None:
            notes.append(f"Line {n.lineno}: a bare `except:` hides every error, even Ctrl-C. Name the error, like `except ValueError:`.")
        elif isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for d in [*n.args.defaults, *n.args.kw_defaults]:
                if isinstance(d, (ast.List, ast.Dict, ast.Set)):
                    notes.append(f"Line {n.lineno}: `{n.name}` has a list/dict/set as a default argument. It is shared between calls; use `None` and create it inside.")
            if not ast.get_docstring(n):
                missing_doc += 1
            span = (n.end_lineno or n.lineno) - n.lineno + 1
            if span > 40:
                notes.append(f"Line {n.lineno}: `{n.name}` is {span} lines long. Splitting it into smaller functions makes it easier to read and test.")
        elif isinstance(n, ast.Compare):
            for op, c in zip(n.ops, n.comparators):
                if isinstance(op, (ast.Eq, ast.NotEq)) and isinstance(c, ast.Constant) and c.value is None:
                    notes.append(f"Line {n.lineno}: compare with None using `is None` / `is not None`, not `==`.")
                if isinstance(op, (ast.Eq, ast.NotEq)) and isinstance(c, ast.Constant) and isinstance(c.value, bool):
                    notes.append(f"Line {n.lineno}: `== {c.value}` is not needed; use the value directly (`if x:`).")
        elif isinstance(n, ast.For) and isinstance(n.iter, ast.Call) and _call_name(n.iter) == "range" \
                and n.iter.args and _call_name(n.iter.args[0]) == "len":
            notes.append(f"Line {n.lineno}: `for i in range(len(x))` can usually be `for item in x` or `for i, item in enumerate(x)`.")
        elif isinstance(n, ast.Call) and _call_name(n) == "open" and id(n) not in with_items:
            notes.append(f"Line {n.lineno}: use `with open(...) as f:` so the file is always closed.")
    if missing_doc:
        notes.append(f"{missing_doc} function(s) have no docstring. Tap Docstrings to get suggestions.")
    if not notes:
        return "I checked for unused imports, bare except, shared default arguments, `== None`, loops over range(len(...)), unclosed files and very long functions. Nothing to report."
    seen: dict[str, None] = {}
    for x in notes:
        seen.setdefault(x, None)
    return "Suggestions (checked by rules, so I cannot judge whether your logic is right):\n\n" + "\n".join(f"• {x}" for x in list(seen)[:30])


def _functions(tree: ast.Module) -> list[tuple[str | None, ast.FunctionDef]]:
    found: list[tuple[str | None, ast.FunctionDef]] = []
    for n in tree.body:
        if isinstance(n, ast.FunctionDef):
            found.append((None, n))
        elif isinstance(n, ast.ClassDef):
            found += [(n.name, m) for m in n.body if isinstance(m, ast.FunctionDef)]
    return found


def tests(source: str, module: str) -> str:
    try:
        tree = ast.parse(source)
    except SyntaxError as e:
        return f"Fix the syntax error on line {e.lineno} first ({e.msg}); then I can write a test skeleton."
    funcs = [(c, f) for c, f in _functions(tree) if not f.name.startswith("_") and c is None]
    if not funcs:
        return "I found no top-level functions to test. Put your logic in functions (def name(...):) and tap Tests again."
    mod = re.sub(r"[^A-Za-z0-9_]", "_", module.rsplit("/", 1)[-1].removesuffix(".py")) or "main"
    lines = ["import unittest", f"from {mod} import " + ", ".join(f.name for _, f in funcs), "", "",
             "class TestFunctions(unittest.TestCase):"]
    for _, f in funcs:
        defaults = {a.arg: _short(d) for a, d in zip(reversed(f.args.args), reversed(f.args.defaults))}
        args = ", ".join(defaults.get(a.arg, "0") for a in f.args.args)
        lines += [f"    def test_{f.name}(self):", f"        result = {f.name}({args})",
                  "        self.assertEqual(result, None)  # TODO: replace None with the value you expect", ""]
    lines += ["", "if __name__ == '__main__':", "    unittest.main()"]
    return ("Test skeleton. I cannot know what your functions should return, so every test has a TODO. Save it as a new file "
            "(for example test_" + mod + ".py), replace the example inputs and expected values, then run it.\n\n" + "\n".join(lines))


def docstrings(source: str) -> str:
    try:
        tree = ast.parse(source)
    except SyntaxError as e:
        return f"Fix the syntax error on line {e.lineno} first ({e.msg})."
    out: list[str] = []
    for n in ast.walk(tree):
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and not ast.get_docstring(n):
            args = [a.arg for a in n.args.args if a.arg not in ("self", "cls")]
            doc = ["    \"\"\"Describe what " + n.name + " does in one line.", ""]
            if args:
                doc += ["    Args:"] + [f"        {a}: what {a} means." for a in args] + [""]
            if any(isinstance(x, ast.Return) and x.value is not None for x in ast.walk(n)):
                doc += ["    Returns:", "        what the function gives back.", ""]
            if doc[-1] == "":
                doc.pop()
            doc.append("    \"\"\"")
            out.append(f"Under line {n.lineno} (def {n.name}):\n" + "\n".join(doc))
        elif isinstance(n, ast.ClassDef) and not ast.get_docstring(n):
            out.append(f"Under line {n.lineno} (class {n.name}):\n    \"\"\"Describe what a {n.name} is.\"\"\"")
    if not out:
        return "Every function and class already has a docstring."
    return "Docstring templates. I cannot know what your code is for, so fill in the descriptions:\n\n" + "\n\n".join(out[:20])


# ------------------------------------------------------------------ questions
_KB: list[tuple[tuple[str, ...], str]] = [
    (("input", "user type", "ask the user", "keyboard"),
     "input() waits for the user to type and gives back TEXT.\n\nname = input('Your name: ')\nage = int(input('Your age: '))  # int() turns the text into a number\n\nWhile the script runs, type into the box at the bottom of the Run page and tap Send."),
    (("print", "show", "display", "output"),
     "print() shows values on the Run page.\n\nprint('Hello')\nprint('Total:', 5 + 3)\nname = 'Sam'\nprint(f'Hi {name}')  # f-strings put variables inside text"),
    (("list", "array", "append"),
     "A list holds items in order.\n\nnums = [3, 1, 2]\nnums.append(5)      # add at the end\nprint(nums[0])      # first item (positions start at 0)\nprint(len(nums))    # how many items\nnums.sort()         # sorts in place and returns None"),
    (("dict", "dictionary", "key value"),
     "A dictionary maps keys to values.\n\nage = {'Sam': 20, 'Ali': 22}\nage['Zed'] = 19\nprint(age['Sam'])\nprint(age.get('Nobody'))   # None instead of an error\nfor name, years in age.items():\n    print(name, years)"),
    (("for loop", "loop", "repeat", "iterate", "while"),
     "for repeats once per item; while repeats as long as a condition is true.\n\nfor i in range(3):      # 0, 1, 2\n    print(i)\n\nn = 3\nwhile n > 0:\n    print(n)\n    n -= 1             # without this the loop never ends"),
    (("function", "def ", "return"),
     "A function is a named block of code you can reuse.\n\ndef add(a, b):\n    return a + b\n\nprint(add(2, 3))   # 5\n\nreturn gives a value back. A function without return gives back None."),
    (("class", "object", "self", "__init__"),
     "A class is a blueprint for objects.\n\nclass Dog:\n    def __init__(self, name):\n        self.name = name\n    def bark(self):\n        print(self.name, 'says woof')\n\nd = Dog('Rex')\nd.bark()"),
    (("if", "else", "elif", "condition"),
     "if chooses what runs.\n\nx = 5\nif x > 10:\n    print('big')\nelif x > 3:\n    print('medium')\nelse:\n    print('small')\n\nUse == to compare and = to store."),
    (("try", "except", "catch", "handle error"),
     "try/except keeps the script from stopping when something fails.\n\ntry:\n    n = int(input('Number: '))\nexcept ValueError:\n    print('That was not a number')"),
    (("file", "read file", "write file", "open("),
     "Use with so the file always closes.\n\nwith open('notes.txt', 'w') as f:\n    f.write('hello')\nwith open('notes.txt') as f:\n    print(f.read())\n\nFiles live inside your project folder."),
    (("import", "module", "library", "package", "pip"),
     "import loads code from a module.\n\nimport math\nprint(math.sqrt(16))\n\nThis app cannot pip install while running. Packages are bundled at build time; see Tools → Packages. OpenCV, SciPy and scikit-learn run with the PACKS button."),
    (("string", "text", "format", "f-string", "upper", "split"),
     "Strings are text.\n\ns = 'Hello World'\nprint(s.upper(), s.lower(), len(s))\nprint(s.split())          # ['Hello', 'World']\nprint(s[0:5])             # 'Hello'\nprint(f'{s} has {len(s)} letters')"),
    (("comprehension", "list comprehension"),
     "A list comprehension builds a list in one line.\n\nsquares = [n * n for n in range(5)]        # [0, 1, 4, 9, 16]\nevens = [n for n in range(10) if n % 2 == 0]"),
    (("random",), "import random\nprint(random.randint(1, 6))       # whole number from 1 to 6\nprint(random.choice(['a', 'b']))"),
    (("sort", "sorted", "order"),
     "nums = [3, 1, 2]\nprint(sorted(nums))                 # new sorted list\nnums.sort(reverse=True)             # changes nums\nprint(sorted(['b', 'a'], key=len))"),
    (("int", "float", "convert", "number"),
     "int('5') -> 5, float('2.5') -> 2.5, str(5) -> '5'. Text from input() must be converted before doing maths. int('abc') raises ValueError."),
    (("slice", "slicing"), "s = 'abcdef'\nprint(s[1:4])   # 'bcd'\nprint(s[:2])    # 'ab'\nprint(s[-1])    # 'f'\nprint(s[::-1])  # reversed"),
    (("lambda",), "A lambda is a tiny unnamed function: square = lambda x: x * x. Often used as a key: sorted(words, key=lambda w: len(w))."),
    (("recursion", "recursive"), "A recursive function calls itself and needs a case that stops.\n\ndef fact(n):\n    if n <= 1:\n        return 1\n    return n * fact(n - 1)"),
]
_ERROR_NAME = re.compile(r"\b([A-Z][A-Za-z]*(?:Error|Exception|Interrupt))\b")


def _looks_like_code(text: str) -> bool:
    if not re.search(r"[=()\[\]{}:]|^\s*(import|from|def|class|for|while|if|print)\b", text, re.M):
        return False
    try:
        ast.parse(text)
        return True
    except SyntaxError:
        return False


def answer(question: str, source: str) -> str:
    q = question.strip()
    if not q:
        return "Type a question, paste a line of code to have it explained, or an error name like ZeroDivisionError."
    if len(q) > MAX_SOURCE:
        return "That is too long. Paste a smaller piece."
    if _looks_like_code(q):
        return explain(q)
    m = _ERROR_NAME.search(q)
    if m:
        d = diagnose(source, m.group(1), "", 0)
        return f"{d['title']}.\n{d['explanation']}\n" + "\n".join(f"• {s}" for s in d["steps"])
    low = q.lower()
    scored = sorted(((sum(1 for k in keys if k in low), ans) for keys, ans in _KB), key=lambda t: -t[0])
    if scored and scored[0][0] > 0:
        return scored[0][1]
    return ("I can't answer that one offline. I can: explain code (select it, or paste it here), find and fix errors, review code, "
            "write a test skeleton, suggest docstrings, and answer basic Python questions (lists, loops, functions, files, input, errors…). "
            "Try asking about one of those.")


def assist(kind: str, source: str, selection: str, question: str, last_error: dict | None, module: str) -> dict[str, Any]:
    code = selection if selection.strip() else source
    if len(code) > MAX_SOURCE:
        return {"text": "That file is too large for the offline assistant.", "fix": None}
    if kind == "explain":
        return {"text": explain(code), "fix": None}
    if kind == "fix":
        return fix(source, last_error)
    if kind == "improve":
        return {"text": improve(code), "fix": None}
    if kind == "tests":
        return {"text": tests(source, module), "fix": None}
    if kind == "docstring":
        return {"text": docstrings(source), "fix": None}
    return {"text": answer(question, source), "fix": None}
