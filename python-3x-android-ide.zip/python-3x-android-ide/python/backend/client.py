"""Supabase client (GoTrue auth + PostgREST) using only the PUBLIC anon key.

Security model: the anon key is public by design; every table is protected by row-level security
on the server. The service-role key is never used or accepted here. Tokens are passed per call and
stored by the Kotlin side in the Android Keystore, never here.
"""

from __future__ import annotations

import json
import re
from typing import Any
from urllib.parse import quote, urlparse

from netutil import HttpClient, NetError, Response

_EMAIL = re.compile(r"^[^@\s]{1,64}@[^@\s]{1,255}\.[^@\s]{2,}$")
_HOST = re.compile(r"^[a-z0-9-]{3,63}\.supabase\.(co|in)$")


class BackendError(ValueError):
    pass


def normalize_url(url: str) -> str:
    url = (url or "").strip().rstrip("/")
    p = urlparse(url)
    if p.scheme != "https" or not _HOST.match(p.hostname or "") or p.path or p.port or p.username:
        raise BackendError("The backend address must look like https://<project>.supabase.co")
    return f"https://{p.hostname}"


class SupabaseClient:
    def __init__(self, url: str, anon_key: str, http: HttpClient | None = None):
        self.url = normalize_url(url)
        anon_key = (anon_key or "").strip()
        if not anon_key or any(c.isspace() for c in anon_key):
            raise BackendError("Backend public key is missing.")
        if _is_service_role(anon_key):
            raise BackendError("A service-role key was supplied. Refusing: use only the public anon key.")
        self._key = anon_key
        self.http = http or HttpClient({urlparse(self.url).hostname})

    # ----------------------------------------------------------------- core
    def _headers(self, token: str | None, body: bool, extra: dict | None = None) -> dict:
        h = {"apikey": self._key, "Authorization": f"Bearer {token or self._key}", "Accept": "application/json"}
        if body:
            h["Content-Type"] = "application/json"
        h.update(extra or {})
        return h

    @staticmethod
    def _fail(resp: Response) -> BackendError:
        try:
            d = json.loads(resp.body or b"{}")
            msg = d.get("msg") or d.get("message") or d.get("error_description") or d.get("error") or ""
        except (ValueError, AttributeError):
            msg = ""
        if resp.status in (401, 403):
            return BackendError(msg or "Not allowed. Please sign in again.")
        if resp.status == 429:
            return BackendError("Too many requests. Please wait a moment and try again.")
        if resp.status >= 500:
            return BackendError("The backend is having trouble. Try again later.")
        return BackendError(msg or f"Backend error {resp.status}.")

    def _call(self, method: str, path: str, payload: Any = None, token: str | None = None, extra: dict | None = None) -> Any:
        body = json.dumps(payload).encode() if payload is not None else None
        try:
            resp = self.http.request(method, self.url + path, self._headers(token, body is not None, extra), body)
        except NetError as exc:
            raise BackendError(f"Could not reach the backend: {exc}") from exc
        if resp.status not in (200, 201, 204):
            raise self._fail(resp)
        if not resp.body:
            return None
        try:
            return json.loads(resp.body)
        except ValueError as exc:
            raise BackendError("The backend sent an unreadable answer.") from exc

    # ----------------------------------------------------------------- auth
    @staticmethod
    def _check_credentials(email: str, password: str) -> tuple[str, str]:
        email = (email or "").strip().lower()
        if not _EMAIL.match(email):
            raise BackendError("Enter a valid email address.")
        if len(password or "") < 8:
            raise BackendError("Password must be at least 8 characters.")
        return email, password

    @staticmethod
    def _session(d: dict, now: float = 0) -> dict:
        user = d.get("user") or {}
        return {
            "access_token": d["access_token"],
            "refresh_token": d.get("refresh_token", ""),
            "expires_in": int(d.get("expires_in", 3600)),
            "user_id": user.get("id", ""),
            "email": user.get("email", ""),
        }

    def sign_up(self, email: str, password: str) -> dict:
        email, password = self._check_credentials(email, password)
        d = self._call("POST", "/auth/v1/signup", {"email": email, "password": password})
        if isinstance(d, dict) and d.get("access_token"):
            return {"needs_confirmation": False, **self._session(d)}
        return {"needs_confirmation": True, "email": email}

    def sign_in(self, email: str, password: str) -> dict:
        email, password = self._check_credentials(email, password)
        try:
            d = self._call("POST", "/auth/v1/token?grant_type=password", {"email": email, "password": password})
        except BackendError as exc:
            if "invalid" in str(exc).lower():
                raise BackendError("Wrong email or password, or the email is not confirmed yet.") from exc
            raise
        return self._session(d)

    def refresh(self, refresh_token: str) -> dict:
        if not refresh_token:
            raise BackendError("Please sign in again.")
        d = self._call("POST", "/auth/v1/token?grant_type=refresh_token", {"refresh_token": refresh_token})
        return self._session(d)

    def sign_out(self, access_token: str) -> None:
        try:
            self._call("POST", "/auth/v1/logout", None, access_token)
        except BackendError:
            pass  # local sign-out still happens

    # ------------------------------------------------------------ data (RLS)
    def my_profile(self, access_token: str, user_id: str) -> dict:
        rows = self._call("GET", f"/rest/v1/profiles?id=eq.{quote(user_id, safe='')}&select=email,role", None, access_token)
        if not rows:
            return {"email": "", "role": "user"}
        return {"email": rows[0].get("email", ""), "role": rows[0].get("role", "user")}

    def get_ads_config(self) -> dict | None:
        """Ads settings are public-readable (no secrets in them: unit ids are public identifiers)."""
        rows = self._call("GET", "/rest/v1/app_settings?key=eq.ads&select=value")
        return rows[0]["value"] if rows else None

    def set_ads_config(self, access_token: str, cfg: dict) -> None:
        self._call(
            "POST", "/rest/v1/app_settings?on_conflict=key", {"key": "ads", "value": cfg}, access_token,
            {"Prefer": "resolution=merge-duplicates,return=minimal"},
        )

    def admin_stats(self, access_token: str) -> dict:
        d = self._call("POST", "/rest/v1/rpc/admin_stats", {}, access_token)
        return d if isinstance(d, dict) else {}

    def log_event(self, access_token: str | None, name: str) -> None:
        if not re.match(r"^[a-z_]{1,40}$", name or ""):
            raise BackendError("Invalid event name.")
        self._call("POST", "/rest/v1/events", {"name": name}, access_token, {"Prefer": "return=minimal"})


def _is_service_role(key: str) -> bool:
    """Detect a service_role JWT (payload role claim) so it can never be used by mistake."""
    import base64

    parts = key.split(".")
    if len(parts) != 3:
        return key.startswith("sb_secret_")
    try:
        pad = parts[1] + "=" * (-len(parts[1]) % 4)
        return json.loads(base64.urlsafe_b64decode(pad)).get("role") == "service_role"
    except (ValueError, TypeError):
        return False
