"""Small HTTPS client used by the GitHub and AI features.

Rules: HTTPS only, a fixed host allow-list per caller, bounded response size, redirects followed only to
allowed hosts (the Authorization header is dropped when the host changes). The transport is injectable so
tests never touch the network.
"""

from __future__ import annotations

import socket
import ssl
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from typing import Callable

MAX_RESPONSE_BYTES = 60 * 1024 * 1024
REDIRECT_CODES = {301, 302, 303, 307, 308}


class NetError(ValueError):
    """A network problem described for the person using the app."""


@dataclass
class Response:
    status: int
    headers: dict[str, str] = field(default_factory=dict)
    body: bytes = b""


Transport = Callable[[str, str, dict, "bytes | None", float, int], Response]


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):  # noqa: D401 - urllib hook
        return None


def default_transport(method: str, url: str, headers: dict, body: bytes | None, timeout: float, max_bytes: int) -> Response:
    request = urllib.request.Request(url, data=body, method=method, headers=headers)
    opener = urllib.request.build_opener(_NoRedirect, urllib.request.HTTPSHandler(context=ssl.create_default_context()))
    try:
        with opener.open(request, timeout=timeout) as resp:
            data = resp.read(max_bytes + 1)
            if len(data) > max_bytes:
                raise NetError("The response was too large.")
            return Response(resp.status, {k.lower(): v for k, v in resp.headers.items()}, data)
    except urllib.error.HTTPError as exc:  # non-2xx, including redirects (we disabled auto-follow)
        data = exc.read(max_bytes + 1) if exc.fp else b""
        return Response(exc.code, {k.lower(): v for k, v in exc.headers.items()}, data)
    except (urllib.error.URLError, socket.timeout, TimeoutError, ssl.SSLError, ConnectionError) as exc:
        reason = getattr(exc, "reason", exc)
        raise NetError(f"Could not reach the server ({reason}). Check your internet connection.") from exc


class HttpClient:
    def __init__(self, allowed_hosts: set[str] | None, transport: Transport | None = None, max_bytes: int = MAX_RESPONSE_BYTES):
        """``allowed_hosts=None`` allows any HTTPS host (used only for a user-chosen AI endpoint)."""
        self.allowed = allowed_hosts
        self.transport = transport or default_transport
        self.max_bytes = max_bytes

    def _check(self, url: str) -> str:
        parts = urllib.parse.urlsplit(url)
        if parts.scheme != "https" or not parts.hostname:
            raise NetError("Only HTTPS addresses are allowed.")
        host = parts.hostname.lower()
        if self.allowed is not None and host not in self.allowed:
            raise NetError(f"Connections to {host} are not allowed.")
        return host

    def request(self, method: str, url: str, headers: dict | None = None, body: bytes | None = None, timeout: float = 30) -> Response:
        headers = dict(headers or {})
        host = self._check(url)
        first_host = host
        for _ in range(4):
            resp = self.transport(method, url, headers, body, timeout, self.max_bytes)
            if resp.status not in REDIRECT_CODES:
                return resp
            location = resp.headers.get("location")
            if not location:
                return resp
            url = urllib.parse.urljoin(url, location)
            host = self._check(url)
            if host != first_host:
                headers.pop("Authorization", None)
                headers.pop("authorization", None)
            if resp.status == 303:
                method, body = "GET", None
        raise NetError("Too many redirects.")
