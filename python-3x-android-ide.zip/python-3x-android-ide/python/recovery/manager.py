"""Crash recovery.

``begin_session`` marks the session as running. A clean shutdown calls
``end_session``. If the next launch finds the marker still set, the previous
run ended unexpectedly. Independently of that, any draft that differs from the
file on disk is offered for recovery, so unsaved text is never silently lost.
"""

from __future__ import annotations

import difflib
from typing import Any

from autosave.service import AutosaveService
from projects.manager import ProjectManager
from projects.paths import PathError
from storage.db import Database

_KEY = "session_running"


class RecoveryManager:
    def __init__(self, db: Database, projects: ProjectManager, autosave: AutosaveService):
        self.db = db
        self.projects = projects
        self.autosave = autosave
        self.previous_session_crashed = False

    def begin_session(self) -> bool:
        """Call once at startup. Returns True if the previous session did not exit cleanly."""
        self.previous_session_crashed = self.db.get_setting(_KEY, "0") == "1"
        self.db.set_setting(_KEY, "1")
        return self.previous_session_crashed

    def end_session(self) -> None:
        self.db.set_setting(_KEY, "0")

    def scan(self) -> dict[str, Any]:
        """Describe what can be recovered. ``items`` only lists drafts with real changes."""
        items = []
        for draft in self.autosave.list_drafts():
            pid, rel = draft["project_id"], draft["rel"]
            if not self.autosave.has_unsaved_changes(pid, rel):
                self.autosave.discard_draft(pid, rel)  # identical to disk, nothing to recover
                continue
            items.append(draft)
        return {"crashed": self.previous_session_crashed, "items": items}

    def diff(self, project_id: int, rel: str) -> str:
        """Unified diff between the file on disk and the recovered draft."""
        draft = self.autosave.get_draft(project_id, rel)
        if draft is None:
            raise PathError("No draft for this file.")
        try:
            disk = self.projects.read_file(project_id, rel)["content"]
        except PathError:
            disk = ""
        lines = difflib.unified_diff(
            disk.splitlines(), draft["content"].splitlines(),
            fromfile=f"{rel} (on disk)", tofile=f"{rel} (recovered)", lineterm="",
        )
        return "\n".join(lines)

    def restore(self, project_id: int, rel: str) -> dict:
        """Write the recovered draft to disk (the old disk text is kept in history)."""
        draft = self.autosave.get_draft(project_id, rel)
        if draft is None:
            raise PathError("No draft for this file.")
        try:
            old = self.projects.read_file(project_id, rel)["content"]
            self.autosave._add_version(  # noqa: SLF001 - same package family
                project_id, rel.strip("/"), old,
                self.projects.read_file(project_id, rel)["hash"], "before_restore",
            )
        except PathError:
            pass
        return self.autosave.commit(project_id, rel, draft["content"], "restored_draft")

    def discard(self, project_id: int, rel: str) -> None:
        self.autosave.discard_draft(project_id, rel)
