"""Job runner for the companion "Python 3.x Packs" app (Python 3.10 + heavy native packages).

The main IDE sends a zip of the project plus a job description. This module unpacks it into a private
work folder, runs the job, and returns a zip of the files the job created or changed so the IDE can
copy them back. Nothing here talks to the network or to any other app: transport (Android IPC)
lives in Kotlin.

Job kinds
  script  arg = relative path of a .py file; runs it with the project as working directory.
  vision  arg = {"rel": image, "steps": [...], "out": output image}; OpenCV Studio processing.
"""

from __future__ import annotations

import json
import os
import shutil
import threading
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any, Callable

from projects.paths import PathError, resolve_inside
from runtime import ScriptRunner, default_backend
from vision import VisionError, VisionStudio

MAX_FILES = 5000
MAX_UNPACKED_BYTES = 200 * 1024 * 1024
MAX_RESULT_BYTES = 50 * 1024 * 1024
MAX_RESULT_FILES = 2000
SKIP_DIRS = {"__pycache__", ".py3x_trash", ".git"}


class JobError(ValueError):
    pass


def safe_extract(zip_path: Path, dest: Path, skip_dirs: set[str] | None = None) -> list[str]:
    """Extract with zip-slip, count and size limits. Returns the relative paths written."""
    written: list[str] = []
    dest.mkdir(parents=True, exist_ok=True)
    root = dest.resolve()
    total = 0
    with zipfile.ZipFile(zip_path) as zf:
        infos = [i for i in zf.infolist() if not i.is_dir()]
        if len(infos) > MAX_FILES:
            raise JobError(f"The project has more than {MAX_FILES} files.")
        for info in infos:
            name = info.filename.replace("\\", "/")
            parts = PurePosixPath(name).parts
            if name.startswith("/") or ".." in parts or not parts:
                raise JobError(f"Unsafe path in project archive: {info.filename!r}")
            total += info.file_size
            if total > MAX_UNPACKED_BYTES:
                raise JobError("The project is too large to send (limit 200 MB unpacked).")
            if skip_dirs and any(part in skip_dirs for part in parts):
                continue
            target = (root / name).resolve()
            if not target.is_relative_to(root):
                raise JobError(f"Unsafe path in project archive: {info.filename!r}")
            if skip_dirs is not None:
                resolve_inside(root, name)  # also rejects reserved names the IDE protects
            target.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(info) as src, open(target, "wb") as out:
                shutil.copyfileobj(src, out)
            written.append("/".join(parts))
    return written


def apply_result(zip_path: str | Path, project_dir: str | Path) -> list[str]:
    """Copy the files a Packs job produced back into a project folder (used by the main IDE)."""
    return safe_extract(Path(zip_path), Path(project_dir), skip_dirs=SKIP_DIRS)


def _snapshot(root: Path) -> dict[str, tuple[int, int]]:
    snap = {}
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for f in filenames:
            p = Path(dirpath) / f
            st = p.stat()
            snap[str(p.relative_to(root))] = (st.st_size, st.st_mtime_ns)
    return snap


def pack_changes(root: Path, before: dict[str, tuple[int, int]], out_zip: Path) -> list[str]:
    """Zip files that are new or modified since ``before``. Returns their relative paths."""
    changed = [rel for rel, sig in _snapshot(root).items() if before.get(rel) != sig]
    if len(changed) > MAX_RESULT_FILES:
        raise JobError(f"The job produced too many files ({len(changed)}).")
    total = sum((root / r).stat().st_size for r in changed)
    if total > MAX_RESULT_BYTES:
        raise JobError("The job's output files are too large to send back (limit 50 MB).")
    with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as zf:
        for rel in changed:
            zf.write(root / rel, rel)
    return changed


class PacksJobs:
    """One job at a time (phones are small); a second request while busy is refused clearly."""

    def __init__(self, work_root: Path, backend=None):
        self.work_root = Path(work_root)
        self.work_root.mkdir(parents=True, exist_ok=True)
        self._runner = ScriptRunner(backend or default_backend())
        self._lock = threading.Lock()
        self._busy = False
        self._cancel = False

    @property
    def busy(self) -> bool:
        return self._busy

    def start(
        self,
        job_id: str,
        zip_path: str | Path,
        kind: str,
        arg: Any,
        on_output: Callable[[str, str], None],
        on_finish: Callable[[dict], None],
        timeout: float | None = None,
    ) -> None:
        if not job_id or not job_id.replace("-", "").replace("_", "").isalnum():
            raise JobError("Invalid job id.")
        if kind not in ("script", "vision"):
            raise JobError(f"Unknown job kind '{kind}'.")
        with self._lock:
            if self._busy:
                raise JobError("The Packs app is already running a job.")
            self._busy = True
            self._cancel = False
        try:
            job_dir = self.work_root / job_id
            shutil.rmtree(job_dir, ignore_errors=True)
            safe_extract(Path(zip_path), job_dir)
            before = _snapshot(job_dir)
            threading.Thread(
                target=self._run, args=(job_id, job_dir, before, kind, arg, on_output, on_finish, timeout), daemon=True
            ).start()
        except Exception:
            with self._lock:
                self._busy = False
            raise

    def stop(self) -> None:
        self._cancel = True
        self._runner.stop()

    # ---------------------------------------------------------------- worker
    def _finish(self, job_dir: Path, before, job_id: str, on_finish, result: dict) -> None:
        result_zip = self.work_root / f"{job_id}-result.zip"
        try:
            changed = pack_changes(job_dir, before, result_zip)
            result["result_zip"] = str(result_zip) if changed else None
            result["changed"] = changed
        except JobError as exc:
            result.setdefault("error", str(exc))
            result["result_zip"] = None
            result["changed"] = []
        finally:
            with self._lock:
                self._busy = False
        try:
            on_finish(result)
        except Exception:  # noqa: BLE001 - the transport may already be gone
            pass

    def _run(self, job_id, job_dir, before, kind, arg, on_output, on_finish, timeout) -> None:
        result: dict[str, Any] = {"kind": kind, "exit_code": 1, "state": "failed"}
        try:
            if kind == "script":
                self._run_script(job_dir, str(arg), on_output, timeout, result)
            else:
                self._run_vision(job_dir, arg, result)
        except (JobError, PathError, VisionError) as exc:
            result["error"] = str(exc)
            on_output("stderr", f"{exc}\n")
        except Exception as exc:  # noqa: BLE001
            result["error"] = f"Unexpected error ({type(exc).__name__}): {exc}"
            on_output("stderr", result["error"] + "\n")
        self._finish(job_dir, before, job_id, on_finish, result)

    def _run_script(self, job_dir: Path, rel: str, on_output, timeout, result: dict) -> None:
        script = resolve_inside(job_dir, rel)
        if script.suffix != ".py" or not script.is_file():
            raise JobError("Choose an existing .py file to run.")
        done = threading.Event()
        holder: dict = {}

        def finished(r: dict) -> None:
            holder.update(r)
            done.set()

        self._runner.start(script, job_dir, (), on_output, None, finished, timeout)
        done.wait()
        result.update(
            exit_code=holder.get("exit_code"),
            state=holder.get("state", "failed"),
            duration=holder.get("duration", 0),
            stuck=bool(holder.get("stuck")),
        )
        if holder.get("error"):
            result["traceback"] = holder["error"]

    def _run_vision(self, job_dir: Path, arg: Any, result: dict) -> None:
        if not isinstance(arg, dict) or not all(k in arg for k in ("rel", "steps", "out")):
            raise JobError("Vision job needs rel, steps and out.")
        info = VisionStudio(job_dir).process(arg["rel"], arg["steps"], arg["out"])
        result.update(exit_code=0, state="completed", vision=info)

    def cleanup(self, job_id: str) -> None:
        if not job_id or not job_id.replace("-", "").replace("_", "").isalnum():
            return
        shutil.rmtree(self.work_root / job_id, ignore_errors=True)
        (self.work_root / f"{job_id}-result.zip").unlink(missing_ok=True)
