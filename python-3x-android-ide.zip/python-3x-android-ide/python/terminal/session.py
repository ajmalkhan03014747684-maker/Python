"""Integrated terminal.

A deliberately small, safe command set that works inside the app sandbox. It is
not a system shell: there is no ``sh``, no pipes and no access outside the
sessions root. ``python`` runs through the same runner as the editor's Run button.
"""

from __future__ import annotations

import importlib.metadata as md
import shlex
import sys
import tempfile
from pathlib import Path
from typing import Callable

from projects.paths import PathError, resolve_inside
from runtime.runner import RunResult, ScriptRunner

Emit = Callable[[str], None]
Done = Callable[[int], None]

MAX_CAT_BYTES = 200 * 1024
COMMANDS = ("cat", "cd", "clear", "echo", "help", "history", "ls", "mkdir", "pip", "pwd",
            "python", "python3", "touch")

HELP = """Python 3.x terminal. Commands:
  python [-c CODE | FILE [args]]   run Python (python3 is the same)
  pip list | show NAME | freeze    inspect installed packages
  ls [PATH]  cd PATH  pwd  cat FILE  mkdir DIR  touch FILE  echo TEXT
  history  clear  help
This is a sandboxed terminal, not a full shell: no pipes, no system commands."""

PIP_INSTALL_MSG = (
    "pip install/uninstall is not available in this build.\n"
    "Packages are bundled at build time on Android. See docs/packages.md.\n"
)


class TerminalSession:
    def __init__(self, root: str | Path, start: str | Path | None = None,
                 runner: ScriptRunner | None = None, scratch: str | Path | None = None):
        self.root = Path(root).resolve()
        self.cwd = Path(start).resolve() if start else self.root
        if self.root not in (self.cwd, *self.cwd.parents):
            self.cwd = self.root
        self.runner = runner or ScriptRunner()
        self.scratch = Path(scratch) if scratch else Path(tempfile.gettempdir())
        self.history: list[str] = []
        self.last_exit = 0

    # ---------------------------------------------------------------- public
    def prompt(self) -> str:
        rel = self.cwd.relative_to(self.root).as_posix()
        return f"~/{'' if rel == '.' else rel}$ "

    @property
    def busy(self) -> bool:
        return self.runner.is_running

    def interrupt(self) -> None:
        self.runner.stop()

    def send_input(self, text: str) -> None:
        self.runner.send_input(text)

    def execute(self, line: str, emit: Emit, done: Done) -> dict:
        """Run one command line. Output goes to ``emit``; ``done(exit_code)`` fires once.

        Returns ``{"clear": bool, "async": bool}``.
        """
        line = line.strip()
        if not line:
            done(self.last_exit)
            return {"clear": False, "async": False}
        if self.busy:
            emit("A command is still running. Stop it first.\n")
            done(1)
            return {"clear": False, "async": False}
        self.history = (self.history + [line])[-500:]
        try:
            argv = shlex.split(line)
        except ValueError as exc:
            emit(f"syntax error: {exc}\n")
            return self._finish(1, done)
        cmd, args = argv[0], argv[1:]
        try:
            if cmd in ("python", "python3"):
                return self._python(args, emit, done)
            handler = getattr(self, f"_cmd_{cmd}", None)
            if handler is None:
                emit(f"{cmd}: command not found. Type 'help'.\n")
                return self._finish(127, done)
            code = handler(args, emit)
            if cmd == "clear":
                self.last_exit = 0
                done(0)
                return {"clear": True, "async": False}
            return self._finish(code, done)
        except PathError as exc:
            emit(f"{cmd}: {exc}\n")
            return self._finish(1, done)

    def complete(self, line: str) -> list[str]:
        """Completion candidates for the last word of ``line``."""
        parts = line.split(" ")
        word = parts[-1]
        if len(parts) == 1:
            return [c for c in COMMANDS if c.startswith(word)]
        folder_part, _, stem = word.rpartition("/")
        try:
            base = resolve_inside(self.root, str(self._rel(folder_part)), allow_root=True) \
                if folder_part else self.cwd
        except PathError:
            return []
        if not base.is_dir():
            return []
        out = []
        for p in sorted(base.iterdir()):
            if p.name.startswith(stem) and not p.name.startswith(".py3x"):
                prefix = f"{folder_part}/" if folder_part else ""
                out.append(prefix + p.name + ("/" if p.is_dir() else ""))
        return out

    # --------------------------------------------------------------- helpers
    def _finish(self, code: int, done: Done) -> dict:
        self.last_exit = code
        done(code)
        return {"clear": False, "async": False}

    def _rel(self, path: str) -> Path:
        """Path relative to ``root`` for a user-typed path (relative to cwd)."""
        target = (self.cwd / path).resolve() if not path.startswith("/") else Path(path)
        if self.root != target and self.root not in target.parents:
            raise PathError("path is outside the sandbox")
        return target.relative_to(self.root)

    def _resolve(self, path: str) -> Path:
        rel = self._rel(path)
        if rel.as_posix() == ".":
            return self.root
        return resolve_inside(self.root, rel.as_posix(), allow_root=True)

    # -------------------------------------------------------------- commands
    def _cmd_help(self, args: list[str], emit: Emit) -> int:
        emit(HELP + "\n")
        return 0

    def _cmd_clear(self, args: list[str], emit: Emit) -> int:
        return 0

    def _cmd_pwd(self, args: list[str], emit: Emit) -> int:
        emit(f"{self.prompt()[:-2]}\n")
        return 0

    def _cmd_echo(self, args: list[str], emit: Emit) -> int:
        emit(" ".join(args) + "\n")
        return 0

    def _cmd_history(self, args: list[str], emit: Emit) -> int:
        for i, h in enumerate(self.history, 1):
            emit(f"{i:4}  {h}\n")
        return 0

    def _cmd_ls(self, args: list[str], emit: Emit) -> int:
        target = self._resolve(args[0] if args else ".")
        if target.is_file():
            emit(target.name + "\n")
            return 0
        if not target.is_dir():
            emit("ls: no such file or directory\n")
            return 1
        names = [
            p.name + ("/" if p.is_dir() else "")
            for p in sorted(target.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
            if not p.name.startswith(".py3x") and p.name != ".trash"
        ]
        emit(("  ".join(names) + "\n") if names else "")
        return 0

    def _cmd_cd(self, args: list[str], emit: Emit) -> int:
        target = self._resolve(args[0] if args else ".")
        if not target.is_dir():
            emit("cd: not a directory\n")
            return 1
        self.cwd = target
        return 0

    def _cmd_cat(self, args: list[str], emit: Emit) -> int:
        if not args:
            emit("cat: missing file\n")
            return 1
        code = 0
        for name in args:
            path = self._resolve(name)
            if not path.is_file():
                emit(f"cat: {name}: no such file\n")
                code = 1
            elif path.stat().st_size > MAX_CAT_BYTES:
                emit(f"cat: {name}: file too large for the terminal\n")
                code = 1
            else:
                try:
                    emit(path.read_text(encoding="utf-8"))
                except UnicodeDecodeError:
                    emit(f"cat: {name}: not a text file\n")
                    code = 1
        return code

    def _cmd_mkdir(self, args: list[str], emit: Emit) -> int:
        if not args:
            emit("mkdir: missing name\n")
            return 1
        self._resolve(args[0]).mkdir(parents=True, exist_ok=True)
        return 0

    def _cmd_touch(self, args: list[str], emit: Emit) -> int:
        if not args:
            emit("touch: missing name\n")
            return 1
        self._resolve(args[0]).touch()
        return 0

    def _cmd_pip(self, args: list[str], emit: Emit) -> int:
        sub = args[0] if args else "--help"
        if sub in ("list", "freeze"):
            dists = sorted(
                ((d.metadata["Name"] or "?", d.version) for d in md.distributions()),
                key=lambda t: t[0].lower(),
            )
            for name, version in dists:
                emit(f"{name}=={version}\n" if sub == "freeze" else f"{name:32} {version}\n")
            return 0
        if sub == "show" and len(args) > 1:
            try:
                meta = md.metadata(args[1])
            except md.PackageNotFoundError:
                emit(f"WARNING: Package(s) not found: {args[1]}\n")
                return 1
            for key in ("Name", "Version", "Summary", "Home-page", "License", "Requires-Dist"):
                for value in meta.get_all(key) or []:
                    emit(f"{key}: {value}\n")
            return 0
        if sub == "--version":
            emit(f"pip (Python 3.x terminal) on Python {sys.version.split()[0]}\n")
            return 0
        if sub in ("install", "uninstall", "download"):
            emit(PIP_INSTALL_MSG)
            return 1
        emit("usage: pip list | freeze | show NAME | --version\n")
        return 0 if sub == "--help" else 2

    # ---------------------------------------------------------------- python
    def _python(self, args: list[str], emit: Emit, done: Done) -> dict:
        if not args:
            emit("Interactive REPL is not available yet. Use: python FILE  or  python -c CODE\n")
            return self._finish(2, done)
        if args[0] in ("--version", "-V"):
            emit(f"Python {sys.version.split()[0]}\n")
            return self._finish(0, done)
        if args[0] == "-c":
            if len(args) < 2:
                emit("python: -c requires code\n")
                return self._finish(2, done)
            self.scratch.mkdir(parents=True, exist_ok=True)
            script = self.scratch / "terminal_snippet.py"
            script.write_text(args[1] + "\n", encoding="utf-8")
            rest: tuple[str, ...] = tuple(args[2:])
        else:
            script = self._resolve(args[0])
            rest = tuple(args[1:])
            if not script.is_file():
                emit(f"python: can't open file '{args[0]}'\n")
                return self._finish(2, done)

        def on_output(_stream: str, text: str) -> None:
            emit(text)

        def on_finish(result: dict) -> None:
            code = result["exit_code"] if result["exit_code"] is not None else 1
            if result["state"] == "stopped":
                emit("^C\n")
                code = 130
            self.last_exit = code
            done(code)

        self.runner.start(script, self.cwd, rest, on_output=on_output, on_finish=on_finish)
        return {"clear": False, "async": True}


def result_summary(result: RunResult) -> str:
    return f"{result.state.value} (exit {result.exit_code}) in {result.duration:.2f}s"
