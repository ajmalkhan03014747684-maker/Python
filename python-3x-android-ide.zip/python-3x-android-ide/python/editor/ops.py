"""Pure text-editing operations used by the editor toolbar.

Every function takes plain text and a selection (``start``, ``end`` offsets)
and returns ``(new_text, new_start, new_end)``. No UI, no I/O, easy to test.
Per-keystroke work (typing, undo stack, highlighting) lives in the Kotlin UI;
these operations run when a toolbar button is tapped.
"""

from __future__ import annotations

import re
from typing import Iterator

Edit = tuple[str, int, int]

_OPEN, _CLOSE = "([{", ")]}"
_PAIRS = {"(": ")", "[": "]", "{": "}"}
_DEDENT_KEYWORDS = ("return", "break", "continue", "pass", "raise")


def _clamp(text: str, start: int, end: int) -> tuple[int, int]:
    n = len(text)
    start, end = max(0, min(start, n)), max(0, min(end, n))
    return (start, end) if start <= end else (end, start)


def _line_span(text: str, start: int, end: int) -> tuple[int, int]:
    """Start of the first selected line and end (before newline) of the last."""
    first = text.rfind("\n", 0, start) + 1
    probe = end - 1 if end > start and text[end - 1 : end] == "\n" else end
    last = text.find("\n", probe)
    return first, len(text) if last == -1 else last


def indent_unit(use_spaces: bool = True, tab_width: int = 4) -> str:
    return " " * tab_width if use_spaces else "\t"


# --------------------------------------------------------------- selection
def select_all(text: str) -> tuple[int, int]:
    return 0, len(text)


# ------------------------------------------------------ line transformations
def toggle_comment(text: str, start: int, end: int) -> Edit:
    start, end = _clamp(text, start, end)
    ls, le = _line_span(text, start, end)
    lines = text[ls:le].split("\n")
    content = [ln for ln in lines if ln.strip()]
    if not content:
        return text, start, end
    if all(ln.lstrip().startswith("#") for ln in content):
        new_lines = []
        for ln in lines:
            stripped = ln.lstrip()
            if stripped.startswith("#"):
                pad = ln[: len(ln) - len(stripped)]
                rest = stripped[1:]
                rest = rest[1:] if rest.startswith(" ") else rest
                ln = pad + rest
            new_lines.append(ln)
    else:
        pad = min(len(ln) - len(ln.lstrip()) for ln in content)
        new_lines = [
            ln if not ln.strip() else ln[:pad] + "# " + ln[pad:] for ln in lines
        ]
    return _apply_lines(text, ls, le, lines, new_lines, start, end)


def indent(text: str, start: int, end: int, use_spaces: bool = True, tab_width: int = 4) -> Edit:
    start, end = _clamp(text, start, end)
    unit = indent_unit(use_spaces, tab_width)
    ls, le = _line_span(text, start, end)
    lines = text[ls:le].split("\n")
    new_lines = [unit + ln if ln.strip() else ln for ln in lines]
    return _apply_lines(text, ls, le, lines, new_lines, start, end)


def outdent(text: str, start: int, end: int, use_spaces: bool = True, tab_width: int = 4) -> Edit:
    start, end = _clamp(text, start, end)
    ls, le = _line_span(text, start, end)
    lines = text[ls:le].split("\n")
    new_lines = []
    for ln in lines:
        if ln.startswith("\t"):
            ln = ln[1:]
        else:
            strip = min(tab_width, len(ln) - len(ln.lstrip(" ")))
            ln = ln[strip:]
        new_lines.append(ln)
    return _apply_lines(text, ls, le, lines, new_lines, start, end)


def _apply_lines(
    text: str, ls: int, le: int, old: list[str], new: list[str], start: int, end: int
) -> Edit:
    out = text[:ls] + "\n".join(new) + text[le:]
    first_delta = len(new[0]) - len(old[0])
    total_delta = sum(len(n) - len(o) for n, o in zip(new, old, strict=True))
    new_start = max(ls, start + first_delta) if start != ls else ls
    new_end = max(new_start, end + total_delta)
    return out, min(new_start, len(out)), min(new_end, len(out))


def duplicate_line(text: str, start: int, end: int) -> Edit:
    start, end = _clamp(text, start, end)
    ls, le = _line_span(text, start, end)
    block = text[ls:le]
    out = text[:le] + "\n" + block + text[le:]
    shift = len(block) + 1
    return out, start + shift, end + shift


def delete_line(text: str, start: int, end: int) -> Edit:
    start, end = _clamp(text, start, end)
    ls, le = _line_span(text, start, end)
    if le < len(text):  # remove the trailing newline too
        out = text[:ls] + text[le + 1 :]
        return out, ls, ls
    if ls > 0:  # last line: remove the preceding newline instead
        out = text[: ls - 1]
        return out, ls - 1, ls - 1
    return "", 0, 0


def move_lines(text: str, start: int, end: int, direction: int) -> Edit:
    """Move the selected lines up (-1) or down (+1)."""
    start, end = _clamp(text, start, end)
    ls, le = _line_span(text, start, end)
    lines = text.split("\n")
    first = text.count("\n", 0, ls)
    last = text.count("\n", 0, le)
    if direction < 0 and first == 0 or direction > 0 and last >= len(lines) - 1:
        return text, start, end
    block = lines[first : last + 1]
    if direction < 0:
        neighbour = lines[first - 1]
        lines[first - 1 : last + 1] = block + [neighbour]
        delta = -(len(neighbour) + 1)
    else:
        neighbour = lines[last + 1]
        lines[first : last + 2] = [neighbour] + block
        delta = len(neighbour) + 1
    return "\n".join(lines), start + delta, end + delta


# ---------------------------------------------------------------- auto-indent
def _strip_comment(line: str) -> str:
    quote = None
    i = 0
    while i < len(line):
        ch = line[i]
        if quote:
            if ch == "\\":
                i += 1
            elif ch == quote:
                quote = None
        elif ch in "'\"":
            quote = ch
        elif ch == "#":
            return line[:i]
        i += 1
    return line


def auto_indent(line_before_cursor: str, use_spaces: bool = True, tab_width: int = 4) -> str:
    """Whitespace to insert after Enter, given the text of the line before the cursor."""
    unit = indent_unit(use_spaces, tab_width)
    current = line_before_cursor[: len(line_before_cursor) - len(line_before_cursor.lstrip())]
    code = _strip_comment(line_before_cursor).rstrip()
    if code.endswith(":") or code.endswith(tuple(_OPEN)):
        return current + unit
    word = code.strip().split(" ", 1)[0].split("(", 1)[0]
    if word in _DEDENT_KEYWORDS and current.endswith(unit):
        return current[: -len(unit)]
    return current


# ----------------------------------------------------------- bracket matching
def _scan_brackets(text: str) -> Iterator[tuple[int, str]]:
    """Yield (index, char) for every bracket outside strings and comments."""
    i, n = 0, len(text)
    while i < n:
        ch = text[i]
        if ch == "#":
            nl = text.find("\n", i)
            i = n if nl == -1 else nl
            continue
        if ch in "'\"":
            triple = text.startswith(ch * 3, i)
            end_quote = ch * 3 if triple else ch
            i += 3 if triple else 1
            while i < n:
                if text[i] == "\\":
                    i += 2
                    continue
                if text.startswith(end_quote, i):
                    i += len(end_quote)
                    break
                if not triple and text[i] == "\n":
                    break
                i += 1
            continue
        if ch in _OPEN or ch in _CLOSE:
            yield i, ch
        i += 1


def match_bracket(text: str, pos: int, max_chars: int = 200_000) -> tuple[int, int] | None:
    """Matching bracket pair for the bracket at ``pos`` or just before it."""
    if len(text) > max_chars:
        return None
    pairs: dict[int, int] = {}
    stack: list[tuple[int, str]] = []
    for idx, ch in _scan_brackets(text):
        if ch in _OPEN:
            stack.append((idx, ch))
        elif stack and _PAIRS[stack[-1][1]] == ch:
            opener, _ = stack.pop()
            pairs[opener] = idx
            pairs[idx] = opener
    for candidate in (pos, pos - 1):
        if candidate in pairs:
            return candidate, pairs[candidate]
    return None


# ------------------------------------------------------------------- search
def _pattern(query: str, case_sensitive: bool, regex: bool, whole_word: bool) -> re.Pattern[str]:
    if not query:
        raise ValueError("Search text is empty.")
    body = query if regex else re.escape(query)
    if whole_word:
        body = rf"(?<!\w)(?:{body})(?!\w)"
    flags = re.MULTILINE | (0 if case_sensitive else re.IGNORECASE)
    try:
        return re.compile(body, flags)
    except re.error as exc:
        raise ValueError(f"Invalid pattern: {exc}") from exc


def find_all(
    text: str, query: str, case_sensitive: bool = False, regex: bool = False,
    whole_word: bool = False, limit: int = 5000,
) -> list[tuple[int, int]]:
    pat = _pattern(query, case_sensitive, regex, whole_word)
    found = []
    for m in pat.finditer(text):
        if m.end() == m.start():
            continue
        found.append((m.start(), m.end()))
        if len(found) >= limit:
            break
    return found


def find_next(
    text: str, query: str, pos: int, forward: bool = True, wrap: bool = True, **opts
) -> tuple[int, int] | None:
    matches = find_all(text, query, **opts)
    if not matches:
        return None
    if forward:
        for m in matches:
            if m[0] >= pos:
                return m
        return matches[0] if wrap else None
    for m in reversed(matches):
        if m[0] < pos:
            return m
    return matches[-1] if wrap else None


def replace_next(
    text: str, query: str, replacement: str, pos: int, case_sensitive: bool = False,
    regex: bool = False, whole_word: bool = False,
) -> tuple[str, int, bool]:
    """Replace the first match at or after ``pos``. Returns (text, new_pos, replaced)."""
    pat = _pattern(query, case_sensitive, regex, whole_word)
    for m in pat.finditer(text):
        if m.start() >= pos and m.end() > m.start():
            new = _expand(m, replacement, regex)
            return text[: m.start()] + new + text[m.end() :], m.start() + len(new), True
    return text, pos, False


def replace_all(
    text: str, query: str, replacement: str, case_sensitive: bool = False,
    regex: bool = False, whole_word: bool = False,
) -> tuple[str, int]:
    pat = _pattern(query, case_sensitive, regex, whole_word)
    count = 0

    def sub(m: re.Match[str]) -> str:
        nonlocal count
        if m.end() == m.start():
            return m.group(0)
        count += 1
        return _expand(m, replacement, regex)

    return pat.sub(sub, text), count


def _expand(m: re.Match[str], replacement: str, regex: bool) -> str:
    if not regex:
        return replacement
    try:
        return m.expand(replacement)
    except (re.error, IndexError) as exc:
        raise ValueError(f"Invalid replacement: {exc}") from exc


# ----------------------------------------------------------------- positions
def goto_line(text: str, line: int) -> int:
    """Offset of the start of 1-based ``line`` (clamped to the document)."""
    line = max(1, line)
    offset = 0
    for _ in range(line - 1):
        nl = text.find("\n", offset)
        if nl == -1:
            break
        offset = nl + 1
    return offset


def line_col(text: str, pos: int) -> tuple[int, int]:
    pos = max(0, min(pos, len(text)))
    line = text.count("\n", 0, pos) + 1
    col = pos - (text.rfind("\n", 0, pos) + 1)
    return line, col
