"""Syntax diagnostics for the editor's error highlighting."""

from __future__ import annotations

import ast
from typing import Any

MAX_CHARS = 1_000_000


def check_syntax(text: str, filename: str = "<editor>") -> list[dict[str, Any]]:
    """Return a list of syntax problems (empty if the code parses)."""
    if len(text) > MAX_CHARS:
        return []
    try:
        ast.parse(text, filename=filename)
    except SyntaxError as exc:
        line = exc.lineno or 1
        col = max((exc.offset or 1) - 1, 0)
        return [
            {
                "line": line,
                "col": col,
                "end_line": exc.end_lineno or line,
                "end_col": max((exc.end_offset or exc.offset or 1) - 1, col + 1),
                "message": exc.msg,
                "severity": "error",
            }
        ]
    except ValueError as exc:  # e.g. null bytes
        return [
            {"line": 1, "col": 0, "end_line": 1, "end_col": 1, "message": str(exc), "severity": "error"}
        ]
    return []
