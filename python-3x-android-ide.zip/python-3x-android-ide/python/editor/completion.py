"""Autocomplete suggestions: keywords, builtins, names in the buffer and module members."""

from __future__ import annotations

import builtins
import importlib
import keyword
import re
import sys
from typing import Any

_IDENT = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")
_PREFIX_AT_END = re.compile(r"([A-Za-z_][A-Za-z0-9_]*)?$")
_MEMBER_CTX = re.compile(r"([A-Za-z_][A-Za-z0-9_]*)\.([A-Za-z_][A-Za-z0-9_]*)?$")
_IMPORT_LINE = re.compile(r"^\s*import\s+(.+)$", re.MULTILINE)
_SELF_ATTR = re.compile(r"\bself\.([A-Za-z_][A-Za-z0-9_]*)")

# stdlib modules that must never be imported just to list their members
_NO_IMPORT = {"antigravity", "this", "idlelib", "turtledemo", "tkinter", "turtle", "pydoc_data"}

_BUILTINS = sorted(n for n in dir(builtins) if not n.startswith("_"))
_KEYWORDS = sorted(keyword.kwlist + getattr(keyword, "softkwlist", []))


def _imported_modules(text: str) -> dict[str, str]:
    """Map local name -> module for simple ``import x`` / ``import x as y`` lines."""
    mapping: dict[str, str] = {}
    for m in _IMPORT_LINE.finditer(text):
        for part in m.group(1).split(","):
            bits = part.strip().split(" as ")
            module = bits[0].strip()
            local = (bits[1] if len(bits) > 1 else module.split(".")[0]).strip()
            if module and local.isidentifier():
                mapping[local] = module
    return mapping


def _module_members(module: str) -> list[tuple[str, bool]]:
    root = module.split(".")[0]
    if root not in sys.stdlib_module_names or root in _NO_IMPORT:
        return []
    try:
        mod = importlib.import_module(module)
    except Exception:  # noqa: BLE001
        return []
    return [
        (name, callable(getattr(mod, name, None)))
        for name in dir(mod)
        if not name.startswith("_")
    ]


def _rank(prefix: str, name: str) -> int:
    if not prefix:
        return 1
    if name.startswith(prefix):
        return 0
    return 1 if name.lower().startswith(prefix.lower()) else 2


def suggest(text: str, cursor: int, limit: int = 8) -> dict[str, Any]:
    """Suggestions for the identifier ending at ``cursor``.

    Returns ``{"prefix": str, "items": [{"label", "insert", "kind"}]}``.
    """
    cursor = max(0, min(cursor, len(text)))
    line_start = text.rfind("\n", 0, cursor) + 1
    before = text[line_start:cursor]
    if "#" in before:
        return {"prefix": "", "items": []}
    member = _MEMBER_CTX.search(before)
    prefix = (member.group(2) or "") if member else (_PREFIX_AT_END.search(before).group(1) or "")
    candidates: list[tuple[str, str, bool]] = []  # (name, kind, callable)

    if member:
        owner = member.group(1)
        if owner == "self":
            names = sorted(set(_SELF_ATTR.findall(text)))
            candidates = [(n, "member", False) for n in names]
        else:
            module = _imported_modules(text).get(owner)
            if module:
                candidates = [(n, "member", c) for n, c in _module_members(module)]
    else:
        if not prefix:
            return {"prefix": "", "items": []}
        words = {w for w in _IDENT.findall(text) if len(w) > 1}
        candidates += [(w, "local", False) for w in words]
        candidates += [(k, "keyword", False) for k in _KEYWORDS]
        candidates += [(b, "builtin", callable(getattr(builtins, b, None))) for b in _BUILTINS]

    kind_order = {"local": 0, "member": 0, "keyword": 1, "builtin": 2}
    seen: set[str] = set()
    ranked = []
    for name, kind, is_call in candidates:
        if name in seen or name == prefix or _rank(prefix, name) == 2:
            continue
        seen.add(name)
        ranked.append((_rank(prefix, name), kind_order[kind], len(name), name, kind, is_call))
    ranked.sort()
    items = [
        {"label": name + ("()" if is_call and kind != "keyword" else ""), "insert": name, "kind": kind}
        for _, _, _, name, kind, is_call in ranked[:limit]
    ]
    return {"prefix": prefix, "items": items}
