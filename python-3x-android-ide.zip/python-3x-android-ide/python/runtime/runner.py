"""Run system: lifecycle, output capture, stop, timeout and result reporting."""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Callable

from .backends import Handle, RunIO, RunSpec, default_backend
from .tracebacks import parse_traceback

MAX_OUTPUT_CHARS = 2_000_000  # cap kept in memory and forwarded; protects against runaway prints


class RunState(str, Enum):
    READY = "ready"
    PREPARING = "preparing"
    RUNNING = "running"
    STOPPED = "stopped"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class RunResult:
    state: RunState = RunState.READY
    exit_code: int | None = None
    duration: float = 0.0
    stdout: str = ""
    stderr: str = ""
    error: dict[str, Any] | None = None
    stuck: bool = False
    timed_out: bool = False
    truncated: bool = False
    backend: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "state": self.state.value,
            "exit_code": self.exit_code,
            "duration": round(self.duration, 3),
            "stdout": self.stdout,
            "stderr": self.stderr,
            "error": self.error,
            "stuck": self.stuck,
            "timed_out": self.timed_out,
            "truncated": self.truncated,
            "backend": self.backend,
        }


@dataclass
class _Last:
    script: Path
    cwd: Path
    args: tuple[str, ...]
    timeout: float | None


class ScriptRunner:
    """Runs one script at a time. Thread-safe; callbacks fire on worker threads."""

    def __init__(self, backend=None, max_output: int = MAX_OUTPUT_CHARS):
        self.backend = backend or default_backend()
        self.max_output = max_output
        self._lock = threading.RLock()
        self._state = RunState.READY
        self._handle: Handle | None = None
        self._io: RunIO | None = None
        self._result = RunResult()
        self._finished = threading.Event()
        self._finished.set()
        self._stop_requested = False
        self._timed_out = False
        self._last: _Last | None = None
        self._on_state: Callable[[str], None] | None = None
        self._on_output: Callable[[str, str], None] | None = None
        self._on_finish: Callable[[dict], None] | None = None
        self._out_chars = 0
        self._truncated = False
        self._out: dict[str, list[str]] = {"stdout": [], "stderr": []}
        self._started_at = time.monotonic()

    # ---------------------------------------------------------------- state
    @property
    def state(self) -> RunState:
        return self._state

    @property
    def is_running(self) -> bool:
        return self._state in (RunState.PREPARING, RunState.RUNNING)

    def _set_state(self, state: RunState) -> None:
        self._state = state
        if self._on_state:
            try:
                self._on_state(state.value)
            except Exception:  # noqa: BLE001 - UI callback must never kill the runner
                pass

    # ---------------------------------------------------------------- start
    def start(
        self,
        script: str | Path,
        cwd: str | Path,
        args: tuple[str, ...] = (),
        on_output: Callable[[str, str], None] | None = None,
        on_state: Callable[[str], None] | None = None,
        on_finish: Callable[[dict], None] | None = None,
        timeout: float | None = None,
    ) -> None:
        script, cwd = Path(script), Path(cwd)
        with self._lock:
            if self.is_running:
                raise RuntimeError("A script is already running. Stop it first.")
            self._on_output, self._on_state, self._on_finish = on_output, on_state, on_finish
            self._last = _Last(script, cwd, tuple(args), timeout)
            self._finished.clear()
            self._stop_requested = False
            self._timed_out = False
            self._out_chars = 0
            self._truncated = False
            self._result = RunResult(backend=self.backend.name)
            self._out = {"stdout": [], "stderr": []}
            self._started_at = time.monotonic()
            self._set_state(RunState.PREPARING)
            if not script.is_file():
                self._fail_to_start(f"Script not found: {script.name}\n")
                return
            self._io = RunIO(emit=self._emit)
            try:
                self._handle = self.backend.start(RunSpec(script, cwd, tuple(args)), self._io)
            except Exception as exc:  # noqa: BLE001
                self._fail_to_start(f"Could not start Python process: {exc}\n")
                return
            self._set_state(RunState.RUNNING)
            threading.Thread(target=self._supervise, args=(timeout,), daemon=True).start()

    def _fail_to_start(self, message: str) -> None:
        self._emit("stderr", message)
        self._result.state = RunState.FAILED
        self._result.exit_code = None
        self._finish()

    def _emit(self, stream: str, text: str) -> None:
        if self._out_chars >= self.max_output:
            if not self._truncated:
                self._truncated = True
                note = "\n[output truncated: limit reached]\n"
                self._out["stderr"].append(note)
                if self._on_output:
                    self._on_output("stderr", note)
            return
        remaining = self.max_output - self._out_chars
        text = text[:remaining]
        self._out_chars += len(text)
        self._out[stream].append(text)
        if self._on_output:
            try:
                self._on_output(stream, text)
            except Exception:  # noqa: BLE001
                pass

    # ------------------------------------------------------------ supervise
    def _supervise(self, timeout: float | None) -> None:
        handle = self._handle
        assert handle is not None
        timer = None
        if timeout:
            timer = threading.Timer(timeout, self._on_timeout)
            timer.daemon = True
            timer.start()
        code = handle.wait()
        if timer:
            timer.cancel()
        r = self._result
        r.duration = time.monotonic() - self._started_at
        r.exit_code = code
        r.stuck = bool(getattr(handle, "stuck", False))
        r.timed_out = self._timed_out
        if self._stop_requested or self._timed_out:
            r.state = RunState.STOPPED if not self._timed_out else RunState.FAILED
        elif code == 0:
            r.state = RunState.COMPLETED
        else:
            r.state = RunState.FAILED
        self._finish()

    def _on_timeout(self) -> None:
        self._timed_out = True
        self._emit("stderr", "\n[stopped: maximum run time exceeded]\n")
        if self._handle:
            self._handle.stop()

    def _finish(self) -> None:
        r = self._result
        r.stdout = "".join(self._out["stdout"])
        r.stderr = "".join(self._out["stderr"])
        r.truncated = self._truncated
        project_dir = str(self._last.cwd.resolve()) if self._last else None
        r.error = parse_traceback(r.stderr, project_dir) if r.state == RunState.FAILED else None
        self._handle = None
        self._set_state(r.state)
        self._finished.set()
        if self._on_finish:
            try:
                self._on_finish(r.to_dict())
            except Exception:  # noqa: BLE001
                pass

    # ----------------------------------------------------------------- stop
    def stop(self) -> None:
        with self._lock:
            handle = self._handle
            if handle is None or not self.is_running:
                return
            self._stop_requested = True
        handle.stop()

    def restart(self) -> None:
        if self._last is None:
            raise RuntimeError("Nothing to restart.")
        self.stop()
        self.wait(timeout=5)
        last = self._last
        self.start(
            last.script, last.cwd, last.args, self._on_output, self._on_state,
            self._on_finish, last.timeout,
        )

    def send_input(self, text: str) -> None:
        if self._io is not None and self.is_running:
            self._io.stdin.put(text)

    def wait(self, timeout: float | None = None) -> RunResult | None:
        if not self._finished.wait(timeout):
            return None
        return self._result

    @property
    def result(self) -> RunResult:
        return self._result

