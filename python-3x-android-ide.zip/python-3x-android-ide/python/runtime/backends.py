"""Execution backends for :class:`runtime.runner.ScriptRunner`.

``SubprocessBackend``
    Runs ``python -u script.py`` in a child process. Strong isolation and a
    reliable hard stop. Used on desktop and in tests. On Android there is no
    ``python`` executable to spawn, so it is not available there.

``InProcessBackend``
    Runs the script on a worker thread inside the host interpreter (what
    Chaquopy gives us). Stop is cooperative: it raises an exception inside the
    script thread, which works for Python code but cannot interrupt a thread
    blocked inside a native call. In that case the handle reports ``stuck``.
"""

from __future__ import annotations

import codecs
import ctypes
import importlib
import io
import os
import queue
import runpy
import signal
import subprocess
import sys
import tempfile
import threading
import traceback
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Protocol

Emit = Callable[[str, str], None]  # (stream "stdout"|"stderr", text)


@dataclass
class RunSpec:
    script: Path
    cwd: Path
    args: tuple[str, ...] = ()


@dataclass
class RunIO:
    emit: Emit
    stdin: "queue.Queue[str | None]" = field(default_factory=queue.Queue)


class Handle(Protocol):
    stuck: bool

    def stop(self, grace: float = 2.0) -> None: ...

    def wait(self, timeout: float | None = None) -> int | None: ...


class StopExecution(BaseException):
    """Injected into a script thread to stop it. Derives from BaseException so a
    bare ``except Exception`` in user code does not swallow it."""


# --------------------------------------------------------------- subprocess
_ENV_KEEP = ("PATH", "HOME", "LANG", "LC_ALL", "TMPDIR", "SYSTEMROOT", "TEMP", "TMP")


class _SubprocessHandle:
    def __init__(self, spec: RunSpec, io_: RunIO):
        env = {k: os.environ[k] for k in _ENV_KEEP if k in os.environ}
        # no .pyc: same-size edits within one second would otherwise run stale bytecode
        env.update(
            PYTHONUNBUFFERED="1", PYTHONIOENCODING="utf-8",
            PYTHONPATH=str(spec.cwd), PYTHONDONTWRITEBYTECODE="1",
        )
        self.stuck = False
        self._io = io_
        self._proc = subprocess.Popen(
            [sys.executable, "-u", str(spec.script), *spec.args],
            cwd=str(spec.cwd),
            env=env,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            start_new_session=(os.name == "posix"),
        )
        self._threads = [
            threading.Thread(target=self._pump, args=(self._proc.stdout, "stdout"), daemon=True),
            threading.Thread(target=self._pump, args=(self._proc.stderr, "stderr"), daemon=True),
            threading.Thread(target=self._feed_stdin, daemon=True),
        ]
        for t in self._threads:
            t.start()

    def _pump(self, stream, name: str) -> None:
        decoder = codecs.getincrementaldecoder("utf-8")(errors="replace")
        try:
            while True:
                chunk = stream.read1(4096)
                if not chunk:
                    tail = decoder.decode(b"", final=True)
                    if tail:
                        self._io.emit(name, tail)
                    return
                text = decoder.decode(chunk)
                if text:
                    self._io.emit(name, text)
        except (OSError, ValueError):
            pass  # pipe closed underneath us during stop
        finally:
            try:
                stream.close()
            except OSError:
                pass

    def _feed_stdin(self) -> None:
        stdin = self._proc.stdin
        try:
            while True:
                item = self._io.stdin.get()
                if item is None:
                    break
                stdin.write(item.encode("utf-8"))
                stdin.flush()
        except (BrokenPipeError, ValueError, OSError):
            pass
        finally:
            try:
                stdin.close()
            except OSError:
                pass

    def stop(self, grace: float = 2.0) -> None:
        self._io.stdin.put(None)
        if self._proc.poll() is not None:
            return
        self._signal(signal.SIGTERM if os.name == "posix" else None)
        try:
            self._proc.wait(timeout=grace)
        except subprocess.TimeoutExpired:
            self._signal(signal.SIGKILL if os.name == "posix" else None, kill=True)
            try:
                self._proc.wait(timeout=grace)
            except subprocess.TimeoutExpired:
                self.stuck = True

    def _signal(self, sig, kill: bool = False) -> None:
        try:
            if os.name == "posix" and sig is not None:
                os.killpg(os.getpgid(self._proc.pid), sig)
            elif kill:
                self._proc.kill()
            else:
                self._proc.terminate()
        except (ProcessLookupError, PermissionError):
            pass

    def wait(self, timeout: float | None = None) -> int | None:
        try:
            code = self._proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            return None
        for t in self._threads[:2]:
            t.join(timeout=2.0)
        self._io.stdin.put(None)
        return code


class SubprocessBackend:
    name = "subprocess"

    def start(self, spec: RunSpec, io_: RunIO) -> Handle:
        return _SubprocessHandle(spec, io_)


# ----------------------------------------------------------------- in-process
class _OutRouter(io.TextIOBase):
    """Replacement for sys.stdout/sys.stderr that routes by calling thread."""

    def __init__(self, original):
        self.original = original
        self.routes: dict[int, Callable[[str], None]] = {}

    def write(self, s: str) -> int:
        route = self.routes.get(threading.get_ident())
        if route is not None:
            if s:
                route(s)
        else:
            self.original.write(s)
        return len(s)

    def flush(self) -> None:
        if threading.get_ident() not in self.routes:
            try:
                self.original.flush()
            except Exception:  # noqa: BLE001
                pass

    def isatty(self) -> bool:
        return False

    @property
    def encoding(self) -> str:  # type: ignore[override]
        return "utf-8"

    def writable(self) -> bool:
        return True


class _InRouter(io.TextIOBase):
    """sys.stdin replacement: each script thread reads from its own queue."""

    def __init__(self, original):
        self.original = original
        self.queues: dict[int, "queue.Queue[str | None]"] = {}

    def readline(self, size: int = -1) -> str:
        q = self.queues.get(threading.get_ident())
        if q is None:
            return self.original.readline(size)
        item = q.get()
        if item is None:
            q.put(None)  # keep EOF sticky
            return ""
        return item

    def read(self, size: int = -1) -> str:
        parts = []
        while True:
            line = self.readline()
            if not line:
                break
            parts.append(line)
        return "".join(parts)

    def isatty(self) -> bool:
        return False

    def readable(self) -> bool:
        return True


_install_lock = threading.Lock()


def _routers() -> tuple[_OutRouter, _OutRouter, _InRouter]:
    """Make sure the std streams are routers (re-wrap if something replaced them)."""
    with _install_lock:
        if not isinstance(sys.stdout, _OutRouter):
            sys.stdout = _OutRouter(sys.stdout)
        if not isinstance(sys.stderr, _OutRouter):
            sys.stderr = _OutRouter(sys.stderr)
        if not isinstance(sys.stdin, _InRouter):
            sys.stdin = _InRouter(sys.stdin)
        return sys.stdout, sys.stderr, sys.stdin  # type: ignore[return-value]


def _purge_project_modules(cwd: Path) -> None:
    """Forget modules imported from the project so edits are picked up on re-run."""
    prefix = str(cwd.resolve()) + os.sep
    for name, module in list(sys.modules.items()):
        file = getattr(module, "__file__", None)
        if file and str(file).startswith(prefix):
            sys.modules.pop(name, None)


_this_file = os.path.abspath(__file__)
_runpy_file = os.path.abspath(runpy.__file__)


def _strip_runner_frames(tb):
    while tb is not None and os.path.abspath(tb.tb_frame.f_code.co_filename) in (
        _this_file,
        _runpy_file,
    ):
        tb = tb.tb_next
    return tb


def _shielded(fn: Callable[[], None]) -> None:
    """Run ``fn`` even if a late stop signal lands inside it (cleanup must finish)."""
    for _ in range(5):
        try:
            fn()
            return
        except StopExecution:
            continue
        except Exception:  # noqa: BLE001
            return


class _InProcessHandle:
    def __init__(self, spec: RunSpec, io_: RunIO):
        self.stuck = False
        self._spec = spec
        self._io = io_
        self._code: int | None = None
        self._done = threading.Event()
        self._phase_lock = threading.Lock()
        self._in_user_phase = True  # stop signals are only injected while True
        self._thread = threading.Thread(target=self._run, name="py3x-script", daemon=True)
        self._thread.start()

    def _run(self) -> None:
        tid = threading.get_ident()
        out = err = inn = None
        saved: tuple | None = None
        try:
            out, err, inn = _routers()
            try:
                cwd_before: str | None = os.getcwd()
            except OSError:  # the previous working directory was deleted
                cwd_before = None
            saved = (list(sys.argv), list(sys.path), cwd_before, sys.dont_write_bytecode)
            out.routes[tid] = lambda s: self._io.emit("stdout", s)
            err.routes[tid] = lambda s: self._io.emit("stderr", s)
            inn.queues[tid] = self._io.stdin
            os.chdir(self._spec.cwd)  # process-wide; one script runs at a time
            sys.path.insert(0, str(self._spec.cwd))
            sys.argv = [str(self._spec.script), *self._spec.args]
            sys.dont_write_bytecode = True  # see SubprocessBackend: avoid stale .pyc
            importlib.invalidate_caches()
            _purge_project_modules(self._spec.cwd)
            self._run_user_code()
        except StopExecution:
            self._code = -15  # stop landed during setup
        except BaseException as exc:  # noqa: BLE001 - never die without reporting
            self._io.emit("stderr", f"Runner error: {type(exc).__name__}: {exc}\n")
            self._code = 1
        finally:
            def leave_user_phase() -> None:
                with self._phase_lock:
                    self._in_user_phase = False

            def cleanup() -> None:
                _purge_project_modules(self._spec.cwd)
                if saved is not None:
                    sys.argv, sys.path[:] = saved[0], saved[1]
                    sys.dont_write_bytecode = saved[3]
                    target = saved[2]
                    if target is None or not os.path.isdir(target):
                        target = tempfile.gettempdir()
                    os.chdir(target)
                for router, table in ((out, "routes"), (err, "routes"), (inn, "queues")):
                    if router is not None:
                        getattr(router, table).pop(tid, None)

            _shielded(leave_user_phase)
            _shielded(cleanup)
            _shielded(self._done.set)

    def _run_user_code(self) -> None:
        try:
            runpy.run_path(str(self._spec.script), run_name="__main__")
            self._code = 0
        except SystemExit as exc:
            code = exc.code
            if code is None:
                self._code = 0
            elif isinstance(code, int):
                self._code = code
            else:
                self._io.emit("stderr", f"{code}\n")
                self._code = 1
        except StopExecution:
            self._code = -15
        except BaseException as exc:  # noqa: BLE001 - user code may raise anything
            tb = _strip_runner_frames(exc.__traceback__)
            self._io.emit("stderr", "".join(traceback.format_exception(type(exc), exc, tb)))
            self._code = 1

    def stop(self, grace: float = 2.0) -> None:
        self._io.stdin.put(None)  # unblock input()
        step, waited = 0.05, 0.0
        while not self._done.is_set() and waited < grace:
            with self._phase_lock:
                if self._in_user_phase:
                    ctypes.pythonapi.PyThreadState_SetAsyncExc(
                        ctypes.c_ulong(self._thread.ident), ctypes.py_object(StopExecution)
                    )
            self._done.wait(step)
            waited += step
        if not self._done.is_set():
            self.stuck = True

    def wait(self, timeout: float | None = None) -> int | None:
        if not self._done.wait(timeout):
            return None
        return self._code


class InProcessBackend:
    name = "in-process"

    def start(self, spec: RunSpec, io_: RunIO) -> Handle:
        return _InProcessHandle(spec, io_)


def default_backend():
    """Android (Chaquopy) cannot spawn a Python executable; everything else can."""
    if hasattr(sys, "getandroidapilevel") or "ANDROID_ROOT" in os.environ:
        return InProcessBackend()
    return SubprocessBackend()
