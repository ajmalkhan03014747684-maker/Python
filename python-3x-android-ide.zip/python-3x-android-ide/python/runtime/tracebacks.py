"""Parse Python tracebacks so the editor can jump to the failing line."""

from __future__ import annotations

import re
from typing import Any

_FRAME = re.compile(r'^\s*File "(?P<file>.+?)", line (?P<line>\d+)(?:, in (?P<func>.+))?\s*$')


def parse_traceback(text: str, project_dir: str | None = None) -> dict[str, Any] | None:
    """Return ``{error_type, message, line, file, frames}`` or ``None``.

    ``line``/``file`` point at the innermost frame inside ``project_dir`` when
    given (so library frames are skipped), otherwise at the innermost frame.
    """
    lines = text.splitlines()
    frames: list[dict[str, Any]] = []
    last_tb_start = None
    for idx, raw in enumerate(lines):
        if raw.startswith("Traceback (most recent call last)"):
            last_tb_start = idx
            frames = []
            continue
        match = _FRAME.match(raw)
        if match:
            if last_tb_start is None:
                last_tb_start = idx  # SyntaxError output has frames but no header
            frames.append(
                {
                    "file": match["file"],
                    "line": int(match["line"]),
                    "func": match["func"] or "",
                }
            )
    if last_tb_start is None or not frames:
        return None
    error_line = ""
    for raw in reversed(lines):
        if raw.strip() and not raw.startswith((" ", "\t")):
            error_line = raw.strip()
            break
    error_type, _, message = error_line.partition(":")
    chosen = frames[-1]
    if project_dir:
        prefix = project_dir.rstrip("/") + "/"
        inside = [f for f in frames if f["file"].startswith(prefix) or not f["file"].startswith("/")]
        if inside:
            chosen = inside[-1]
    return {
        "error_type": error_type.strip(),
        "message": message.strip(),
        "file": chosen["file"],
        "line": chosen["line"],
        "frames": frames,
    }
