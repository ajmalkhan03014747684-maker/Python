"""Breakpoint debugger built on the standard library's ``bdb``.

One session debugs one script on a background thread. The thread pauses at breakpoints/steps and
reports a *snapshot* (file, line, call stack, variables as short strings) through ``on_event``.
The UI then sends one command: continue, step, over, out or stop.

Limits (be honest in the UI): only code running in the debug thread is traced; values are shown as
truncated ``repr`` strings and are not editable; a script blocked in native code cannot be stopped.
"""

from __future__ import annotations

import bdb
import contextlib
import io
import os
import sys
import threading
import traceback
from pathlib import Path
from typing import Any, Callable

MAX_VALUE_CHARS = 200
MAX_VARS = 60
COMMANDS = {"continue", "step", "over", "out", "stop"}


class _Quit(BaseException):
    pass


class _Writer(io.TextIOBase):
    def __init__(self, stream: str, emit: Callable[[str, str], None]):
        self._stream, self._emit = stream, emit

    def writable(self) -> bool:
        return True

    def write(self, s: str) -> int:
        if s:
            self._emit(self._stream, s)
        return len(s)


def _short(value: Any) -> str:
    try:
        text = repr(value)
    except Exception as exc:  # noqa: BLE001 - user objects can raise anything
        text = f"<repr failed: {type(exc).__name__}>"
    return text if len(text) <= MAX_VALUE_CHARS else text[: MAX_VALUE_CHARS - 1] + "…"


class _Bdb(bdb.Bdb):
    def __init__(self, owner: "DebugSession"):
        super().__init__()
        self.owner = owner

    def _inside_project(self, filename: str) -> bool:
        try:
            return Path(filename).resolve().is_relative_to(self.owner.root)
        except (OSError, ValueError):
            return False

    def user_line(self, frame):
        if not self._inside_project(frame.f_code.co_filename):
            self.set_step()  # keep going until we are back in user code
            return
        self.owner._pause(frame)

    def user_return(self, frame, return_value):
        pass

    def user_exception(self, frame, exc_info):
        pass


class DebugSession:
    def __init__(self, project_root: str | Path, on_event: Callable[[dict], None]):
        self.root = Path(project_root).resolve()
        self.on_event = on_event
        self._bdb = _Bdb(self)
        self._cmd: str | None = None
        self._cmd_ready = threading.Event()
        self._thread: threading.Thread | None = None
        self._lock = threading.Lock()
        self.finished = threading.Event()

    # ----------------------------------------------------------- control
    def set_breakpoints(self, rel: str, lines: list[int]) -> None:
        path = str((self.root / rel).resolve())
        with self._lock:
            self._bdb.clear_all_file_breaks(path)
            for line in sorted(set(int(n) for n in lines if int(n) > 0)):
                self._bdb.set_break(path, line)

    def start(self, rel: str, breakpoints: dict[str, list[int]] | None = None, stop_on_entry: bool = False) -> None:
        if self._thread and self._thread.is_alive():
            raise RuntimeError("A debug session is already running.")
        script = (self.root / rel).resolve()
        if not script.is_relative_to(self.root) or not script.is_file():
            raise ValueError("Script not found in the project.")
        for file_rel, lines in (breakpoints or {}).items():
            self.set_breakpoints(file_rel, lines)
        self.finished.clear()
        self._thread = threading.Thread(target=self._run, args=(script, stop_on_entry), name="py3x-debug", daemon=True)
        self._thread.start()

    def command(self, cmd: str) -> None:
        if cmd not in COMMANDS:
            raise ValueError(f"Unknown debugger command '{cmd}'.")
        self._cmd = cmd
        self._cmd_ready.set()

    def stop(self) -> None:
        self.command("stop")

    @property
    def active(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def join(self, timeout: float | None = None) -> bool:
        return self.finished.wait(timeout)

    # ------------------------------------------------------------ thread
    def _emit_output(self, stream: str, text: str) -> None:
        self.on_event({"event": "output", "stream": stream, "text": text})

    def _run(self, script: Path, stop_on_entry: bool) -> None:
        exit_code, error = 0, None
        old_cwd = os.getcwd()
        out, err = _Writer("stdout", self._emit_output), _Writer("stderr", self._emit_output)
        try:
            source = script.read_text(encoding="utf-8")
            code = compile(source, str(script), "exec")
            os.chdir(self.root)
            sys.path.insert(0, str(self.root))  # so `import helper` finds project modules
            glob = {"__name__": "__main__", "__file__": str(script), "__builtins__": __builtins__}
            # bdb.run() always stops on the first line. Set up tracing ourselves so we only stop at
            # breakpoints (or on the first line when asked to).
            self._bdb.reset()
            if stop_on_entry:
                self._bdb.set_step()
            else:
                self._bdb.botframe = object()  # truthy stop frame that no real frame matches
                self._bdb.set_continue()
            with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
                sys.settrace(self._bdb.trace_dispatch)
                try:
                    exec(code, glob, glob)  # noqa: S102 - running the user's own script is the point
                finally:
                    sys.settrace(None)
                    self._bdb.quitting = True
        except _Quit:
            exit_code = -1
        except SystemExit as exc:
            exit_code = exc.code if isinstance(exc.code, int) else (0 if exc.code is None else 1)
        except SyntaxError as exc:
            exit_code, error = 1, f"SyntaxError: {exc.msg} (line {exc.lineno})"
        except BaseException as exc:  # noqa: BLE001
            exit_code = 1
            error = f"{type(exc).__name__}: {exc}"
            self._emit_output("stderr", "".join(traceback.format_exception(type(exc), exc, exc.__traceback__)))
        finally:
            from runtime.backends import _purge_project_modules

            _purge_project_modules(self.root)  # edits are picked up on the next run
            with contextlib.suppress(ValueError):
                sys.path.remove(str(self.root))
            with contextlib.suppress(Exception):
                os.chdir(old_cwd)
            self._bdb.reset()
            self.on_event({"event": "finished", "exit_code": exit_code, "error": error})
            self.finished.set()

    def _pause(self, frame) -> None:
        self.on_event({"event": "paused", **self._snapshot(frame)})
        self._cmd_ready.clear()
        self._cmd_ready.wait()
        cmd = self._cmd
        if cmd == "stop":
            self._bdb.set_quit()
            raise _Quit()
        if cmd == "continue":
            self._bdb.set_continue()
        elif cmd == "step":
            self._bdb.set_step()
        elif cmd == "over":
            self._bdb.set_next(frame)
        elif cmd == "out":
            self._bdb.set_return(frame)

    def _snapshot(self, frame) -> dict[str, Any]:
        stack = []
        f = frame
        while f is not None:
            if self._bdb._inside_project(f.f_code.co_filename):
                stack.append({"function": f.f_code.co_name, "file": os.path.relpath(f.f_code.co_filename, self.root), "line": f.f_lineno})
            f = f.f_back
        local_vars = {
            k: _short(v) for k, v in list(frame.f_locals.items())[:MAX_VARS]
            if not (k.startswith("__") and k.endswith("__"))
        }
        return {
            "file": os.path.relpath(frame.f_code.co_filename, self.root),
            "line": frame.f_lineno,
            "function": frame.f_code.co_name,
            "stack": stack,
            "variables": local_vars,
        }
