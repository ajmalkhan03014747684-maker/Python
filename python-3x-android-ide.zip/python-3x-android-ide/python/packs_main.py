"""Entry point of the Packs companion app (called from Kotlin through Chaquopy).

Same convention as ``main.py``: every method returns a JSON envelope string.
"""

from __future__ import annotations

import functools
import json
import logging
import sys
from pathlib import Path

from packages import PackageCatalog
from packsvc import JobError, PacksJobs
from projects.paths import PathError
from vision import VisionError

log = logging.getLogger("py3x.packs")
PROTOCOL_VERSION = 1


def _api(fn):
    @functools.wraps(fn)
    def wrapper(self, *args, **kwargs) -> str:
        try:
            return json.dumps({"ok": True, "data": fn(self, *args, **kwargs)})
        except (JobError, PathError, VisionError, ValueError, RuntimeError) as exc:
            return json.dumps({"ok": False, "error": str(exc)})
        except Exception as exc:  # noqa: BLE001
            log.exception("Unhandled error in %s", fn.__name__)
            return json.dumps({"ok": False, "error": f"Unexpected error ({type(exc).__name__})."})

    return wrapper


class PacksApi:
    def __init__(self, data_dir: str | Path, backend=None):
        self.data_dir = Path(data_dir)
        self.jobs = PacksJobs(self.data_dir / "jobs", backend)
        self.catalog = PackageCatalog()

    @_api
    def info(self) -> dict:
        return {
            "protocol": PROTOCOL_VERSION,
            "python": sys.version.split()[0],
            "packages": self.catalog.installed(),
            "busy": self.jobs.busy,
        }

    @_api
    def start_job(self, job_id: str, zip_path: str, kind: str, arg_json: str, listener=None) -> bool:
        def on_output(stream: str, text: str) -> None:
            if listener is not None:
                listener.onOutput(stream, text)

        def on_finish(result: dict) -> None:
            if listener is not None:
                listener.onFinish(json.dumps(result))

        self.jobs.start(job_id, zip_path, kind, json.loads(arg_json) if kind == "vision" else arg_json, on_output, on_finish)
        return True

    @_api
    def stop_job(self) -> bool:
        self.jobs.stop()
        return True

    @_api
    def cleanup(self, job_id: str) -> bool:
        self.jobs.cleanup(job_id)
        return True


def create_app(data_dir: str, in_process: bool = True) -> PacksApi:
    backend = None
    if in_process:
        from runtime import InProcessBackend

        backend = InProcessBackend()
    return PacksApi(data_dir, backend)
