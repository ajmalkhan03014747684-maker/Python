"""Entry point used by the Android app (via Chaquopy) and by tests.

Kotlin calls ``main.create_app(data_dir)`` once, then calls methods on the
returned :class:`Py3xApi`. Every method returns a JSON string:

    {"ok": true,  "data": ...}
    {"ok": false, "error": "human readable message"}

Strings in, strings out keeps the Kotlin/Python boundary trivial and avoids
leaking PyObject conversions into the UI layer.
"""

from __future__ import annotations

import functools
import json
import logging
import logging.handlers
import sys
import threading
from pathlib import Path
from typing import Any, Callable

from admin import AdminService
from backend import BackendError, SupabaseClient
from admin.service import AdminError
from autosave import AutosaveService
from debugger import DebugSession
from editor import completion, diagnostics, ops
from github import GitHubClient, GitHubError, GitHubSync
from packages import PackageCatalog
from packsvc import apply_result
from projects import PathError, ProjectManager
from recovery import RecoveryManager
from runtime import ScriptRunner, default_backend
from vision import VisionError, VisionStudio
from storage import Database
from autofix import assist as autofix_assist
from autofix import diagnose as autofix_diagnose
from templates import TemplateError, create_from_template, list_templates
from terminal import TerminalSession

log = logging.getLogger("py3x")

DEFAULT_SETTINGS: dict[str, Any] = {
    "theme": "light",  # dark | light | system
    "accent": "#2F80FF",
    "font_size": 14,
    "tab_width": 4,
    "use_spaces": True,
    "line_numbers": True,
    "word_wrap": True,
    "syntax_highlighting": True,
    "autocomplete": True,
    "auto_indent": True,
    "autosave_debounce_ms": 800,
    "save_all_before_run": True,
    "max_runtime_seconds": 0,  # 0 = no limit
    "reduce_motion": False,
}
_RANGES = {"font_size": (8, 32), "tab_width": (1, 8), "autosave_debounce_ms": (200, 10000),
           "max_runtime_seconds": (0, 86400)}
_CHOICES = {"theme": {"dark", "light", "system"}}

COMPATIBILITY_NOTES = (
    "Python runs inside the app on your device. Many pure-Python programs work, but "
    "desktop-only libraries (tkinter, subprocess-based tools, packages with native code "
    "that is not bundled) will not. Packages are bundled at build time."
)


def _api(fn: Callable[..., Any]) -> Callable[..., str]:
    @functools.wraps(fn)
    def wrapper(self, *args, **kwargs) -> str:
        try:
            return json.dumps({"ok": True, "data": fn(self, *args, **kwargs)})
        except (PathError, AdminError, VisionError, GitHubError, TemplateError, ValueError, RuntimeError) as exc:
            return json.dumps({"ok": False, "error": str(exc)})
        except Exception as exc:  # noqa: BLE001
            log.exception("Unhandled error in %s", fn.__name__)
            return json.dumps({"ok": False, "error": f"Unexpected error ({type(exc).__name__}). See logs."})

    return wrapper


def _setup_logging(log_dir: Path) -> None:
    log_dir.mkdir(parents=True, exist_ok=True)
    for old in [h for h in log.handlers if isinstance(h, logging.handlers.RotatingFileHandler)]:
        log.removeHandler(old)
        old.close()
    handler = logging.handlers.RotatingFileHandler(
        log_dir / "runtime.log", maxBytes=512 * 1024, backupCount=2, encoding="utf-8"
    )
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    log.setLevel(logging.INFO)
    log.addHandler(handler)


class Py3xApi:
    def __init__(self, data_dir: str | Path, runner_backend=None):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        _setup_logging(self.data_dir / "logs")
        self.db = Database(self.data_dir / "ide.db")
        self.projects = ProjectManager(self.db, self.data_dir / "projects")
        self.autosave = AutosaveService(self.db, self.projects)
        self.recovery = RecoveryManager(self.db, self.projects, self.autosave)
        self.admin = AdminService(self.db)
        self._backend_client = None
        self.github = GitHubSync(self.projects, self.autosave, self.data_dir)
        self.package_catalog = PackageCatalog()
        self._debug: DebugSession | None = None
        self.scratch = self.data_dir / "scratch"
        self.scratch.mkdir(exist_ok=True)
        self._backend = runner_backend or default_backend()
        self.runner = ScriptRunner(self._backend)
        self._terminals: dict[int, TerminalSession] = {}
        self._term_lock = threading.Lock()
        self._next_term = 1
        self.crashed = self.recovery.begin_session()
        log.info("session started (previous crashed=%s, backend=%s)", self.crashed, self._backend.name)

    # ------------------------------------------------------------- settings
    @_api
    def get_settings(self) -> dict:
        settings = dict(DEFAULT_SETTINGS)
        for key, default in DEFAULT_SETTINGS.items():
            raw = self.db.get_setting(f"pref.{key}")
            if raw is not None:
                settings[key] = json.loads(raw)
        return settings

    @_api
    def set_setting(self, key: str, value_json: str) -> bool:
        if key not in DEFAULT_SETTINGS:
            raise ValueError(f"Unknown setting '{key}'.")
        value = json.loads(value_json)
        default = DEFAULT_SETTINGS[key]
        if isinstance(default, bool) != isinstance(value, bool) or (
            not isinstance(default, bool) and type(value) is not type(default)
        ):
            raise ValueError(f"Invalid value for '{key}'.")
        if key in _RANGES and not _RANGES[key][0] <= value <= _RANGES[key][1]:
            raise ValueError(f"'{key}' must be between {_RANGES[key][0]} and {_RANGES[key][1]}.")
        if key in _CHOICES and value not in _CHOICES[key]:
            raise ValueError(f"'{key}' must be one of {sorted(_CHOICES[key])}.")
        if key == "accent" and not (isinstance(value, str) and len(value) == 7 and value[0] == "#"):
            raise ValueError("Accent must look like #RRGGBB.")
        self.db.set_setting(f"pref.{key}", json.dumps(value))
        return True

    def _setting(self, key: str) -> Any:
        raw = self.db.get_setting(f"pref.{key}")
        return json.loads(raw) if raw is not None else DEFAULT_SETTINGS[key]

    # ------------------------------------------------------------- projects
    @_api
    def list_projects(self) -> list:
        return self.projects.list_projects()

    @_api
    def create_project(self, name: str) -> dict:
        return self.projects.create_project(name)

    @_api
    def rename_project(self, project_id: int, name: str) -> dict:
        return self.projects.rename_project(project_id, name)

    @_api
    def delete_project(self, project_id: int) -> bool:
        self.projects.delete_project(project_id)
        return True

    @_api
    def list_deleted_projects(self) -> list:
        return self.projects.list_deleted_projects()

    @_api
    def restore_project(self, project_id: int) -> dict:
        return self.projects.restore_project(project_id)

    @_api
    def purge_project(self, project_id: int) -> bool:
        self.projects.purge_project(project_id)
        return True

    @_api
    def duplicate_project(self, project_id: int) -> dict:
        return self.projects.duplicate_project(project_id)

    @_api
    def export_project(self, project_id: int, dest_zip: str) -> str:
        return self.projects.export_project(project_id, dest_zip)

    @_api
    def import_project(self, zip_path: str, name: str | None = None) -> dict:
        return self.projects.import_project(zip_path, name)

    @_api
    def set_main_file(self, project_id: int, rel: str) -> dict:
        return self.projects.set_main_file(project_id, rel)

    # ---------------------------------------------------------------- files
    @_api
    def list_dir(self, project_id: int, rel: str = "", sort: str = "name") -> list:
        return self.projects.list_dir(project_id, rel, sort)

    @_api
    def open_file(self, project_id: int, rel: str) -> dict:
        """Read a file for the editor. If a newer unsaved draft exists it is returned too."""
        data = self.projects.read_file(project_id, rel)
        draft = self.autosave.get_draft(project_id, rel)
        self.projects.touch_recent(project_id, rel)
        data["draft"] = draft["content"] if draft and draft["content"] != data["content"] else None
        return data

    @_api
    def create_file(self, project_id: int, rel: str) -> dict:
        return self.projects.create_file(project_id, rel)

    @_api
    def create_folder(self, project_id: int, rel: str) -> dict:
        return self.projects.create_folder(project_id, rel)

    @_api
    def rename(self, project_id: int, rel: str, new_name: str) -> dict:
        return self.projects.rename(project_id, rel, new_name)

    @_api
    def move(self, project_id: int, rel: str, dest_dir: str) -> dict:
        return self.projects.move(project_id, rel, dest_dir)

    @_api
    def copy(self, project_id: int, rel: str, dest_dir: str) -> dict:
        return self.projects.copy(project_id, rel, dest_dir)

    @_api
    def delete(self, project_id: int, rel: str) -> int:
        return self.projects.delete(project_id, rel)

    @_api
    def list_trash(self, project_id: int) -> list:
        return self.projects.list_trash(project_id)

    @_api
    def restore_trash(self, project_id: int, trash_id: int) -> dict:
        return self.projects.restore_from_trash(project_id, trash_id)

    @_api
    def search_files(self, project_id: int, query: str, content: bool = False) -> list:
        return self.projects.search_files(project_id, query, content)

    @_api
    def toggle_favorite(self, project_id: int, rel: str) -> bool:
        return self.projects.toggle_favorite(project_id, rel)

    @_api
    def favorites(self, project_id: int) -> list:
        return self.projects.favorites(project_id)

    @_api
    def recent_files(self, limit: int = 10) -> list:
        return self.projects.recent_files(limit)

    # ------------------------------------------------------------- autosave
    @_api
    def update_drafts(self, drafts_json: str) -> int:
        """Store drafts for several open tabs at once.

        ``drafts_json`` is ``[{"project_id", "rel", "content", "base_hash"}, ...]``.
        """
        items = json.loads(drafts_json)
        for d in items:
            self.autosave.update_draft(d["project_id"], d["rel"], d["content"], d.get("base_hash", ""))
        return len(items)

    @_api
    def save_file(self, project_id: int, rel: str, content: str) -> dict:
        return self.autosave.commit(project_id, rel, content, "save")

    @_api
    def has_unsaved_changes(self, project_id: int, rel: str) -> bool:
        return self.autosave.has_unsaved_changes(project_id, rel)

    @_api
    def list_versions(self, project_id: int, rel: str) -> list:
        return self.autosave.list_versions(project_id, rel)

    @_api
    def get_version(self, version_id: int) -> dict:
        return self.autosave.get_version(version_id)

    # ------------------------------------------------------------- recovery
    @_api
    def recovery_scan(self) -> dict:
        return self.recovery.scan()

    @_api
    def recovery_diff(self, project_id: int, rel: str) -> str:
        return self.recovery.diff(project_id, rel)

    @_api
    def recovery_restore(self, project_id: int, rel: str) -> dict:
        return self.recovery.restore(project_id, rel)

    @_api
    def recovery_discard(self, project_id: int, rel: str) -> bool:
        self.recovery.discard(project_id, rel)
        return True

    @_api
    def end_session(self) -> bool:
        """Call on a clean shutdown so the next launch does not report a crash."""
        self.recovery.end_session()
        return True

    # --------------------------------------------------------------- editor
    @_api
    def edit_op(self, name: str, text: str, start: int, end: int, options_json: str = "{}") -> dict:
        opts = json.loads(options_json)
        simple = {"toggle_comment": ops.toggle_comment, "duplicate_line": ops.duplicate_line,
                  "delete_line": ops.delete_line}
        spaced = {"indent": ops.indent, "outdent": ops.outdent}
        if name in simple:
            out = simple[name](text, start, end)
        elif name in spaced:
            out = spaced[name](text, start, end, opts.get("use_spaces", True), opts.get("tab_width", 4))
        elif name == "move_up":
            out = ops.move_lines(text, start, end, -1)
        elif name == "move_down":
            out = ops.move_lines(text, start, end, 1)
        else:
            raise ValueError(f"Unknown edit operation '{name}'.")
        return {"text": out[0], "start": out[1], "end": out[2]}

    @_api
    def auto_indent(self, line_before_cursor: str, use_spaces: bool = True, tab_width: int = 4) -> str:
        return ops.auto_indent(line_before_cursor, use_spaces, tab_width)

    @_api
    def match_bracket(self, text: str, pos: int) -> list | None:
        pair = ops.match_bracket(text, pos)
        return list(pair) if pair else None

    @_api
    def find_all(self, text: str, query: str, options_json: str = "{}") -> list:
        return [list(m) for m in ops.find_all(text, query, **json.loads(options_json))]

    @_api
    def find_next(self, text: str, query: str, pos: int, forward: bool = True,
                  options_json: str = "{}") -> list | None:
        m = ops.find_next(text, query, pos, forward, **json.loads(options_json))
        return list(m) if m else None

    @_api
    def replace_next(self, text: str, query: str, replacement: str, pos: int,
                     options_json: str = "{}") -> dict:
        new, new_pos, replaced = ops.replace_next(text, query, replacement, pos, **json.loads(options_json))
        return {"text": new, "pos": new_pos, "replaced": replaced}

    @_api
    def replace_all(self, text: str, query: str, replacement: str, options_json: str = "{}") -> dict:
        new, count = ops.replace_all(text, query, replacement, **json.loads(options_json))
        return {"text": new, "count": count}

    @_api
    def goto_line(self, text: str, line: int) -> int:
        return ops.goto_line(text, line)

    @_api
    def diagnostics(self, text: str) -> list:
        return diagnostics.check_syntax(text)

    @_api
    def complete(self, text: str, cursor: int) -> dict:
        return completion.suggest(text, cursor)

    # ------------------------------------------------------------------ run
    @staticmethod
    def _callbacks(listener):
        if listener is None:
            return None, None, None
        return (
            lambda stream, text: listener.onOutput(stream, text),
            lambda state: listener.onState(state),
            lambda result: listener.onFinish(json.dumps(result)),
        )

    def _start_run(self, project_id: int, script: Path, listener, rel_for_save: str | None) -> dict:
        if self.runner.is_running:
            raise RuntimeError("A script is already running. Stop it first.")
        cwd = self.projects.project_dir(project_id)
        saved: list[str] = []
        if self._setting("save_all_before_run"):
            saved = self.autosave.commit_all_drafts(project_id, "run")
        elif rel_for_save:
            draft = self.autosave.get_draft(project_id, rel_for_save)
            if draft is not None:
                self.autosave.commit(project_id, rel_for_save, draft["content"], "run")
                saved = [rel_for_save]
        on_out, on_state, on_finish = self._callbacks(listener)
        timeout = self._setting("max_runtime_seconds") or None
        self.runner.start(script, cwd, (), on_out, on_state, on_finish, timeout)
        return {"saved": saved, "backend": self._backend.name}

    @_api
    def run_file(self, project_id: int, rel: str, listener=None) -> dict:
        script = self.projects._target(project_id, rel)  # noqa: SLF001 - validated path
        return self._start_run(project_id, script, listener, rel)

    @_api
    def run_project(self, project_id: int, listener=None) -> dict:
        main = self.projects.get_project(project_id)["main_file"]
        script = self.projects._target(project_id, main)  # noqa: SLF001
        return self._start_run(project_id, script, listener, main)

    @_api
    def run_code(self, project_id: int, code: str, listener=None) -> dict:
        """Run a selected snippet in the project's working directory."""
        script = self.scratch / "selection.py"
        script.write_text(code + "\n", encoding="utf-8")
        return self._start_run(project_id, script, listener, None)

    @_api
    def stop_run(self) -> bool:
        self.runner.stop()
        return True

    @_api
    def send_run_input(self, text: str) -> bool:
        self.runner.send_input(text if text.endswith("\n") else text + "\n")
        return True

    @_api
    def run_state(self) -> str:
        return self.runner.state.value

    # ------------------------------------------------------------- terminal
    @_api
    def terminal_open(self, project_id: int | None = None) -> int:
        start = self.projects.project_dir(project_id) if project_id else None
        session = TerminalSession(
            self.projects.root, start, ScriptRunner(self._backend), self.scratch
        )
        with self._term_lock:
            sid = self._next_term
            self._next_term += 1
            self._terminals[sid] = session
        return sid

    def _term(self, sid: int) -> TerminalSession:
        with self._term_lock:
            if sid not in self._terminals:
                raise RuntimeError("Terminal session not found.")
            return self._terminals[sid]

    @_api
    def terminal_exec(self, sid: int, line: str, listener=None) -> dict:
        """``listener`` needs ``onOutput(text)`` and ``onDone(exitCode)``."""
        term = self._term(sid)
        emit = (lambda t: listener.onOutput(t)) if listener else (lambda t: None)
        done = (lambda c: listener.onDone(c)) if listener else (lambda c: None)
        out = term.execute(line, emit, done)
        out["prompt"] = term.prompt()
        return out

    @_api
    def terminal_prompt(self, sid: int) -> str:
        return self._term(sid).prompt()

    @_api
    def terminal_complete(self, sid: int, line: str) -> list:
        return self._term(sid).complete(line)

    @_api
    def terminal_history(self, sid: int) -> list:
        return list(self._term(sid).history)

    @_api
    def terminal_interrupt(self, sid: int) -> bool:
        self._term(sid).interrupt()
        return True

    @_api
    def terminal_input(self, sid: int, text: str) -> bool:
        self._term(sid).send_input(text if text.endswith("\n") else text + "\n")
        return True

    @_api
    def terminal_close(self, sid: int) -> bool:
        with self._term_lock:
            term = self._terminals.pop(sid, None)
        if term:
            term.interrupt()
        return True

    # ------------------------------------------------------------- packages
    @_api
    def packages_installed(self) -> list:
        return self.package_catalog.installed()

    @_api
    def packages_check(self, name: str, packs_json: str = "[]") -> dict:
        return self.package_catalog.check(name, json.loads(packs_json))

    @_api
    def packages_search(self, query: str, packs_json: str = "[]") -> list:
        return self.package_catalog.search(query, json.loads(packs_json))

    @_api
    def packages_catalog(self, packs_json: str = "[]") -> list:
        return self.package_catalog.catalog(json.loads(packs_json))

    # ------------------------------------------------------- example projects
    @_api
    def assist(self, kind: str, source: str, selection: str, question: str, error_json: str, module: str) -> dict:
        err = json.loads(error_json) if error_json else None
        return autofix_assist(kind, source, selection, question, err, module)

    @_api
    def autofix(self, source: str, error_type: str, message: str, line: int) -> dict:
        return autofix_diagnose(source, error_type, message, int(line))

    @_api
    def templates_list(self) -> list:
        return list_templates()

    @_api
    def templates_create(self, key: str) -> dict:
        return create_from_template(self.projects, key)

    # ---------------------------------------------------------------- GitHub
    # The token comes from Android Keystore-backed storage on every call; Python never stores it.
    @_api
    def github_user(self, token: str) -> dict:
        return GitHubClient(token).user()

    @_api
    def github_repos(self, token: str) -> list:
        return GitHubClient(token).repos()

    @_api
    def github_clone(self, token: str, owner: str, repo: str, branch: str, name: str) -> dict:
        return self.github.clone(GitHubClient(token), owner, repo, branch or None, name or None)

    @_api
    def github_status(self, project_id: int) -> dict:
        return self.github.status(project_id)

    @_api
    def github_push(self, token: str, project_id: int, message: str, new_branch: str) -> dict:
        return self.github.push(GitHubClient(token), project_id, message, new_branch or None)

    @_api
    def github_pull(self, token: str, project_id: int) -> dict:
        return self.github.pull(GitHubClient(token), project_id)

    @_api
    def github_unlink(self, project_id: int) -> bool:
        self.github.unlink(project_id)
        return True

    # ---------------------------------------------------- Packs companion app
    @_api
    def packs_export(self, project_id: int, dest_zip: str) -> str:
        """Commit open drafts, then zip the project so the Packs app can run it."""
        self.autosave.commit_all_drafts(project_id, "packs")
        return self.projects.export_project(project_id, dest_zip)

    @_api
    def packs_apply(self, project_id: int, result_zip: str) -> list:
        """Copy the files a Packs job produced back into the project (limits and path checks inside)."""
        return apply_result(result_zip, self.projects.project_dir(project_id))

    # -------------------------------------------------------------- debugger
    @_api
    def debug_start(self, project_id: int, rel: str, breakpoints_json: str, stop_on_entry: bool, listener=None) -> bool:
        if self._debug is not None and self._debug.active:
            raise RuntimeError("A debug session is already running. Stop it first.")
        if self.runner.is_running:
            raise RuntimeError("A script is running. Stop it before debugging.")
        root = self.projects.project_dir(project_id)

        def forward(event: dict) -> None:
            if listener is not None:
                try:
                    listener.onEvent(json.dumps(event))
                except Exception:  # noqa: BLE001 - UI problems must not kill the debugged script
                    log.exception("debug listener failed")

        session = DebugSession(root, forward)
        raw = json.loads(breakpoints_json or "{}")
        session.start(rel, {k: [int(n) for n in v] for k, v in raw.items()}, stop_on_entry=bool(stop_on_entry))
        self._debug = session
        return True

    @_api
    def debug_command(self, cmd: str) -> bool:
        if self._debug is None:
            raise RuntimeError("No debug session is running.")
        self._debug.command(cmd)
        return True

    @_api
    def debug_set_breakpoints(self, rel: str, lines_json: str) -> bool:
        if self._debug is None:
            raise RuntimeError("No debug session is running.")
        self._debug.set_breakpoints(rel, json.loads(lines_json))
        return True

    # ---------------------------------------------------------- opencv studio
    def _studio(self, project_id: int) -> VisionStudio:
        return VisionStudio(self.projects.project_dir(project_id))

    @_api
    def vision_project_path(self, project_id: int) -> str:
        return str(self.projects.project_dir(project_id))

    @_api
    def vision_operations(self) -> list:
        return VisionStudio(self.data_dir).operations()

    @_api
    def vision_info(self, project_id: int, rel: str) -> dict:
        return self._studio(project_id).info(rel)

    @_api
    def vision_process(self, project_id: int, rel: str, steps_json: str, out_rel: str) -> dict:
        return self._studio(project_id).process(rel, json.loads(steps_json), out_rel)

    # ------------------------------------------------------------- backend
    def _bk(self) -> SupabaseClient:
        if self._backend_client is None:
            raise BackendError("The online backend is not set up in this build.")
        return self._backend_client

    @_api
    def backend_configure(self, url: str, anon_key: str) -> dict:
        """Called once at start with build-time public values. Empty values = backend not configured."""
        if not (url or "").strip() or not (anon_key or "").strip():
            self._backend_client = None
            return {"configured": False}
        self._backend_client = SupabaseClient(url, anon_key)
        return {"configured": True}

    @_api
    def backend_sign_up(self, email: str, password: str) -> dict:
        return self._bk().sign_up(email, password)

    @_api
    def backend_sign_in(self, email: str, password: str) -> dict:
        s = self._bk().sign_in(email, password)
        return {**s, **self._bk().my_profile(s["access_token"], s["user_id"])}

    @_api
    def backend_refresh(self, refresh_token: str) -> dict:
        s = self._bk().refresh(refresh_token)
        return {**s, **self._bk().my_profile(s["access_token"], s["user_id"])}

    @_api
    def backend_sign_out(self, access_token: str) -> bool:
        self._bk().sign_out(access_token)
        return True

    @_api
    def backend_pull_ads(self) -> dict:
        """Fetch the admin-published ads config and apply it locally (validated). Returns the active config."""
        remote = self._bk().get_ads_config()
        return self.admin.apply_remote_config(remote) if remote else self.admin.get_ads_config()

    @_api
    def backend_push_ads(self, access_token: str, updates_json: str) -> dict:
        """Admin only (enforced by the server's row-level security). Validated locally first."""
        cfg = self.admin._apply(json.loads(updates_json))
        self._bk().set_ads_config(access_token, cfg)
        return cfg

    @_api
    def backend_admin_stats(self, access_token: str) -> dict:
        return self._bk().admin_stats(access_token)

    @_api
    def backend_log_event(self, access_token: str, name: str) -> bool:
        self._bk().log_event(access_token or None, name)
        return True

    # ---------------------------------------------------------- admin & ads
    @_api
    def admin_login(self, password: str) -> str:
        return self.admin.login(password)

    @_api
    def admin_logout(self, token: str) -> bool:
        self.admin.logout(token)
        return True

    @_api
    def admin_change_password(self, token: str, current: str, new: str) -> bool:
        self.admin.change_password(token, current, new)
        return True

    @_api
    def ads_get_config(self) -> dict:
        return self.admin.get_ads_config()

    @_api
    def admin_set_ads_config(self, token: str, updates_json: str) -> dict:
        return self.admin.set_ads_config(token, json.loads(updates_json))

    @_api
    def ads_unlock_status(self) -> dict:
        return self.admin.unlock_status()

    @_api
    def ads_grant_unlock(self) -> dict:
        """Called only after the ad SDK reports a completed rewarded ad."""
        return self.admin.grant_unlock()

    @_api
    def admin_test_unlock(self, token: str) -> dict:
        return self.admin.admin_test_unlock(token)

    # ----------------------------------------------------------------- misc
    @_api
    def runtime_info(self) -> dict:
        return {
            "python": sys.version.split()[0],
            "backend": self._backend.name,
            "can_hard_stop": self._backend.name == "subprocess",
            "notes": COMPATIBILITY_NOTES,
        }

    @_api
    def log_tail(self, max_lines: int = 200) -> str:
        path = self.data_dir / "logs" / "runtime.log"
        if not path.exists():
            return ""
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        return "\n".join(lines[-max_lines:])

    def shutdown(self) -> None:
        if self._debug is not None:
            self._debug.stop()
        self.runner.stop()
        for sid in list(self._terminals):
            self.terminal_close(sid)
        self.db.close()


def create_app(data_dir: str, in_process: bool | None = None) -> Py3xApi:
    backend = None
    if in_process is True:
        from runtime import InProcessBackend

        backend = InProcessBackend()
    return Py3xApi(data_dir, backend)
