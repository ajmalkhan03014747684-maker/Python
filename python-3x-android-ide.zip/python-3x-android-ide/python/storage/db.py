"""SQLite storage for Python 3.x.

One small wrapper around ``sqlite3`` with a versioned schema. All access goes
through a lock so the UI thread, the autosave thread and the runner thread can
share one connection safely.
"""

from __future__ import annotations

import sqlite3
import threading
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterable, Iterator

SCHEMA_VERSION = 1

_SCHEMA_V1 = """
CREATE TABLE projects (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    slug        TEXT NOT NULL UNIQUE,
    main_file   TEXT NOT NULL DEFAULT 'main.py',
    created_at  REAL NOT NULL,
    modified_at REAL NOT NULL,
    deleted_at  REAL
);
CREATE TABLE settings (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
CREATE TABLE recent_files (
    project_id INTEGER NOT NULL,
    rel_path   TEXT NOT NULL,
    opened_at  REAL NOT NULL,
    PRIMARY KEY (project_id, rel_path)
);
CREATE TABLE favorites (
    project_id INTEGER NOT NULL,
    rel_path   TEXT NOT NULL,
    created_at REAL NOT NULL,
    PRIMARY KEY (project_id, rel_path)
);
CREATE TABLE drafts (
    project_id INTEGER NOT NULL,
    rel_path   TEXT NOT NULL,
    content    TEXT NOT NULL,
    base_hash  TEXT NOT NULL,
    updated_at REAL NOT NULL,
    PRIMARY KEY (project_id, rel_path)
);
CREATE TABLE file_versions (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL,
    rel_path   TEXT NOT NULL,
    content    TEXT NOT NULL,
    content_hash TEXT NOT NULL,
    reason     TEXT NOT NULL,
    created_at REAL NOT NULL
);
CREATE INDEX idx_versions_file ON file_versions (project_id, rel_path, id);
CREATE TABLE trash (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL,
    original_rel TEXT NOT NULL,
    trash_rel  TEXT NOT NULL,
    is_dir     INTEGER NOT NULL,
    deleted_at REAL NOT NULL
);
"""


class Database:
    """Thread-safe SQLite wrapper with schema migration."""

    def __init__(self, path: str | Path):
        self.path = str(path)
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(self.path, check_same_thread=False, isolation_level=None)
        self._conn.row_factory = sqlite3.Row
        with self._lock:
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA foreign_keys=ON")
        self._migrate()

    def _migrate(self) -> None:
        with self.transaction() as conn:
            version = conn.execute("PRAGMA user_version").fetchone()[0]
            if version > SCHEMA_VERSION:
                raise RuntimeError(
                    f"Database schema {version} is newer than this app supports "
                    f"({SCHEMA_VERSION}). Update the app."
                )
            if version < 1:
                for statement in _SCHEMA_V1.split(";"):
                    if statement.strip():
                        conn.execute(statement)
            conn.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")

    @contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        with self._lock:
            try:
                self._conn.execute("BEGIN")
                yield self._conn
                self._conn.execute("COMMIT")
            except BaseException:
                if self._conn.in_transaction:
                    self._conn.execute("ROLLBACK")
                raise

    def execute(self, sql: str, params: Iterable[Any] = ()) -> int:
        """Run a write statement in its own transaction; returns lastrowid."""
        with self.transaction() as conn:
            return conn.execute(sql, tuple(params)).lastrowid or 0

    def query(self, sql: str, params: Iterable[Any] = ()) -> list[sqlite3.Row]:
        with self._lock:
            return self._conn.execute(sql, tuple(params)).fetchall()

    def query_one(self, sql: str, params: Iterable[Any] = ()) -> sqlite3.Row | None:
        rows = self.query(sql, params)
        return rows[0] if rows else None

    # -- settings -----------------------------------------------------
    def get_setting(self, key: str, default: str | None = None) -> str | None:
        row = self.query_one("SELECT value FROM settings WHERE key = ?", (key,))
        return row["value"] if row else default

    def set_setting(self, key: str, value: str) -> None:
        self.execute(
            "INSERT INTO settings(key, value) VALUES(?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            (key, value),
        )

    def close(self) -> None:
        with self._lock:
            self._conn.close()


def now() -> float:
    return time.time()
