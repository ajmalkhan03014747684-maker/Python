"""Autosave: drafts, version history and unsaved-change detection.

Flow
----
* While typing, the UI calls :meth:`update_draft` after a debounce. A draft is a
  row in SQLite; the file on disk is untouched, so a crash can never corrupt it.
* :meth:`commit` writes the file atomically, clears the draft and records a
  version snapshot (history is pruned to ``MAX_VERSIONS`` per file).
* Discarding a draft is non-destructive: the content is kept in version history.
"""

from __future__ import annotations

from typing import Any

from projects.manager import ProjectManager, content_hash
from projects.paths import PathError
from storage.db import Database, now

MAX_VERSIONS = 50


class AutosaveService:
    def __init__(self, db: Database, projects: ProjectManager):
        self.db = db
        self.projects = projects

    # --------------------------------------------------------------- drafts
    def update_draft(self, project_id: int, rel: str, content: str, base_hash: str) -> dict:
        """Store the latest editor text. Cheap; safe to call often."""
        rel = rel.strip("/")
        self.projects.project_dir(project_id)  # validates project exists
        self.db.execute(
            "INSERT INTO drafts(project_id, rel_path, content, base_hash, updated_at) "
            "VALUES(?,?,?,?,?) ON CONFLICT(project_id, rel_path) DO UPDATE SET "
            "content = excluded.content, base_hash = excluded.base_hash, "
            "updated_at = excluded.updated_at",
            (project_id, rel, content, base_hash, now()),
        )
        return {"saved_at": now(), "status": "draft"}

    def get_draft(self, project_id: int, rel: str) -> dict | None:
        row = self.db.query_one(
            "SELECT * FROM drafts WHERE project_id = ? AND rel_path = ?",
            (project_id, rel.strip("/")),
        )
        if row is None:
            return None
        return {
            "content": row["content"],
            "base_hash": row["base_hash"],
            "updated_at": row["updated_at"],
        }

    def list_drafts(self) -> list[dict]:
        rows = self.db.query(
            "SELECT d.*, p.name FROM drafts d JOIN projects p ON p.id = d.project_id "
            "WHERE p.deleted_at IS NULL ORDER BY d.updated_at DESC"
        )
        return [
            {
                "project_id": r["project_id"],
                "project_name": r["name"],
                "rel": r["rel_path"],
                "updated_at": r["updated_at"],
                "base_hash": r["base_hash"],
            }
            for r in rows
        ]

    def has_unsaved_changes(self, project_id: int, rel: str) -> bool:
        """True if a draft exists whose content differs from the file on disk."""
        draft = self.get_draft(project_id, rel)
        if draft is None:
            return False
        try:
            disk = self.projects.read_file(project_id, rel)
        except PathError:
            return True  # file vanished or unreadable; the draft is the only copy
        return content_hash(draft["content"]) != disk["hash"]

    def _drop_draft(self, project_id: int, rel: str) -> None:
        self.db.execute(
            "DELETE FROM drafts WHERE project_id = ? AND rel_path = ?", (project_id, rel.strip("/"))
        )

    # ------------------------------------------------------------- commits
    def commit(self, project_id: int, rel: str, content: str, reason: str = "save") -> dict:
        """Write to disk, snapshot into history, clear the draft."""
        digest = self.projects.write_file(project_id, rel, content)
        self._add_version(project_id, rel.strip("/"), content, digest, reason)
        self._drop_draft(project_id, rel)
        return {"hash": digest, "saved_at": now(), "status": "saved"}

    def commit_all_drafts(self, project_id: int | None = None, reason: str = "run") -> list[str]:
        """Write every draft (optionally one project's) to disk. Used before running."""
        committed: list[str] = []
        for item in self.list_drafts():
            if project_id is not None and item["project_id"] != project_id:
                continue
            draft = self.get_draft(item["project_id"], item["rel"])
            if draft is None:
                continue
            self.commit(item["project_id"], item["rel"], draft["content"], reason)
            committed.append(item["rel"])
        return committed

    def discard_draft(self, project_id: int, rel: str) -> None:
        """Drop a draft but keep its text in history, so nothing is lost for good."""
        draft = self.get_draft(project_id, rel)
        if draft is not None:
            self._add_version(
                project_id, rel.strip("/"), draft["content"],
                content_hash(draft["content"]), "discarded_draft",
            )
        self._drop_draft(project_id, rel)

    # ------------------------------------------------------------- history
    def _add_version(self, project_id: int, rel: str, content: str, digest: str, reason: str) -> None:
        last = self.db.query_one(
            "SELECT content_hash FROM file_versions WHERE project_id = ? AND rel_path = ? "
            "ORDER BY id DESC LIMIT 1",
            (project_id, rel),
        )
        if last is not None and last["content_hash"] == digest:
            return
        self.db.execute(
            "INSERT INTO file_versions(project_id, rel_path, content, content_hash, reason, created_at) "
            "VALUES(?,?,?,?,?,?)",
            (project_id, rel, content, digest, reason, now()),
        )
        self.db.execute(
            "DELETE FROM file_versions WHERE project_id = ? AND rel_path = ? AND id NOT IN ("
            "SELECT id FROM file_versions WHERE project_id = ? AND rel_path = ? "
            "ORDER BY id DESC LIMIT ?)",
            (project_id, rel, project_id, rel, MAX_VERSIONS),
        )

    def list_versions(self, project_id: int, rel: str) -> list[dict[str, Any]]:
        rows = self.db.query(
            "SELECT id, content_hash, reason, created_at, length(content) AS size "
            "FROM file_versions WHERE project_id = ? AND rel_path = ? ORDER BY id DESC",
            (project_id, rel.strip("/")),
        )
        return [dict(r) for r in rows]

    def get_version(self, version_id: int) -> dict[str, Any]:
        row = self.db.query_one("SELECT * FROM file_versions WHERE id = ?", (version_id,))
        if row is None:
            raise PathError("Version not found.")
        return {
            "id": row["id"],
            "content": row["content"],
            "reason": row["reason"],
            "created_at": row["created_at"],
        }
