from .service import MAX_VERSIONS, AutosaveService

__all__ = ["AutosaveService", "MAX_VERSIONS"]
