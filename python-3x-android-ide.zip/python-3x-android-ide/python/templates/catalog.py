"""Example projects. Each is a small, real program that works with the libraries named in ``needs``.

``runs_in`` says where it runs: ``main`` (the IDE's Python 3.12) or ``packs`` (the Python 3.10 Packs app,
needed for SciPy / scikit-learn / OpenCV). Nothing here is downloaded: the files are plain strings.
"""

from __future__ import annotations

from typing import Any

from projects.paths import PathError, resolve_inside


class TemplateError(ValueError):
    pass


_README = "# {title}\n\n{desc}\n\nRuns in: {where}. Needs: {needs}.\n"

TEMPLATES: dict[str, dict[str, Any]] = {
    "data-analysis": {
        "title": "Data Analysis",
        "desc": "Build a table with pandas, group it and summarise it.",
        "needs": "pandas",
        "runs_in": "main",
        "files": {
            "main.py": '''"""Data analysis with pandas."""
import pandas as pd

sales = pd.DataFrame({
    "region": ["North", "South", "North", "East", "South", "East", "North"],
    "product": ["A", "A", "B", "B", "A", "A", "B"],
    "units": [12, 7, 9, 15, 4, 11, 6],
    "price": [2.5, 2.5, 4.0, 4.0, 2.5, 2.5, 4.0],
})
sales["revenue"] = sales["units"] * sales["price"]

print("First rows:")
print(sales.head(), "\\n")
print("Revenue by region:")
print(sales.groupby("region")["revenue"].sum().sort_values(ascending=False), "\\n")
print("Summary:")
print(sales[["units", "revenue"]].describe())
''',
        },
    },
    "plot-graphs": {
        "title": "Plot Graphs",
        "desc": "Draw charts with matplotlib and save them as PNG files you can open in Files.",
        "needs": "matplotlib, numpy",
        "runs_in": "main",
        "files": {
            "main.py": '''"""Plot graphs with matplotlib. Android has no window, so charts are saved as PNG files."""
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

x = np.linspace(0, 2 * np.pi, 200)
fig, ax = plt.subplots(figsize=(6, 3.5))
ax.plot(x, np.sin(x), label="sin")
ax.plot(x, np.cos(x), label="cos")
ax.set_title("Sine and cosine")
ax.legend()
fig.tight_layout()
fig.savefig("plot.png", dpi=120)
print("Saved plot.png - open it from the Files tab.")
''',
        },
    },
    "statistics": {
        "title": "Statistics",
        "desc": "Mean, spread and correlation with numpy and the standard library.",
        "needs": "numpy",
        "runs_in": "main",
        "files": {
            "main.py": '''"""Basic statistics."""
import statistics

import numpy as np

heights = [162, 170, 168, 175, 180, 158, 172, 169, 177, 165]
weights = [55, 68, 63, 74, 82, 50, 70, 66, 78, 60]

print("mean   :", statistics.mean(heights))
print("median :", statistics.median(heights))
print("stdev  :", round(statistics.stdev(heights), 2))
print("range  :", min(heights), "to", max(heights))
print("correlation height/weight:", round(float(np.corrcoef(heights, weights)[0, 1]), 3))
''',
        },
    },
    "machine-learning": {
        "title": "Machine Learning",
        "desc": "Train and test a classifier with scikit-learn.",
        "needs": "scikit-learn (needs the Packs app: use the PACKS button)",
        "runs_in": "packs",
        "files": {
            "main.py": '''"""Machine learning with scikit-learn. Run this with the PACKS button (Python 3.10)."""
from sklearn.datasets import make_classification
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

X, y = make_classification(n_samples=400, n_features=6, n_informative=4, random_state=0)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=0)

model = LogisticRegression(max_iter=500).fit(X_train, y_train)
print("train accuracy:", round(model.score(X_train, y_train), 3))
print("test accuracy :", round(model.score(X_test, y_test), 3))
''',
        },
    },
    "game-guess": {
        "category": "game",
        "title": "Game: Guess the Number",
        "desc": "A console game: guess the secret number with higher/lower hints.",
        "needs": "nothing (standard library). Type your guesses in the input box on the Run page.",
        "runs_in": "main",
        "files": {
            "main.py": '''"""Guess the number."""
import random

secret = random.randint(1, 100)
tries = 0
print("I am thinking of a number from 1 to 100.")
while True:
    text = input("Your guess: ").strip()
    if not text.isdigit():
        print("Please type a whole number.")
        continue
    guess = int(text)
    tries += 1
    if guess < secret:
        print("Higher!")
    elif guess > secret:
        print("Lower!")
    else:
        print(f"Correct! You needed {tries} tries.")
        break
''',
        },
    },
    "game-tictactoe": {
        "category": "game",
        "title": "Game: Tic-Tac-Toe",
        "desc": "Two players take turns on one phone. Enter a square number 1-9.",
        "needs": "nothing (standard library)",
        "runs_in": "main",
        "files": {
            "main.py": '''"""Tic-Tac-Toe for two players."""
board = [" "] * 9
LINES = [(0, 1, 2), (3, 4, 5), (6, 7, 8), (0, 3, 6), (1, 4, 7), (2, 5, 8), (0, 4, 8), (2, 4, 6)]


def show():
    for r in range(3):
        print(" " + " | ".join(board[r * 3:r * 3 + 3]))
        if r < 2:
            print("---+---+---")


def winner():
    for a, b, c in LINES:
        if board[a] != " " and board[a] == board[b] == board[c]:
            return board[a]
    return None


player = "X"
for _ in range(9):
    show()
    while True:
        text = input(f"{player}, choose a square (1-9): ").strip()
        if text.isdigit() and 1 <= int(text) <= 9 and board[int(text) - 1] == " ":
            board[int(text) - 1] = player
            break
        print("That square is not available.")
    if winner():
        show()
        print(f"{player} wins!")
        break
    player = "O" if player == "X" else "X"
else:
    show()
    print("It is a draw.")
''',
        },
    },
    "game-hangman": {
        "category": "game",
        "title": "Game: Hangman",
        "desc": "Guess the hidden word one letter at a time before you run out of lives.",
        "needs": "nothing (standard library)",
        "runs_in": "main",
        "files": {
            "main.py": '''"""Hangman."""
import random

words = ["python", "android", "keyboard", "function", "variable", "program", "loop", "module"]
word = random.choice(words)
found = set()
lives = 6
while lives > 0:
    shown = " ".join(c if c in found else "_" for c in word)
    print(f"\\n{shown}   (lives: {lives})")
    if all(c in found for c in word):
        print("You won!")
        break
    letter = input("Letter: ").strip().lower()
    if len(letter) != 1 or not letter.isalpha():
        print("Type one letter.")
        continue
    if letter in found:
        print("You already tried that.")
        continue
    found.add(letter)
    if letter not in word:
        lives -= 1
        print("Not in the word.")
else:
    print(f"You lost. The word was {word}.")
''',
        },
    },
}


def list_templates() -> list[dict[str, str]]:
    return [
        {"key": k, "title": t["title"], "desc": t["desc"], "needs": t["needs"], "runs_in": t["runs_in"],
         "category": t.get("category", "data")}
        for k, t in TEMPLATES.items()
    ]


def create_from_template(projects, key: str) -> dict:
    t = TEMPLATES.get(key)
    if t is None:
        raise TemplateError("Unknown example project.")
    project = projects.create_project(t["title"], template=False)
    root = projects.project_dir(project["id"])
    try:
        files = dict(t["files"])
        files["README.md"] = _README.format(
            title=t["title"], desc=t["desc"], needs=t["needs"], where="the Packs app" if t["runs_in"] == "packs" else "this app"
        )
        for rel, content in files.items():
            target = resolve_inside(root, rel)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding="utf-8", newline="\n")
    except PathError as exc:  # cannot happen with the built-in names, but never leave a half project behind
        projects.delete_project(project["id"])
        projects.purge_project(project["id"])
        raise TemplateError(str(exc)) from exc
    return projects.get_project(project["id"])
