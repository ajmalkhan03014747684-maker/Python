"""Ready-made example projects (Data Science hub)."""

from .catalog import TEMPLATES, TemplateError, create_from_template, list_templates

__all__ = ["TEMPLATES", "TemplateError", "create_from_template", "list_templates"]
