# Troubleshooting
- Runtime fails to start: Settings → View runtime log; the app shows details on the error screen.
- Stop does nothing: the script is in native code. Settings → Restart runtime (drafts are kept).
- Unsaved work after a crash: a Recover dialog appears at next launch.
- First Gradle sync fails: check JDK 17 and that Maven Central, Google and Chaquopy repositories are reachable.
