# Android build
Requirements: JDK 17, Android SDK platform 35, Gradle 8.10.x, Python 3.12 **and** 3.10 on the build machine (Chaquopy uses them to bundle packages).

Two Gradle modules, both using Chaquopy 17:
- `:app` - the IDE, Python 3.12 (`android/app/build.gradle.kts`), packages from the `py3xPackages` property.
- `:packs` - the companion "Python 3.x Packs" app, Python 3.10 (`android/packs/build.gradle.kts`), packages from `py3xPacksPackages`. arm64 only.

Build order (see the CI workflow): `:packs:assembleFast`, copy its APK to `android/app/src/main/assets/packs/python3x-packs.apk`,
then `:app:assembleFast`. The IDE then contains the Packs installer, and the Package Manager's *Install* button offers it to Android's installer.
Both APKs must be signed with the same key (signature permission `com.py3x.permission.PACKS`). Run the `make-signing-key` workflow once and save its output as the repository secret `PY3X_KEYSTORE_B64`; `build.yml` then signs every build with that permanent key (without it the key is only kept in the GitHub cache, which expires after 7 days unused).
If you rebuild with a different key, uninstall both apps first (this deletes the IDE's local projects).

Known unknown: the Kotlin sources have only ever been compiled by CI; report any build error with the log.
