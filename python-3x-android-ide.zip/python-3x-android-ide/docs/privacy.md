# Privacy
Projects are stored locally (app-private storage). No analytics, no accounts, no cloud sync yet.
Network use happens only when you start it:
- **GitHub**: requests to api.github.com with your token when you connect, clone, push or pull. Pushed files go to the repository you chose.
- **AI assistant**: when you tap a button, the question and the selected code (or open file) are sent to the provider you configured, with your API key. That provider's terms and retention apply. Nothing is sent otherwise.
- **Ads** (off by default; the admin enables them): the Google AdMob SDK loads ads and may collect device and advertising identifiers (it adds the AD_ID permission). With the default sample ids only test ads appear. This build has no consent (UMP) dialog, so do not enable real ads for users in regions that require consent until one is added.
- **Packs app**: when you use PACKS or OpenCV Studio, a temporary copy of the current project is handed to the Python 3.x Packs app on the same phone and removed after the job. That app has no internet permission.
