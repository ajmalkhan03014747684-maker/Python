# Security
- Main app permissions: `INTERNET` and `ACCESS_NETWORK_STATE` (GitHub, the AI provider you choose, AdMob when enabled), `REQUEST_INSTALL_PACKAGES` (only to open Android's installer for the bundled Packs app; Android asks for confirmation) and the signature permission `com.py3x.permission.PACKS`. The Packs app has no INTERNET permission.
- Network code (`python/netutil.py`): HTTPS only, per-feature host allow-list (GitHub: api.github.com + codeload.github.com; AI: only the one provider host you configured), bounded response size, redirects only to allowed hosts with the Authorization header dropped when the host changes.
- Secrets: the GitHub token and AI API key are encrypted with an AES-GCM key held in the Android Keystore (`SecureStore`), excluded from backups, passed to Python per call and never stored or logged there. Nothing secret is in the repo or the APK. The AI assistant is bring-your-own-key: the key lives only on your phone; a server-side proxy comes with the Supabase milestone.
- The AI assistant only produces text. Nothing it returns is executed, and it can only see code you select or the file you have open when you tap a button.
- GitHub: no merging. Push refuses if the branch moved; pull refuses if local files changed; files over 5 MB are skipped; paths from the repository are validated (zip-slip).
- Main <-> Packs: bound Messenger service protected by a signature-level permission, so only an app signed with the same key can call it. Requests carry a zip of one project; results are a zip that the main app validates (zip-slip, file count, size, skipped internal folders) before copying into the same project. One job at a time.
- The bundled Packs installer is checked (package name and signing certificate) before it is handed to Android's installer. It is a first-party app built in the same CI run, not a downloaded or arbitrary executable.
- Ads: the AdMob SDK is a normal build-time dependency (no dynamic SDK download). It is initialised only when the admin enables ads with provider AdMob; coding never depends on ads. By default only Google's sample ids are used (test ads).
- Admin panel is a local gate (PBKDF2 hash, lockouts), not server-side security; it only controls local ad settings.
- Path validation blocks `..`, absolute paths, reserved trash directory and symlink escapes; zip import blocks zip-slip and limits size/count. Terminal is confined to the project root. Deletion is soft by default.

- Backend: only the public Supabase anon key may be built into the app (a service-role key is refused at runtime). Admin rights and ad settings are enforced by row-level security on the server; the sign-in refresh token is kept in the Keystore store.

## Pre-publish check (done)
- No secrets in the repo or APK: only the public Supabase anon key and public ad IDs are built in; service-role keys are refused at runtime.
- HTTPS only (targetSdk 35 blocks cleartext), `allowBackup=false`, only the launcher activity is exported, Packs IPC protected by a signature permission.
- Ads: Google UMP consent runs before any ad request; Unity receives consent metadata; coding works with ads off or blocked.
- Still your job: replace the placeholders in `docs/privacy-policy.md`, host it at a public URL, and fill the Play Console data-safety form to match.
