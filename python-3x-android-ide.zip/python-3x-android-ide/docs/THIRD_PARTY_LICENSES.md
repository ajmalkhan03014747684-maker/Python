# Third-party components
- Chaquopy — MIT (Python runtime embedding; see chaquo.com)
- CPython — PSF License
- AndroidX / Jetpack Compose / Material3 — Apache 2.0
- Kotlin / kotlinx.coroutines — Apache 2.0
Verify exact versions and notices from the Gradle dependency report before release.
