# Privacy Policy — Python 3.x

_Last updated: <DATE>. Contact: <YOUR CONTACT EMAIL>. Replace the two placeholders before publishing._

## What stays on your device
Your projects, files, code, run output, settings and the offline AI helper's work all stay on your device. The app does not upload your code anywhere. Code you run executes locally.

## What the app sends over the internet, and only when you use it
- **Packages / GitHub:** when you use GitHub features, the app talks to GitHub with a token you provide. The token is stored encrypted with the Android Keystore and is never logged or sent anywhere else.
- **Account (optional):** if you create an account, your email address and a password are handled by our backend (Supabase). We store your email, a role (user or admin), and the time you signed up. Passwords are handled by Supabase and are never visible to us. You can use the whole app without an account.
- **Basic usage counts (only if you are signed in):** simple named events such as "app opened" or "reward ad completed". They carry no code, file names or content.
- **Ad settings:** the app downloads the current ad configuration (which ad network is on and its public ad unit IDs). No personal data is sent for this.

## Ads
Ads are optional and off unless the app owner switches them on. When on, Google AdMob or Unity Ads may collect device and advertising identifiers and show personalised or non-personalised ads, under their own policies:
- https://policies.google.com/technologies/ads
- https://unity.com/legal/privacy-policy
Where required by law (for example the EEA and UK) the app shows Google's consent form before any ad is requested, and an "Ad privacy choices" entry in More lets you change your choice later. Ads are never required to write or run code.

## Permissions
- Internet: for the features above.
- Camera (via the system camera app) and photo/file selection: only when you choose to use OpenCV Studio's camera or import files. The app does not access your camera on its own.
- Install packages permission: only to install the companion "Python 3.x Packs" app when you ask for it.

## Security
Secrets are encrypted on device. Network access is HTTPS only and limited to the services named above. The app cannot download or run extra native programs after installation.

## Your choices
Sign out any time in More. To delete your account and its data, email the contact address above. Uninstalling the app removes all local data.

## Children
The app is a general programming tool and is not directed at children under 13.

## Changes
We will update this page and its date when something changes.
