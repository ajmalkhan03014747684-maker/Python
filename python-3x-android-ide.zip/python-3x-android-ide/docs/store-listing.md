# Store listing draft (edit before publishing)

**Name:** Python 3.x
**Short description (80 chars):** Write, run and debug Python 3 on your phone, offline.
**Full description:**
Python 3.x is a pocket Python IDE. Write code with syntax colours and autosave, run it in a full-screen console (including input()), step through it with the debugger, and keep projects organised on your device.

• Offline Python 3.12 runtime, nothing uploaded
• Editor with tabs, find, line jump, word wrap and light/dark themes
• Full-screen console with colour and cursor support
• Breakpoint debugger
• Offline AI helper that explains errors and suggests fixes — no key, no account
• Package manager showing honestly which libraries work on Android
• Optional companion "Python 3.x Packs" app: OpenCV, SciPy, scikit-learn, scikit-image, statsmodels
• OpenCV Studio, data-science examples and text games
• GitHub clone / push / pull

Ads are optional: a short rewarded ad can unlock advanced tools for a limited time; coding and running scripts stay free.

**Honest limits to keep in the listing:** no Pygame or desktop GUI windows; OpenCV works on one image/frame at a time; packages are bundled at build time.
**Category:** Tools / Education. **Content rating:** Everyone. **Data safety:** email (optional account), app activity counts (signed-in), advertising ID (when ads are on); data encrypted in transit; account deletion by email request.
