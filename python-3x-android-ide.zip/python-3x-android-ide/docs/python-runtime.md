# Python runtime
CPython (via Chaquopy) runs in-process. Output is capped at 2,000,000 characters; editor files at 2 MB. Scripts run with the project as working directory and project modules are purged between runs.
Limits: no true process kill on Android (cooperative stop); scripts blocked in native code need a runtime restart; no `fork`/subprocess guarantees on Android.

## Two runtimes
Chaquopy embeds exactly one Python version per APK, and the Android wheels for scipy, scikit-learn, scikit-image, OpenCV and
statsmodels exist only for Python 3.10. So:
- **Python 3.x** (main app) runs Python 3.12 with numpy, pandas, matplotlib, pillow, lxml, pyyaml and pure-Python libraries.
- **Python 3.x Packs** (companion app) runs Python 3.10 with those plus scipy, scikit-learn, opencv-python.
The editor's **PACKS** button sends a copy of the project to the companion, runs the file there with live output, and copies the
files it created or changed back. OpenCV Studio runs the same way. Pygame, torch and tensorflow have no usable Android wheels in either.

## Known limitation: Python 3.10 busy loops (Packs app only)
CPython 3.10 never releases the interpreter lock inside a loop of the exact shape `while True: try: pass / except: pass`
(fixed in 3.11), so such a script freezes the Packs app until it is restarted. Ordinary busy loops and anything that calls a function or sleeps are fine.
