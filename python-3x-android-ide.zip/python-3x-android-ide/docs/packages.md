# Packages
Android cannot run `pip install` at runtime, so the in-app Package Manager is an honest *catalog*, not a pip: it lists what is
importable in this build, what the Packs companion app contains, and what the compatibility catalog knows about a name
(`stdlib`, `bundled`, `in-packs`, `packs`, `buildable`, `pure-python`, `unsupported`, `unknown`). It never claims a package works unless it is present.

## Which app has what
- Main app (Python 3.12): `py3xPackages`. Default CI set: numpy, pandas, matplotlib, pillow, pyyaml, lxml, sympy, beautifulsoup4, jinja2, rich, tqdm, click.
- Packs app (Python 3.10): `py3xPacksPackages`. Default CI set adds scipy, scikit-learn, opencv-python.
- scikit-image (0.18.x) and statsmodels (0.14.x) are added to the Packs app by default in CI via `PY3X_PACKS_EXTRA`. Not bundled: cryptography.

## Adding packages
Packages with native code must have an Android wheel in the Chaquopy repository for that app's Python version.
Set the Gradle property (`-Ppy3xPackages=...` / `-Ppy3xPacksPackages=...`) or the CI environment variables
`ORG_GRADLE_PROJECT_py3xPackages` / `ORG_GRADLE_PROJECT_py3xPacksPackages` and rebuild. Large packages greatly increase APK size.

## Install flow for Packs
*Package Manager -> Install* copies the Packs APK that is stored inside the main app to a private cache folder, checks that it is
the `com.py3x.packs` package signed with the same key, and opens Android's installer, which asks for confirmation. Nothing is downloaded.

## Not possible
- `pygame`: no Android wheel -> Pygame Studio cannot be built. `opencv-python-headless` is not in the repository either; use `opencv-python`.
- `torch`, `tensorflow`, `h5py`: no usable Android wheels for Python 3.10 or 3.12.
- Desktop GUI toolkits (tkinter, PyQt, Kivy).
