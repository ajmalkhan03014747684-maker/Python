# Roadmap
Done: core IDE, package catalog, breakpoint debugger (bdb), hidden local admin panel with ad settings, OpenCV Studio, two-app design (IDE on Python 3.12 + Packs companion on Python 3.10 for OpenCV/SciPy/scikit-learn).
Done after that: GitHub (clone/status/push/pull), bring-your-own-key AI assistant, AdMob banner + rewarded 1-hour ad-free unlock, image preview, permanent signing key workflow.
Still open: Supabase backend (accounts, sync, server-side admin and AI proxy), consent (UMP) dialog and Unity/LevelPlay adapters for ads, scikit-image/statsmodels in Packs, Pygame Studio (impossible on Android without a wheel).

1. Core IDE.
2. Package manager + compatibility engine; debugger.
3. OpenCV Studio (via Packs), AI/ML notes. Pygame Studio is not possible.
4. Supabase auth/RLS/edge functions, remote config, admin dashboard.
5. Ads architecture (AdMob / LevelPlay adapters), rewarded 1-hour unlock - coding must always work without ads.
6. GitHub integration, AI assistant abstraction (server-side keys only).

## Redesign (in stages)
- Stage 1 (this build): new colour system, bottom navigation (Home, Projects, Terminal, Tools, More), splash with progress, onboarding, Home dashboard, Tools hub, More tab, Data Science examples, unlock countdown. Game Studio is shown honestly as unavailable (pygame has no Android build).
- Stage 2: editor, terminal, Package Manager, file and project screens.
- Stage 3: debugger, OpenCV Studio, AI assistant, settings, admin panel.
- Then: Supabase backend.

## Stage 1.1 (feedback round)
- Run opens a full-screen Run page (output only, STOP/DEBUG on top, error helper above the output).
- Offline error helper (`python/autofix`): explains common errors and proposes one-line fixes with no API key or network. The chat/explain/improve AI still needs the person's own key; a keyless chat would need a server (planned with Supabase).
- Packages, AI and OpenCV pages scroll; OpenCV uses its own hidden "OpenCV Studio" project and can save the result anywhere.
- Defaults: light theme, word wrap on (new installs).

## Stage 1.2
- AI Assistant is fully offline (no key, model or address fields). Explain, Fix, Improve, Tests, Docstrings and questions use rules and Python's own parser.
- Full-screen pages (Run, AI, Packages, OpenCV, Data Science, GitHub) are drawn inside the app layout so the phone's navigation bar can no longer cover the bottom buttons or input box.
- Packages shows a loading indicator until the lists are ready.

## Stage 3
- Restyled: Settings (grouped cards), Debugger panel, OpenCV Studio (tool tiles, Image/Camera/Video tabs with camera and video honestly marked "soon"), AI Assistant (action tiles), Admin panel (Overview, AdMob, Unity, Security tabs; Unity and user statistics are shown honestly as not available).

## Stage 3, part 2
- OpenCV Studio Camera tab: opens the phone's camera app (no background recording, no CAMERA permission), brings the photo back.
- OpenCV Studio Video tab: pick a video, choose a frame with a slider, process that frame. Whole-video processing is not built.
- Game Studio: three real console games (Guess the Number, Tic-Tac-Toe, Hangman) as editable projects. pygame itself cannot run on Android.

## Stage 2
- Package Manager: Popular / Installed / Updates tabs (honest: nothing is installed at runtime; Updates explains rebuilding).
- Terminal: always-dark console with quick-command chips.
- Files: coloured type badges with sizes, gradient actions, full-screen project manager (open, run, new, import).
- Editor: gradient RUN, tab underline, status bar (line, column, lines, spaces, encoding).

## Run page console
- Output is drawn on a small terminal screen (`AnsiScreen`): cursor moves, clear screen/line and colours are honoured, so ASCII animations redraw in place and fit the width.
- Scripts that read input get a blinking cursor at the end of the output; typing happens inline and Enter sends the line. The separate input box is gone.

## Stage: Supabase backend
- `supabase/setup.sql` + `supabase/README.md`: tables (profiles, app_settings, events), row-level security, auth trigger, admin-only `admin_stats()`.
- `python/backend`: GoTrue + PostgREST client using only the public anon key (refuses service-role keys, host locked to the project URL). Ads config published by an admin is validated locally before being applied.
- App: optional Account card (More tab), server-side admin (role = admin) with real counts; without backend values the app stays fully offline and keeps the local admin gate.
- Build: `PY3X_SUPABASE_URL` / `PY3X_SUPABASE_ANON_KEY` GitHub Actions variables.
- Not done: server-side AI proxy, UMP consent, Unity adapter, revenue figures (they live in AdMob).

## Admin: Ad Networks screen
- Admin panel tabs: Overview, Ad Networks, Security. Ad Networks has AdMob (App ID, Rewarded ID, optional Banner ID), Unity Ads (Game ID, Placement ID) and Reward unlock cards, one network on at a time. No AppLovin.
- IDs are format-checked in Python. AdMob App ID is only read by the SDK from the build, so the panel compares it with the built-in one and says when a rebuild (PY3X_ADMOB_APP_ID) is needed. Unity IDs are stored but the Unity SDK is not bundled, so no Unity ads show yet.

## Stage: ads consent, Unity, Packs extras, publishing
- Google UMP consent runs before the ad SDK starts; "Ad privacy choices" row in More when Google requires it.
- Unity Ads (rewarded only) bundled at build time; Game/Placement IDs from the admin panel; locks only apply when the IDs are set.
- Packs gets scikit-image and statsmodels by default (PY3X_PACKS_EXTRA variable to switch off).
- `docs/privacy-policy.md`, `docs/store-listing.md`, security check appended to `docs/security.md`.
- Unverified until CI builds: Kotlin changes (never compiled in this environment) and the two new Packs wheels resolving.

- AdMob App ID: typed in Admin -> Ad Networks, saved to the backend; the CI build reads it (variable > py3x-config.env > admin panel) because Android only reads the App ID from the installed app.
