plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.chaquo.python")
}

android {
    namespace = "com.py3x.packs"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.py3x.packs"
        minSdk = 24
        targetSdk = 35
        // Release builds pass -Ppy3xVersionCode / -Ppy3xVersionName (see the publish-release workflow).
        // versionCode must go up with every release the store or phones should accept as an update.
        versionCode = (findProperty("py3xVersionCode") as String?)?.trim()?.toIntOrNull() ?: 1
        versionName = (findProperty("py3xVersionName") as String?)?.trim()?.takeIf { it.isNotEmpty() } ?: "0.1.0"
        // arm64 only: this APK is also embedded in the main app, and phones are arm64.
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
        }
        // Same arrangement as the main app: optimised, signed with the debug key, fast to build.
        create("fast") {
            initWith(getByName("release"))
            isMinifyEnabled = false
            isShrinkResources = false
            signingConfig = signingConfigs.getByName("debug")
            matchingFallbacks += "release"
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

chaquopy {
    defaultConfig {
        // Python 3.10 is the version that has Android wheels for scipy, scikit-learn, OpenCV and friends.
        version = "3.10"
        // Packages bundled in the Packs app: -Ppy3xPacksPackages=a,b,c (CI: ORG_GRADLE_PROJECT_py3xPacksPackages).
        (findProperty("py3xPacksPackages") as String?)
            ?.split(",")?.map { it.trim() }?.filter { it.isNotEmpty() }
            ?.forEach { name -> pip { install(name) } }
    }
    sourceSets {
        getByName("main") { srcDir("../../python") }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
}
