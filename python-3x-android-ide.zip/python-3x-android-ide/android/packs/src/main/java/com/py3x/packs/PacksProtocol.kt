package com.py3x.packs

/**
 * Wire format between the main "Python 3.x" app and this app. The main app has an identical copy
 * (com.py3x.ide.packs.PacksProtocol); keep both in step and bump [VERSION] on incompatible changes.
 *
 * Client -> service
 *   MSG_INFO  (replyTo)                                  ask for protocol, Python version, packages
 *   MSG_RUN   job, kind, arg, zip(ParcelFileDescriptor)  run a job on a zip of the project
 *   MSG_STOP                                             stop the running job
 * Service -> client
 *   MSG_INFO_REPLY json                                  the "info" envelope from Python
 *   MSG_OUTPUT     stream, text                          streamed stdout / stderr
 *   MSG_FINISH     json, zip(ParcelFileDescriptor?)      result JSON + zip of changed files
 *   MSG_ERROR      message                               the job could not be started
 */
object PacksProtocol {
    const val VERSION = 1
    const val PERMISSION = "com.py3x.permission.PACKS"

    const val MSG_INFO = 1
    const val MSG_RUN = 2
    const val MSG_STOP = 3

    const val MSG_INFO_REPLY = 11
    const val MSG_OUTPUT = 12
    const val MSG_FINISH = 13
    const val MSG_ERROR = 14

    const val K_JOB = "job"
    const val K_KIND = "kind"
    const val K_ARG = "arg"
    const val K_ZIP = "zip"
    const val K_JSON = "json"
    const val K_STREAM = "stream"
    const val K_TEXT = "text"
    const val K_MESSAGE = "message"
}
