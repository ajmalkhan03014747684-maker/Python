package com.py3x.packs

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import org.json.JSONObject
import kotlin.concurrent.thread

/** The Packs app has no real UI: it explains itself and lists what it can run. Work arrives from the main app. */
class PacksActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            setBackgroundColor(Color.parseColor("#0B0F1A"))
        }
        fun text(value: String, size: Float, color: String, bold: Boolean = false) = TextView(this).apply {
            text = value; textSize = size; setTextColor(Color.parseColor(color))
            if (bold) setTypeface(typeface, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { bottomMargin = pad / 2 }
        }
        root.addView(text("Python 3.x Packs", 24f, "#E6EAF5", true))
        root.addView(text(
            "Companion app for Python 3.x. It runs Python 3.10 with extra libraries (OpenCV, SciPy, scikit-learn, …) " +
                "that are not available for the Python 3.12 used by the main app. Open Python 3.x and use “Run with Packs”, " +
                "or the OpenCV Studio. Nothing is sent over the network: this app has no internet permission.",
            14f, "#9AA6C4",
        ))
        status = text("Checking…", 13f, "#E6EAF5").apply { typeface = Typeface.MONOSPACE }
        root.addView(status)
        setContentView(ScrollView(this).apply { addView(root) })

        thread(name = "packs-info") {
            val line = try {
                if (!Python.isStarted()) Python.start(AndroidPlatform(applicationContext))
                val app = Python.getInstance().getModule("packs_main").callAttr("create_app", filesDir.absolutePath, true)
                val data = JSONObject(app.callAttr("info").toString()).getJSONObject("data")
                val pk = data.getJSONArray("packages")
                val names = (0 until pk.length()).joinToString("\n") { i ->
                    pk.getJSONObject(i).let { "${it.getString("name")} ${it.getString("version")}" }
                }
                "Python ${data.getString("python")}  ·  protocol ${data.getInt("protocol")}\n\nInstalled packages (${pk.length()}):\n$names"
            } catch (t: Throwable) {
                "Could not start Python: ${t.message ?: t.javaClass.simpleName}"
            }
            runOnUiThread { status.text = line }
        }
    }
}
