package com.py3x.packs

import android.app.Service
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Message
import android.os.Messenger
import android.os.ParcelFileDescriptor
import androidx.core.os.BundleCompat
import com.chaquo.python.PyObject
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import org.json.JSONObject
import java.io.File

/**
 * Runs jobs for the main app. Access is limited by a signature-level permission (see the manifest):
 * only an app signed with the same key can bind. Jobs run on a zip copy of the project, never on the
 * main app's files; results come back as a zip of changed files that the main app applies itself.
 */
class PacksService : Service() {
    private lateinit var thread: HandlerThread
    private lateinit var messenger: Messenger
    @Volatile private var api: PyObject? = null

    override fun onCreate() {
        super.onCreate()
        thread = HandlerThread("py3x-packs").also { it.start() }
        messenger = Messenger(Handler(thread.looper) { msg -> handle(msg); true })
    }

    override fun onBind(intent: Intent?): IBinder = messenger.binder

    override fun onDestroy() {
        runCatching { api?.callAttr("stop_job") }
        thread.quitSafely()
        super.onDestroy()
    }

    private fun python(): PyObject {
        api?.let { return it }
        if (!Python.isStarted()) Python.start(AndroidPlatform(applicationContext))
        val created = Python.getInstance().getModule("packs_main").callAttr("create_app", filesDir.absolutePath, true)
        api = created
        return created
    }

    private fun reply(to: Messenger?, what: Int, data: Bundle) {
        val m = Message.obtain(null, what).apply { this.data = data }
        runCatching { to?.send(m) }
    }

    private fun error(to: Messenger?, text: String) =
        reply(to, PacksProtocol.MSG_ERROR, Bundle().apply { putString(PacksProtocol.K_MESSAGE, text) })

    private fun handle(msg: Message) {
        val client = msg.replyTo
        try {
            when (msg.what) {
                PacksProtocol.MSG_INFO -> reply(
                    client, PacksProtocol.MSG_INFO_REPLY,
                    Bundle().apply { putString(PacksProtocol.K_JSON, python().callAttr("info").toString()) },
                )
                PacksProtocol.MSG_RUN -> run(msg, client)
                PacksProtocol.MSG_STOP -> python().callAttr("stop_job")
            }
        } catch (t: Throwable) {
            error(client, "Packs app error: ${t.message ?: t.javaClass.simpleName}")
        }
    }

    private fun run(msg: Message, client: Messenger?) {
        val data = msg.data
        data.classLoader = ParcelFileDescriptor::class.java.classLoader
        val job = data.getString(PacksProtocol.K_JOB).orEmpty()
        val kind = data.getString(PacksProtocol.K_KIND).orEmpty()
        val arg = data.getString(PacksProtocol.K_ARG).orEmpty()
        val pfd = BundleCompat.getParcelable(data, PacksProtocol.K_ZIP, ParcelFileDescriptor::class.java)
        if (pfd == null || job.isEmpty()) return error(client, "The job request was incomplete.")

        // Copy the incoming zip into private storage; Python reads it from there.
        val inbox = File(filesDir, "inbox").apply { mkdirs() }
        val zip = File(inbox, "$job.zip")
        try {
            ParcelFileDescriptor.AutoCloseInputStream(pfd).use { input -> zip.outputStream().use { input.copyTo(it) } }
        } catch (e: Exception) {
            return error(client, "Could not receive the project: ${e.message}")
        }

        val listener = JobListener(client, job, zip)
        val envelope = JSONObject(python().callAttr("start_job", job, zip.absolutePath, kind, arg, listener).toString())
        if (!envelope.getBoolean("ok")) {
            zip.delete()
            error(client, envelope.optString("error", "The job could not be started."))
        }
    }

    /** Called by Python (on its own threads) with streamed output and the final result. */
    inner class JobListener(private val client: Messenger?, private val job: String, private val inbox: File) {
        fun onOutput(stream: String, text: String) {
            reply(client, PacksProtocol.MSG_OUTPUT, Bundle().apply {
                putString(PacksProtocol.K_STREAM, stream)
                putString(PacksProtocol.K_TEXT, text)
            })
        }

        fun onFinish(resultJson: String) {
            val result = JSONObject(resultJson)
            val resultZip = result.optString("result_zip").takeIf { it.isNotEmpty() && it != "null" }?.let { File(it) }
            var pfd: ParcelFileDescriptor? = null
            try {
                if (resultZip != null && resultZip.isFile) pfd = ParcelFileDescriptor.open(resultZip, ParcelFileDescriptor.MODE_READ_ONLY)
                reply(client, PacksProtocol.MSG_FINISH, Bundle().apply {
                    putString(PacksProtocol.K_JSON, resultJson)
                    if (pfd != null) putParcelable(PacksProtocol.K_ZIP, pfd)
                })
            } finally {
                // The descriptor was duplicated into the message, so the files can go now.
                runCatching { pfd?.close() }
                inbox.delete()
                runCatching { python().callAttr("cleanup", job) }
            }
        }
    }
}
