plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.chaquo.python")
}

android {
    namespace = "com.py3x.ide"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.py3x.ide"
        minSdk = 24 // Chaquopy 17 requires >= 24
        targetSdk = 35
        // Release builds pass -Ppy3xVersionCode / -Ppy3xVersionName (see the publish-release workflow).
        // versionCode must go up with every release the store or phones should accept as an update.
        versionCode = (findProperty("py3xVersionCode") as String?)?.trim()?.toIntOrNull() ?: 1
        versionName = (findProperty("py3xVersionName") as String?)?.trim()?.takeIf { it.isNotEmpty() } ?: "0.1.0"
        // Google's sample AdMob app id unless you pass your own: -Ppy3xAdmobAppId=ca-app-pub-XXXX~YYYY
        manifestPlaceholders["admobAppId"] =
            (findProperty("py3xAdmobAppId") as String?)?.takeIf { it.isNotBlank() } ?: "ca-app-pub-3940256099942544~3347511713"
        // Public backend values (Supabase project URL + anon key). Empty = backend off; the app still works fully offline.
        // The anon key is public by design; NEVER put a service_role key here.
        val sbUrl = ((findProperty("py3xSupabaseUrl") as String?) ?: "").trim().replace("\"", "")
        val sbKey = ((findProperty("py3xSupabaseAnonKey") as String?) ?: "").trim().replace("\"", "")
        buildConfigField("String", "SUPABASE_URL", "\"" + sbUrl + "\"")
        buildConfigField("String", "SUPABASE_ANON_KEY", "\"" + sbKey + "\"")
        // Chaquopy ships one Python per ABI; keep the APK small.
        // Phones only (arm64): drop x86_64 (emulator) to save ~25% size.
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    signingConfigs {
        // Release signing is opt-in via environment variables (see docs/android-build.md).
        val keystore = System.getenv("PY3X_KEYSTORE_PATH")
        if (keystore != null) {
            create("release") {
                storeFile = file(keystore)
                storePassword = System.getenv("PY3X_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("PY3X_KEY_ALIAS")
                keyPassword = System.getenv("PY3X_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
        }
        // Installable, optimised build signed with the debug key: much faster than the debug build.
        create("fast") {
            initWith(getByName("release"))
            isMinifyEnabled = false
            isShrinkResources = false
            signingConfig = signingConfigs.findByName("release") ?: signingConfigs.getByName("debug")
            matchingFallbacks += "release"
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfigs.findByName("release")?.let { signingConfig = it }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true; buildConfig = true }
    // The Packs installer is an APK in assets: it is already compressed.
    androidResources { noCompress += "apk" }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
    testOptions { unitTests.isReturnDefaultValues = true }
}

chaquopy {
    defaultConfig {
        // The IDE runs the newest Python Chaquopy supports. Libraries that only have Python 3.10 Android wheels
        // (scipy, scikit-learn, OpenCV...) live in the companion Packs app, see ../packs.
        version = "3.12"
        // Extra packages are bundled at build time. Set e.g. -Ppy3xPackages=numpy,pillow
        // (or the ORG_GRADLE_PROJECT_py3xPackages environment variable used by the CI workflow).
        // Only packages with an Android wheel in the Chaquopy repository can work; see the in-app Package Manager.
        (findProperty("py3xPackages") as String?)
            ?.split(",")?.map { it.trim() }?.filter { it.isNotEmpty() }
            ?.forEach { name -> pip { install(name) } }
    }
    sourceSets {
        // The shared Python backend lives at <repo>/python and is also what the desktop tests import.
        getByName("main") { srcDir("../../python") }
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("com.google.android.gms:play-services-ads:23.6.0")
    // Google consent (UMP) and Unity Ads are bundled at build time; the app never downloads an ad SDK.
    implementation("com.google.android.ump:user-messaging-platform:3.1.0")
    implementation("com.unity3d.ads:unity-ads:4.12.5")
    debugImplementation("androidx.compose.ui:ui-tooling")

    testImplementation("junit:junit:4.13.2")
}
