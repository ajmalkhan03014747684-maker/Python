package com.py3x.ide

import com.py3x.ide.ui.editor.AutoIndent
import org.junit.Assert.assertEquals
import org.junit.Test

/** Same cases as tests/test_editor.py::AutoIndentTests: the two implementations must agree. */
class AutoIndentTest {
    private fun a(line: String, spaces: Boolean = true, width: Int = 4) = AutoIndent.after(line, spaces, width)

    @Test fun keepsIndent() = assertEquals("    ", a("    x = 1"))

    @Test fun colonAddsLevel() {
        assertEquals("    ", a("def f():"))
        assertEquals("        ", a("    if x:"))
        assertEquals("    ", a("if x:  # comment"))
    }

    @Test fun colonInStringOrCommentIgnored() {
        assertEquals("", a("x = 'a:'"))
        assertEquals("", a("x = 1  # note:"))
    }

    @Test fun openBracket() = assertEquals("  ", a("foo(", width = 2))

    @Test fun dedentAfterReturnAndFriends() {
        assertEquals("    ", a("        return x"))
        assertEquals("", a("    pass"))
        assertEquals("", a("    raise ValueError('x')"))
    }

    @Test fun tabs() = assertEquals("\t", a("def f():", spaces = false))
}
