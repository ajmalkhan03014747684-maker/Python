package com.py3x.ide

import androidx.compose.ui.text.input.TextFieldValue
import com.py3x.ide.ui.editor.UndoStack
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class UndoStackTest {
    private fun v(s: String) = TextFieldValue(s)

    @Test fun undoThenRedoRestoresValues() {
        val u = UndoStack()
        u.record(v("a"), coalescible = false, nowMs = 0)
        u.record(v("ab"), coalescible = false, nowMs = 10)
        assertEquals("ab", u.undo(v("abc"))!!.text)
        assertEquals("a", u.undo(v("ab"))!!.text)
        assertNull(u.undo(v("a")))
        assertEquals("ab", u.redo(v("a"))!!.text)
    }

    @Test fun typingBurstsCoalesceIntoOneStep() {
        val u = UndoStack(coalesceMs = 800)
        u.record(v(""), coalescible = true, nowMs = 0)
        u.record(v("h"), coalescible = true, nowMs = 100)
        u.record(v("he"), coalescible = true, nowMs = 200)
        assertEquals("", u.undo(v("hel"))!!.text)
        assertFalse(u.canUndo)
    }

    @Test fun pauseStartsNewStep() {
        val u = UndoStack(coalesceMs = 800)
        u.record(v(""), coalescible = true, nowMs = 0)
        u.record(v("h"), coalescible = true, nowMs = 2000)
        assertEquals("h", u.undo(v("hi"))!!.text)
        assertTrue(u.canUndo)
    }

    @Test fun newEditClearsRedo() {
        val u = UndoStack()
        u.record(v("a"), false, 0)
        u.undo(v("ab"))
        assertTrue(u.canRedo)
        u.record(v("a"), false, 5)
        assertFalse(u.canRedo)
    }

    @Test fun limitDropsOldest() {
        val u = UndoStack(limit = 2)
        u.record(v("1"), false, 0)
        u.record(v("2"), false, 1)
        u.record(v("3"), false, 2)
        assertEquals("3", u.undo(v("4"))!!.text)
        assertEquals("2", u.undo(v("3"))!!.text)
        assertNull(u.undo(v("2")))
    }
}
