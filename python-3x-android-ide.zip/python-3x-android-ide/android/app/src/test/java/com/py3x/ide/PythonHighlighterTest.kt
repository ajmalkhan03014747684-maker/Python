package com.py3x.ide

import com.py3x.ide.ui.editor.Diagnostic
import com.py3x.ide.ui.editor.PythonHighlighter
import com.py3x.ide.ui.editor.TokenKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class PythonHighlighterTest {
    private fun kinds(s: String) = PythonHighlighter.tokenize(s).map { it.kind to s.substring(it.start, it.end) }

    @Test fun keywordsBuiltinsNumbers() {
        assertEquals(
            listOf(
                TokenKind.KEYWORD to "if", TokenKind.NUMBER to "10", TokenKind.BUILTIN to "print",
            ),
            kinds("if x > 10: print(x)").filter { it.first != TokenKind.SELF },
        )
    }

    @Test fun keywordInsideStringIsPartOfString() {
        assertEquals(listOf(TokenKind.STRING to "'if while'"), kinds("'if while'"))
    }

    @Test fun commentRunsToLineEnd() {
        assertEquals(listOf(TokenKind.COMMENT to "# for x"), kinds("# for x\ny = 1").take(1))
    }

    @Test fun tripleQuotedSpansLines() {
        val s = "\"\"\"a\nb\"\"\" + 1"
        assertEquals(TokenKind.STRING to "\"\"\"a\nb\"\"\"", kinds(s)[0])
    }

    @Test fun stringPrefixIsIncluded() {
        assertEquals(listOf(TokenKind.STRING to "f\"hi {x}\""), kinds("f\"hi {x}\""))
    }

    @Test fun unterminatedStringStopsAtLineEnd() {
        val s = "x = 'abc\ny = 2"
        assertEquals(TokenKind.STRING to "'abc", kinds(s)[0])
        assertEquals(TokenKind.NUMBER to "2", kinds(s).last())
    }

    @Test fun escapedQuoteDoesNotEndString() {
        assertEquals(listOf(TokenKind.STRING to "'it\\'s'"), kinds("'it\\'s'"))
    }

    @Test fun definitionNamesAndDecorators() {
        val k = kinds("@app.route\ndef handler(self):\n    pass")
        assertEquals(TokenKind.DECORATOR to "@app.route", k[0])
        assertEquals(TokenKind.KEYWORD to "def", k[1])
        assertEquals(TokenKind.DEFINITION to "handler", k[2])
        assertEquals(TokenKind.SELF to "self", k[3])
    }

    @Test fun offsetsAndDiagnosticRange() {
        val text = "ab\ncd\nef"
        assertEquals(3, PythonHighlighter.offsetOf(text, 2, 0))
        assertEquals(8, PythonHighlighter.offsetOf(text, 99, 0))
        assertEquals(5, PythonHighlighter.offsetOf(text, 2, 99)) // clamped to the line end
        val r = PythonHighlighter.diagnosticRange(text, Diagnostic(2, 1, 2, 1, "x"))
        assertEquals(4..4, r)
        assertNull(PythonHighlighter.diagnosticRange("", Diagnostic(1, 0, 1, 1, "x")))
        assertNotNull(PythonHighlighter.diagnosticRange("a", Diagnostic(5, 0, 5, 1, "x")))
    }
}
