package com.py3x.ide.vm

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import com.py3x.ide.ui.editor.Diagnostic
import com.py3x.ide.ui.editor.UndoStack
import org.json.JSONObject

data class Project(
    val id: Int,
    val name: String,
    val mainFile: String,
    val modifiedAt: Double,
) {
    companion object {
        fun from(o: JSONObject) = Project(
            o.getInt("id"), o.getString("name"), o.getString("main_file"), o.getDouble("modified_at"),
        )
    }
}

data class FileEntry(
    val name: String,
    val rel: String,
    val isDir: Boolean,
    val size: Long,
    val editable: Boolean,
) {
    companion object {
        fun from(o: JSONObject) = FileEntry(
            o.getString("name"), o.getString("rel"), o.getBoolean("is_dir"),
            o.getLong("size"), o.getBoolean("editable"),
        )
    }
}

data class RecentFile(val projectId: Int, val projectName: String, val rel: String)

data class RecoveryItem(val projectId: Int, val projectName: String, val rel: String)

data class TrashItem(val id: Int, val originalRel: String, val isDir: Boolean)

/** One open editor tab. Compose-state backed so the UI recomposes on change. */
class TabState(
    val projectId: Int,
    val rel: String,
    initial: String,
    var baseHash: String,
) {
    var value by mutableStateOf(TextFieldValue(initial, TextRange(0)))
    var savedText by mutableStateOf(initial)
    var diagnostics by mutableStateOf<List<Diagnostic>>(emptyList())
    val undo = UndoStack()
    val title: String get() = rel.substringAfterLast('/')
    val isDirty: Boolean get() = value.text != savedText
    val key: String get() = "$projectId:$rel"
}

enum class RunPhase { READY, PREPARING, RUNNING, STOPPED, COMPLETED, FAILED;
    val isActive get() = this == PREPARING || this == RUNNING
    companion object {
        fun from(s: String) = entries.firstOrNull { it.name.equals(s, ignoreCase = true) } ?: READY
    }
}

data class RunError(val line: Int, val type: String, val message: String, val file: String)

data class RunStatus(
    val phase: RunPhase = RunPhase.READY,
    val exitCode: Int? = null,
    val durationSec: Double = 0.0,
    val error: RunError? = null,
    val stuck: Boolean = false,
    val backend: String = "",
)

data class Settings(
    val theme: String = "light",
    val accent: String = "#2F80FF",
    val fontSize: Int = 14,
    val tabWidth: Int = 4,
    val useSpaces: Boolean = true,
    val lineNumbers: Boolean = true,
    val wordWrap: Boolean = true,
    val syntaxHighlighting: Boolean = true,
    val autocomplete: Boolean = true,
    val autoIndent: Boolean = true,
    val autosaveDebounceMs: Int = 800,
    val saveAllBeforeRun: Boolean = true,
    val maxRuntimeSeconds: Int = 0,
    val reduceMotion: Boolean = false,
) {
    companion object {
        fun from(o: JSONObject) = Settings(
            theme = o.getString("theme"),
            accent = o.getString("accent"),
            fontSize = o.getInt("font_size"),
            tabWidth = o.getInt("tab_width"),
            useSpaces = o.getBoolean("use_spaces"),
            lineNumbers = o.getBoolean("line_numbers"),
            wordWrap = o.getBoolean("word_wrap"),
            syntaxHighlighting = o.getBoolean("syntax_highlighting"),
            autocomplete = o.getBoolean("autocomplete"),
            autoIndent = o.getBoolean("auto_indent"),
            autosaveDebounceMs = o.getInt("autosave_debounce_ms"),
            saveAllBeforeRun = o.getBoolean("save_all_before_run"),
            maxRuntimeSeconds = o.getInt("max_runtime_seconds"),
            reduceMotion = o.getBoolean("reduce_motion"),
        )
    }
}

data class RuntimeInfo(val python: String, val backend: String, val canHardStop: Boolean, val notes: String)

enum class SaveIndicator { IDLE, SAVING, DRAFT_SAVED, SAVED }

data class AdsConfig(
    val adsEnabled: Boolean = false,
    val provider: String = "none",
    val bannerEnabled: Boolean = true,
    val rewardedEnabled: Boolean = true,
    val bannerUnitId: String = "",
    val rewardedUnitId: String = "",
    val unlockMinutes: Int = 60,
    val admobAppId: String = "",
    val unityGameId: String = "",
    val unityPlacementId: String = "",
    val adsRequired: Int = 1,
) {
    companion object {
        fun from(o: JSONObject) = AdsConfig(
            o.getBoolean("ads_enabled"), o.getString("provider"), o.getBoolean("banner_enabled"),
            o.getBoolean("rewarded_enabled"), o.getString("banner_unit_id"), o.getString("rewarded_unit_id"),
            o.getInt("rewarded_unlock_minutes"),
            o.optString("admob_app_id"), o.optString("unity_game_id"), o.optString("unity_placement_id"), o.optInt("ads_required", 1).coerceIn(1, 10),
        )
    }
}

data class UnlockStatus(val unlocked: Boolean = false, val remainingSeconds: Int = 0)

data class DebugState(
    val active: Boolean = false,
    val paused: Boolean = false,
    val file: String = "",
    val line: Int = 0,
    val function: String = "",
    val stack: List<String> = emptyList(),
    val variables: List<Pair<String, String>> = emptyList(),
    val message: String? = null,
)

data class PackageInfo(val name: String, val status: String, val version: String, val note: String, val action: String) {
    companion object {
        fun from(o: JSONObject) = PackageInfo(
            o.getString("name"), o.getString("status"), o.getString("version"), o.getString("note"), o.getString("action"),
        )
    }
}

data class GitRepo(val owner: String, val name: String, val private: Boolean, val defaultBranch: String)

/** One chat line. [fix] is a one-line change the person can apply to the open file. */
data class ChatMsg(val role: String, val text: String, val fix: AutoFix? = null)

data class ExampleInfo(val key: String, val title: String, val desc: String, val needs: String, val runsIn: String, val category: String = "data")

/** Result of the offline error helper. [patchLine] 0 means "insert [patchNew] as a new first line". */
data class AutoFix(
    val title: String,
    val explanation: String,
    val steps: List<String>,
    val patchLine: Int?,
    val patchNew: String,
    val packs: Boolean,
)
