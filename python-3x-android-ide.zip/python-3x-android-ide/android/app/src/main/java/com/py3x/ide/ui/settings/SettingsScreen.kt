package com.py3x.ide.ui.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.py3x.ide.ui.components.ConfirmDialog
import com.py3x.ide.ui.components.GlowCard
import com.py3x.ide.ui.components.ToolButton
import com.py3x.ide.vm.IdeViewModel

private val Accents = listOf("#2F80FF" to "Blue", "#22E3C4" to "Teal", "#8B7CFF" to "Violet", "#FFB84D" to "Amber", "#FF6B8A" to "Rose", "#5CB8FF" to "Sky")

@Composable
fun SettingsScreen(vm: IdeViewModel) {
    val s by vm.settings.collectAsState()
    val info by vm.runtimeInfo.collectAsState()
    val deleted by vm.deletedProjects.collectAsState()
    var showLogs by remember { mutableStateOf(false) }
    var confirmRestart by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { vm.loadDeletedProjects() }

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 16.dp))

        Group("Appearance", "◐") {
            Choice("Theme", listOf("dark" to "Dark", "light" to "Light", "system" to "System"), s.theme) {
                vm.setSetting("theme", "\"$it\"")
            }
            Choice("Accent colour", Accents, s.accent.uppercase()) { vm.setSetting("accent", "\"$it\"") }
            Toggle("Reduce motion", "Skips animations. Also follows the system animation setting.", s.reduceMotion) {
                vm.setSetting("reduce_motion", it.toString())
            }
        }

        Group("Editor", "✎") {
            Stepper("Font size", s.fontSize, 10, 28, "sp") { vm.setSetting("font_size", it.toString()) }
            Stepper("Tab width", s.tabWidth, 2, 8, "spaces") { vm.setSetting("tab_width", it.toString()) }
            Toggle("Use spaces for indentation", null, s.useSpaces) { vm.setSetting("use_spaces", it.toString()) }
            Toggle("Line numbers", null, s.lineNumbers) { vm.setSetting("line_numbers", it.toString()) }
            Toggle("Word wrap", null, s.wordWrap) { vm.setSetting("word_wrap", it.toString()) }
            Toggle("Syntax highlighting", "Switched off automatically for very large files.", s.syntaxHighlighting) {
                vm.setSetting("syntax_highlighting", it.toString())
            }
            Toggle("Autocomplete", null, s.autocomplete) { vm.setSetting("autocomplete", it.toString()) }
            Toggle("Auto-indent", null, s.autoIndent) { vm.setSetting("auto_indent", it.toString()) }
        }

        Group("Saving & running", "▶") {
            Stepper("Autosave delay", s.autosaveDebounceMs, 300, 5000, "ms", step = 100) {
                vm.setSetting("autosave_debounce_ms", it.toString())
            }
            Toggle("Save all before run", null, s.saveAllBeforeRun) { vm.setSetting("save_all_before_run", it.toString()) }
            Stepper("Max run time (0 = no limit)", s.maxRuntimeSeconds, 0, 3600, "s", step = 10) {
                vm.setSetting("max_runtime_seconds", it.toString())
            }
        }

        Group("Python runtime", "🐍") {
            val i = info
            if (i == null) {
                Body("Runtime information is not available.")
            } else {
                Body("Python ${i.python} · ${i.backend} runner")
                Body(i.notes)
                if (!i.canHardStop) {
                    Body("This runner stops scripts cooperatively. A script stuck inside native code cannot be interrupted; use “Restart runtime” if Stop has no effect. Your drafts are kept.")
                    Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                        ToolButton("Restart runtime", onClick = { confirmRestart = true }, description = "Restart the Python runtime")
                    }
                }
            }
        }

        Group("Recently deleted projects", "🗑") {
            if (deleted.isEmpty()) Body("Nothing here. Deleted projects stay recoverable until you remove them permanently.")
            deleted.forEach { p ->
                Row(Modifier.fillMaxWidth().heightIn(min = 56.dp).padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(p.name, Modifier.weight(1f), maxLines = 1)
                    TextButton(onClick = { vm.restoreProject(p) }) { Text("Restore") }
                    TextButton(onClick = { vm.purgeProject(p) }) { Text("Delete forever", color = MaterialTheme.colorScheme.error) }
                }
            }
        }

        Group("Diagnostics", "⚑") {
            Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                ToolButton("View runtime log", onClick = { showLogs = true })
            }
        }

        Group("About", "i") {
            Body("Python 3.x — an on-device Python IDE. Your code stays on this phone. Tools (Package Manager, OpenCV Studio, Data Science, AI helper, GitHub) are in the Tools tab. The Supabase backend is not built yet.")
        }
    }

    if (showLogs) LogDialog(vm) { showLogs = false }
    if (confirmRestart) {
        ConfirmDialog(
            title = "Restart runtime?",
            message = "The app will close. Unsaved edits are stored as drafts and offered for recovery when you reopen it.",
            confirmLabel = "Restart",
            onConfirm = { confirmRestart = false; vm.forceRestartRuntime() },
            onDismiss = { confirmRestart = false },
        )
    }
}

@Composable
private fun LogDialog(vm: IdeViewModel, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf("Loading…") }
    LaunchedEffect(Unit) { text = vm.logTail().ifBlank { "The log is empty." } }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Runtime log") },
        text = {
            SelectionContainer {
                Text(
                    text,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    modifier = Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()),
                )
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}

/** A rounded card with a titled header, grouping related settings. */
@Composable
private fun Group(title: String, glyph: String, content: @Composable () -> Unit) {
    GlowCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(vertical = 8.dp)) {
            Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(glyph, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                Text(
                    title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold, modifier = Modifier.semantics { heading() },
                )
            }
            content()
        }
    }
}

@Composable
private fun Body(text: String) {
    Text(text, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
}

@Composable
private fun Toggle(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 56.dp).clickable { onChange(!checked) }.padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f).padding(vertical = 8.dp)) {
            Text(title)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun Stepper(title: String, value: Int, min: Int, max: Int, unit: String, step: Int = 1, onChange: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 56.dp).padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title)
            Text("$value $unit", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        ToolButton("−", onClick = { onChange((value - step).coerceAtLeast(min)) }, enabled = value > min, description = "Decrease $title")
        Row(Modifier.padding(start = 6.dp)) {
            ToolButton("+", onClick = { onChange((value + step).coerceAtMost(max)) }, enabled = value < max, description = "Increase $title")
        }
    }
}

@Composable
private fun Choice(title: String, options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
        Text(title)
        Row(Modifier.padding(top = 6.dp).horizontalScrollCompat(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            options.forEach { (key, label) ->
                ToolButton(label, onClick = { onSelect(key) }, emphasized = key == selected,
                    description = "$title: $label" + if (key == selected) ", selected" else "")
            }
        }
    }
}

@Composable
private fun Modifier.horizontalScrollCompat(): Modifier = this.then(Modifier.horizontalScroll(rememberScrollState()))
