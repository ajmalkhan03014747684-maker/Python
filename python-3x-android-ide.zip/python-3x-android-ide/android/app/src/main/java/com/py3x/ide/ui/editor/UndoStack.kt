package com.py3x.ide.ui.editor

import androidx.compose.ui.text.input.TextFieldValue

/**
 * Undo/redo history for one editor tab.
 *
 * Call [record] with the value *before* each edit. Runs of single-character typing within
 * [coalesceMs] merge into one undo step, so undo removes a burst of typing, not one letter.
 */
class UndoStack(private val limit: Int = 200, private val coalesceMs: Long = 800) {
    private val undoList = ArrayList<TextFieldValue>()
    private val redoList = ArrayList<TextFieldValue>()
    private var lastAt = 0L
    private var lastCoalescible = false

    val canUndo: Boolean get() = undoList.isNotEmpty()
    val canRedo: Boolean get() = redoList.isNotEmpty()

    fun record(before: TextFieldValue, coalescible: Boolean, nowMs: Long) {
        val merge = coalescible && lastCoalescible && undoList.isNotEmpty() && nowMs - lastAt < coalesceMs
        redoList.clear()
        lastAt = nowMs
        lastCoalescible = coalescible
        if (merge) return
        undoList.add(before)
        if (undoList.size > limit) undoList.removeAt(0)
    }

    fun undo(current: TextFieldValue): TextFieldValue? {
        if (undoList.isEmpty()) return null
        redoList.add(current)
        lastCoalescible = false
        return undoList.removeAt(undoList.lastIndex)
    }

    fun redo(current: TextFieldValue): TextFieldValue? {
        if (redoList.isEmpty()) return null
        undoList.add(current)
        lastCoalescible = false
        return redoList.removeAt(redoList.lastIndex)
    }

    fun clear() {
        undoList.clear()
        redoList.clear()
        lastCoalescible = false
    }
}
