package com.py3x.ide.ui.files

import com.py3x.ide.ui.components.FullScreen
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import com.py3x.ide.ui.components.ToolButton
import com.py3x.ide.ui.vision.decode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Read-only picture viewer for image files in a project. */
@Composable
fun ImagePreviewDialog(rel: String, file: File, onClose: () -> Unit) {
    var image by remember(file) { mutableStateOf<ImageBitmap?>(null) }
    var failed by remember(file) { mutableStateOf(false) }
    LaunchedEffect(file) {
        val bmp = withContext(Dispatchers.IO) { decode(file)?.asImageBitmap() }
        image = bmp
        failed = bmp == null
    }
    FullScreen(onClose) {
        Column(
            Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(rel, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                ToolButton("Close", onClose)
            }
            when {
                failed -> Text("This image could not be shown.", color = MaterialTheme.colorScheme.error)
                image == null -> Text("Loading…")
                else -> Image(
                    bitmap = image!!, contentDescription = "Preview of $rel",
                    contentScale = ContentScale.Fit, modifier = Modifier.fillMaxWidth().weight(1f),
                )
            }
        }
    }
}
