package com.py3x.ide.ui.github

import com.py3x.ide.ui.components.FullScreen
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.py3x.ide.ui.components.ToolButton
import com.py3x.ide.vm.IdeViewModel
import org.json.JSONArray

@Composable
fun GitHubDialog(vm: IdeViewModel) {
    FullScreen({ vm.closeGithub() }) {
        GitHubScreen(vm)
    }
}

private fun JSONArray.names(): List<String> = (0 until length()).map { getString(it) }

@Composable
private fun GitHubScreen(vm: IdeViewModel) {
    val hasToken by vm.hasGithubToken.collectAsState()
    val user by vm.githubUser.collectAsState()
    val repos by vm.githubRepos.collectAsState()
    val status by vm.githubStatus.collectAsState()
    val busy by vm.githubBusy.collectAsState()
    val message by vm.githubMessage.collectAsState()
    val project by vm.currentProject.collectAsState()

    var token by remember { mutableStateOf("") }
    var manual by remember { mutableStateOf("") }
    var commitMessage by remember { mutableStateOf("") }
    var newBranch by remember { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("GitHub", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
            ToolButton("Close", onClick = { vm.closeGithub() })
        }
        Text(
            "Talks only to api.github.com. Your token is stored encrypted on this device and sent only to GitHub. " +
                "No merging: push refuses if the branch moved, pull refuses if you have local changes.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        message?.let { Text(it, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodyMedium) }
        if (busy) Text("Working…", color = MaterialTheme.colorScheme.onSurfaceVariant)

        // ------------------------------------------------------------- token
        Text("Account", style = MaterialTheme.typography.titleSmall)
        if (!hasToken) {
            Text(
                "Create a fine-grained token on github.com (Settings → Developer settings → Personal access tokens) " +
                    "limited to the repositories you need, with Contents: read and write.",
                style = MaterialTheme.typography.bodySmall,
            )
            OutlinedTextField(
                token, { token = it }, label = { Text("GitHub token") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, autoCorrectEnabled = false),
            )
            ToolButton("Connect", onClick = { vm.githubConnect(token); token = "" }, enabled = !busy && token.isNotBlank(), emphasized = true)
        } else {
            Text(user?.let { "Connected as $it" } ?: "Token saved on this device.")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ToolButton("Load my repositories", onClick = { vm.githubLoadRepos() }, enabled = !busy)
                ToolButton("Remove token", onClick = { vm.githubForget() }, enabled = !busy)
            }
        }
        HorizontalDivider()

        // ----------------------------------------------------- current project
        Text("Current project", style = MaterialTheme.typography.titleSmall)
        val st = status
        if (project == null) {
            Text("Open a project to push or pull.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else if (st == null || !st.optBoolean("linked")) {
            Text("“${project!!.name}” is not linked to a repository. Clone one below to create a linked project.")
        } else {
            val added = st.getJSONArray("added").names()
            val modified = st.getJSONArray("modified").names()
            val deleted = st.getJSONArray("deleted").names()
            Text("${st.getString("owner")}/${st.getString("repo")} · ${st.getString("branch")} @ ${st.getString("commit")}", style = MaterialTheme.typography.titleSmall)
            Text(
                if (st.optBoolean("clean")) "No local changes."
                else "Changes: ${added.size} new, ${modified.size} modified, ${deleted.size} deleted",
            )
            (added.map { "+ $it" } + modified.map { "~ $it" } + deleted.map { "- $it" }).take(12).forEach {
                Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            val ignored = st.getJSONArray("ignored").names()
            if (ignored.isNotEmpty()) Text("Skipped (over 5 MB): ${ignored.joinToString()}", style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(commitMessage, { commitMessage = it }, label = { Text("Commit message") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(
                newBranch, { newBranch = it }, label = { Text("Push to a new branch (optional)") }, singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ToolButton("Push", onClick = { vm.githubPush(commitMessage, newBranch); commitMessage = "" },
                    enabled = !busy && hasToken && commitMessage.isNotBlank(), emphasized = true)
                ToolButton("Pull", onClick = { vm.githubPull() }, enabled = !busy && hasToken)
                ToolButton("Refresh", onClick = { vm.refreshGithub() }, enabled = !busy)
                ToolButton("Unlink", onClick = { vm.githubUnlink() }, enabled = !busy)
            }
        }
        HorizontalDivider()

        // ----------------------------------------------------------- clone
        Text("Clone a repository", style = MaterialTheme.typography.titleSmall)
        OutlinedTextField(
            manual, { manual = it }, label = { Text("owner/repository") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(autoCorrectEnabled = false),
        )
        ToolButton("Clone", onClick = {
            val parts = manual.trim().split("/")
            if (parts.size == 2) vm.githubClone(parts[0], parts[1]) else vm.notify("Write it as owner/repository.")
        }, enabled = !busy && hasToken && manual.contains("/"))
        repos.forEach { r ->
            Row(
                Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface, MaterialTheme.shapes.medium).padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text("${r.owner}/${r.name}", style = MaterialTheme.typography.titleSmall)
                    Text(if (r.private) "private · ${r.defaultBranch}" else "public · ${r.defaultBranch}", style = MaterialTheme.typography.bodySmall)
                }
                ToolButton("Clone", onClick = { vm.githubClone(r.owner, r.name) }, enabled = !busy, description = "Clone ${r.name}")
            }
        }
    }
}
