package com.py3x.ide.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.py3x.ide.ui.theme.Palette

/** Original app mark: two interlocking rounded tiles (blue and violet) with a cyan spark. Not derived from any other logo. */
@Composable
fun PyMark(size: Dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size).semantics { contentDescription = "Python 3.x logo" }) {
        val s = this.size.minDimension
        val tile = s * 0.56f
        val r = CornerRadius(s * 0.16f)
        rotate(-12f, Offset(s * 0.38f, s * 0.38f)) {
            drawRoundRect(
                Brush.linearGradient(listOf(Palette.Blue, Palette.Cyan), Offset(0f, 0f), Offset(tile, tile)),
                topLeft = Offset(s * 0.06f, s * 0.08f), size = Size(tile, tile), cornerRadius = r,
            )
        }
        rotate(-12f, Offset(s * 0.62f, s * 0.62f)) {
            drawRoundRect(
                Brush.linearGradient(listOf(Palette.Violet, Palette.Blue), Offset(0f, 0f), Offset(tile, tile)),
                topLeft = Offset(s * 0.38f, s * 0.36f), size = Size(tile, tile), cornerRadius = r,
            )
        }
        drawCircle(Color.White.copy(alpha = 0.92f), radius = s * 0.055f, center = Offset(s * 0.27f, s * 0.27f))
        drawCircle(Color.White.copy(alpha = 0.92f), radius = s * 0.055f, center = Offset(s * 0.73f, s * 0.73f))
    }
}

/** Rounded dark card with a thin glowing edge, the basic building block of every screen. */
@Composable
fun GlowCard(
    modifier: Modifier = Modifier,
    accent: Color = MaterialTheme.colorScheme.primary,
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit,
) {
    val shape = RoundedCornerShape(18.dp)
    val border = BorderStroke(1.dp, Brush.linearGradient(listOf(accent.copy(alpha = 0.55f), MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))))
    val color = MaterialTheme.colorScheme.surface
    if (onClick != null) {
        val source = remember { MutableInteractionSource() }
        Surface(onClick = onClick, interactionSource = source, shape = shape, color = color, border = border, modifier = modifier.pressScale(source)) { content() }
    } else {
        Surface(shape = shape, color = color, border = border, modifier = modifier) { content() }
    }
}

/** Filled gradient button used for the main actions (blue, violet or green like the design reference). */
@Composable
fun GradientButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    colors: List<Color> = listOf(Palette.Blue, Color(0xFF1D5FE0)),
    enabled: Boolean = true,
    glyph: String? = null,
    description: String = label,
) {
    val source = remember { MutableInteractionSource() }
    Surface(
        onClick = onClick, enabled = enabled, interactionSource = source, shape = RoundedCornerShape(14.dp), color = Color.Transparent,
        modifier = modifier.pressScale(source).heightIn(min = 48.dp).semantics { contentDescription = description },
    ) {
        Box(
            Modifier.background(
                if (enabled) Brush.linearGradient(colors) else Brush.linearGradient(listOf(Palette.Raised, Palette.Raised)),
                RoundedCornerShape(14.dp),
            ).padding(horizontal = 16.dp, vertical = 12.dp),
            contentAlignment = Alignment.Center,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (glyph != null) Text(glyph, color = Color.White, fontSize = 16.sp)
                Text(label, color = if (enabled) Color.White else MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.SemiBold, maxLines = 1)
            }
        }
    }
}

/** Square tile with a tinted glyph and a caption, used in the tool grids. */
@Composable
fun ToolTile(
    glyph: String,
    label: String,
    modifier: Modifier = Modifier,
    tint: Color = MaterialTheme.colorScheme.primary,
    badge: String? = null,
    onClick: () -> Unit,
) {
    GlowCard(modifier.heightIn(min = 84.dp), accent = tint, onClick = onClick) {
        Column(
            Modifier.padding(8.dp).fillMaxWidth().semantics { contentDescription = if (badge != null) "$label, $badge" else label },
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Box(Modifier.size(38.dp).background(tint.copy(alpha = 0.16f), RoundedCornerShape(11.dp)), contentAlignment = Alignment.Center) {
                Text(glyph, color = tint, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            }
            Text(label, style = MaterialTheme.typography.labelMedium, textAlign = TextAlign.Center, maxLines = 2)
            if (badge != null) Text(badge, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.tertiary)
        }
    }
}

@Composable
fun SectionHeader(text: String, modifier: Modifier = Modifier) {
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, modifier = modifier.padding(top = 6.dp, bottom = 2.dp))
}

/** Wide card for list-style tools (icon, title, description, optional trailing button). */
@Composable
fun ToolRow(glyph: String, title: String, subtitle: String, tint: Color = MaterialTheme.colorScheme.primary, badge: String? = null, onClick: () -> Unit) {
    GlowCard(Modifier.fillMaxWidth(), accent = tint, onClick = onClick) {
        Row(Modifier.padding(12.dp).semantics { contentDescription = "$title. $subtitle" }, verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(tint.copy(alpha = 0.16f), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                Text(glyph, color = tint, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(title, style = MaterialTheme.typography.titleSmall)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (badge != null) Text(badge, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.tertiary)
        }
    }
}
