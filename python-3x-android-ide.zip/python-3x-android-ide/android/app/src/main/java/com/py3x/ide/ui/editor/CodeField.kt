package com.py3x.ide.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions
import com.py3x.ide.ui.theme.codeColors
import com.py3x.ide.vm.Settings
import com.py3x.ide.vm.TabState

/** Above this size syntax colouring is skipped so typing stays instant on large files. */
private const val HIGHLIGHT_LIMIT_CHARS = 200_000

@Composable
fun CodeField(
    tab: TabState,
    settings: Settings,
    bracketPair: Pair<Int, Int>?,
    onValueChange: (TextFieldValue) -> Unit,
    focusRequester: FocusRequester,
    modifier: Modifier = Modifier,
) {
    val colors = codeColors()
    val scheme = MaterialTheme.colorScheme
    val value = tab.value
    val fontSize = settings.fontSize.sp
    val lineHeight = (settings.fontSize * 1.5f).sp
    val style = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontSize = fontSize,
        lineHeight = lineHeight,
        color = scheme.onSurface,
    )
    var layout by remember { mutableStateOf<TextLayoutResult?>(null) }

    // Colouring is computed once per (text, diagnostics, bracket pair), not on every selection change.
    val annotated = remember(value.text, settings.syntaxHighlighting, tab.diagnostics, bracketPair, colors) {
        PythonHighlighter.annotate(
            text = value.text,
            colors = colors,
            highlight = settings.syntaxHighlighting && value.text.length <= HIGHLIGHT_LIMIT_CHARS,
            diagnostics = tab.diagnostics,
            bracketPair = bracketPair,
        )
    }
    val transformation = remember(annotated) {
        VisualTransformation { text ->
            // Guard: if the field text and our cached text ever disagree for a frame, show the plain text.
            TransformedText(if (text.text == annotated.text) annotated else text, OffsetMapping.Identity)
        }
    }

    val gutterText = remember(layout, value.text) {
        buildGutter(value.text, layout)
    }
    val vScroll = rememberScrollState()
    val hScroll = rememberScrollState()
    val currentLineColor = scheme.primary.copy(alpha = 0.08f)

    BoxWithConstraints(modifier = modifier.fillMaxSize().background(scheme.background)) {
        val viewportWidth = maxWidth
        Row(modifier = Modifier.fillMaxSize().verticalScroll(vScroll)) {
            if (settings.lineNumbers) {
                Text(
                    text = gutterText,
                    style = style.copy(color = scheme.onSurfaceVariant.copy(alpha = 0.7f), textAlign = TextAlign.End),
                    modifier = Modifier
                        .background(scheme.surface)
                        .padding(start = 8.dp, end = 8.dp)
                        .semantics { contentDescription = "Line numbers" },
                )
            }
            val fieldModifier = Modifier
                .focusRequester(focusRequester)
                .drawBehind {
                    // Current-line highlight, drawn from the real text layout so it also works with word wrap.
                    layout?.let { l ->
                        if (value.text.isNotEmpty() || l.lineCount > 0) {
                            val line = l.getLineForOffset(value.selection.start.coerceIn(0, value.text.length))
                            val top = l.getLineTop(line)
                            drawRect(currentLineColor, Offset(0f, top), Size(size.width, l.getLineBottom(line) - top))
                        }
                    }
                }
                .semantics { contentDescription = "Code editor for ${tab.title}" }
            val field: @Composable (Modifier) -> Unit = { m ->
                BasicTextField(
                    value = value,
                    onValueChange = onValueChange,
                    modifier = m.then(fieldModifier).padding(end = 24.dp),
                    textStyle = style,
                    cursorBrush = SolidColor(scheme.primary),
                    visualTransformation = transformation,
                    onTextLayout = { layout = it },
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.None,
                        autoCorrectEnabled = false,
                    ),
                )
            }
            if (settings.wordWrap) {
                Box(Modifier.weight(1f)) { field(Modifier.fillMaxWidth()) }
            } else {
                Box(Modifier.weight(1f).horizontalScroll(hScroll)) {
                    field(Modifier.widthIn(min = viewportWidth))
                }
            }
        }
    }
}

/** One number per logical line; wrapped continuation rows get an empty gutter cell so rows stay aligned. */
internal fun buildGutter(text: String, layout: TextLayoutResult?): String {
    if (layout == null || layout.lineCount == 0) {
        val lines = text.count { it == '\n' } + 1
        return (1..lines).joinToString("\n")
    }
    val sb = StringBuilder()
    var number = 0
    for (visual in 0 until layout.lineCount) {
        val start = layout.getLineStart(visual)
        if (start == 0 || text.getOrNull(start - 1) == '\n') {
            number++
            sb.append(number)
        }
        if (visual < layout.lineCount - 1) sb.append('\n')
    }
    return sb.toString()
}
