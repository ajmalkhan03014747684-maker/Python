package com.py3x.ide.packs

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import java.io.File

/**
 * Installs the companion Packs app that was built together with this app and shipped inside it
 * (assets/packs/python3x-packs.apk). Nothing is downloaded. Android's own installer always asks the
 * person for confirmation, and the APK is checked to be the expected package signed with our key.
 */
object PacksInstaller {
    private const val ASSET = "packs/python3x-packs.apk"

    fun bundled(context: Context): Boolean = runCatching { context.assets.open(ASSET).close(); true }.getOrDefault(false)

    /** Returns a message to show the person, or null once Android's installer screen has been opened. Blocking: call off the main thread. */
    fun install(context: Context): String? {
        if (!bundled(context)) {
            return "This build does not contain the Packs app. Install \"Python-3x-Packs.apk\" from the same build output instead."
        }
        val pm = context.packageManager
        if (Build.VERSION.SDK_INT >= 26 && !pm.canRequestPackageInstalls()) {
            context.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${context.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
            return "Android needs your permission first: allow \"Install unknown apps\" for Python 3.x on the screen that just opened, " +
                "go back, and tap Install again."
        }
        val dir = File(context.cacheDir, "packs").apply { mkdirs() }
        val apk = File(dir, "python3x-packs.apk")
        context.assets.open(ASSET).use { input -> apk.outputStream().use { input.copyTo(it) } }
        verify(context, apk)?.let { apk.delete(); return it }

        val uri = FileProvider.getUriForFile(context, "${context.packageName}.packsfiles", apk)
        context.startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK),
        )
        return null
    }

    @Suppress("DEPRECATION")
    private fun verify(context: Context, apk: File): String? {
        val pm = context.packageManager
        val flags = if (Build.VERSION.SDK_INT >= 28) PackageManager.GET_SIGNING_CERTIFICATES else 0
        val archive = pm.getPackageArchiveInfo(apk.absolutePath, flags) ?: return "The bundled Packs installer is damaged."
        if (archive.packageName != PacksClient.PACKAGE) return "The bundled installer is not the Packs app."
        if (Build.VERSION.SDK_INT >= 28) {
            val theirs = archive.signingInfo?.apkContentsSigners
            val ours = pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNING_CERTIFICATES).signingInfo?.apkContentsSigners
            if (theirs != null && ours != null && !(theirs.toSet() == ours.toSet())) {
                return "The bundled Packs installer is signed with a different key than this app, so it would not be allowed to connect."
            }
        }
        return null
    }
}
