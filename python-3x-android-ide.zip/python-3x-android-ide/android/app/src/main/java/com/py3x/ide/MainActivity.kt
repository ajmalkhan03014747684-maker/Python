package com.py3x.ide

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.py3x.ide.ui.AppShell
import com.py3x.ide.vm.IdeViewModel

class MainActivity : ComponentActivity() {
    private val vm: IdeViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { AppShell(vm) }
    }

    override fun onResume() {
        super.onResume()
        vm.onAppResumed()
    }

    override fun onStop() {
        // Push every unsaved edit into the draft store before the process can be killed in the background.
        vm.flushForBackground()
        super.onStop()
    }

    override fun onDestroy() {
        if (isFinishing) vm.cleanShutdown()
        super.onDestroy()
    }
}
