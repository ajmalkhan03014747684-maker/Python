package com.py3x.ide.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.style.TextAlign
import com.py3x.ide.ui.components.GradientButton
import com.py3x.ide.ui.components.PyMark
import com.py3x.ide.ui.theme.Palette
import com.py3x.ide.ui.tools.MoreScreen
import com.py3x.ide.ui.tools.ToolsScreen
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.py3x.ide.ui.components.Dur
import com.py3x.ide.ui.components.ToolButton
import com.py3x.ide.ui.editor.EditorScreen
import com.py3x.ide.ui.files.FilesScreen
import com.py3x.ide.ui.home.HomeScreen
import com.py3x.ide.ui.settings.SettingsScreen
import com.py3x.ide.ui.terminal.TerminalScreen
import com.py3x.ide.ui.theme.LocalReduceMotion
import com.py3x.ide.ui.theme.Py3xTheme
import com.py3x.ide.vm.IdeViewModel

private enum class Dest(val label: String, val glyph: String, val inBar: Boolean) {
    HOME("Home", "⌂", true), PROJECTS("Projects", "▤", true), TERMINAL("Terminal", "›_", true),
    TOOLS("Tools", "✦", true), MORE("More", "⋯", true),
    EDITOR("Editor", "✎", false), SETTINGS("Settings", "⚙", false),
}

/** Which bar item lights up for screens that are not in the bar (the editor belongs to Projects, settings to More). */
private fun barSelection(d: Dest): Dest = when (d) { Dest.EDITOR -> Dest.PROJECTS; Dest.SETTINGS -> Dest.MORE; else -> d }

@Composable
fun AppShell(vm: IdeViewModel) {
    val settings by vm.settings.collectAsState()
    Py3xTheme(settings) {
        val ready by vm.ready.collectAsState()
        val fatal by vm.fatal.collectAsState()
        val onboarded by vm.onboarded.collectAsState()
        val reduce = LocalReduceMotion.current
        Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
            AnimatedContent(
                targetState = when { fatal != null -> 2; ready && !onboarded -> 3; ready -> 1; else -> 0 },
                transitionSpec = {
                    val d = if (reduce) 0 else Dur.PAGE
                    fadeIn(tween(d)) togetherWith fadeOut(tween(d))
                },
                label = "shell",
            ) { state ->
                when (state) {
                    0 -> Splash(vm)
                    2 -> FatalScreen(fatal.orEmpty())
                    3 -> Onboarding(onDone = { vm.finishOnboarding() })
                    else -> MainScaffold(vm)
                }
            }
        }
    }
}

private val SplashSteps = listOf("Initializing Runtime...", "Loading Editor...", "Loading Tools...", "Ready!")

@Composable
private fun Splash(vm: IdeViewModel) {
    val stage by vm.stage.collectAsState()
    val reduce = LocalReduceMotion.current
    var shown by remember { mutableStateOf(reduce) }
    LaunchedEffect(Unit) { shown = true }
    val appear by animateFloatAsState(if (shown) 1f else 0f, tween(if (reduce) 0 else 700), label = "splashAppear")
    val index = SplashSteps.indexOf(stage).coerceAtLeast(0)
    val progress by animateFloatAsState(index / (SplashSteps.size - 1f), tween(if (reduce) 0 else 400), label = "splashProgress")
    Column(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Palette.Raised.copy(alpha = 0.7f), Palette.Ink))).padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        PyMark(112.dp, Modifier.graphicsLayer { alpha = appear; scaleX = 0.8f + 0.2f * appear; scaleY = 0.8f + 0.2f * appear })
        Text("Python 3.x", fontSize = 36.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 16.dp).alpha(appear))
        Text("The Complete Python IDE for Android", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp, bottom = 32.dp).alpha(appear))
        Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth(0.8f)) {
            SplashSteps.forEachIndexed { i, label ->
                val done = i < index || (i == SplashSteps.lastIndex && index == i)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(if (done) "✓" else "○", color = if (done) Palette.Success else MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(label, color = if (i <= index) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            LinearProgressIndicator(
                progress = { progress }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp).semantics { contentDescription = "Loading ${(progress * 100).toInt()} percent" },
                color = MaterialTheme.colorScheme.primary, trackColor = MaterialTheme.colorScheme.surfaceVariant,
            )
            Text("${(progress * 100).toInt()}%", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.align(Alignment.End))
        }
    }
}

private class OnboardPage(val glyph: String, val title: String, val body: String)

private val OnboardPages = listOf(
    OnboardPage("✎", "Write Code", "A real Python editor: highlighting, autocomplete, find and replace, and autosave that survives crashes. Everything works offline."),
    OnboardPage("▤", "Create Projects", "Keep files in projects, import or export zips, and clone repositories from GitHub when you want to."),
    OnboardPage("▶", "Run & Debug", "Run scripts, use the terminal and set breakpoints. Add the Packs app for OpenCV, SciPy and scikit-learn."),
)

@Composable
private fun Onboarding(onDone: () -> Unit) {
    var page by rememberSaveable { mutableIntStateOf(0) }
    val last = page == OnboardPages.lastIndex
    Column(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Palette.Raised.copy(alpha = 0.6f), Palette.Ink))).padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("Welcome to Python 3.x", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 24.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            AnimatedContent(
                targetState = page,
                transitionSpec = { fadeIn(tween(200)) togetherWith fadeOut(tween(120)) },
                label = "onboard",
            ) { i ->
                val p = OnboardPages[i]
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    PyMark(96.dp)
                    Text(p.glyph, fontSize = 28.sp, color = MaterialTheme.colorScheme.tertiary)
                    Text(p.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text(p.body, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 16.dp)) {
            OnboardPages.indices.forEach { i ->
                Box(Modifier.size(if (i == page) 22.dp else 8.dp, 8.dp).background(if (i == page) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline, RoundedCornerShape(4.dp)))
            }
        }
        GradientButton(if (last) "Get started" else "Next", onClick = { if (last) onDone() else page++ }, modifier = Modifier.fillMaxWidth())
        Text("Skip", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(16.dp).clickable { onDone() }.semantics { contentDescription = "Skip introduction" })
    }
}

@Composable
private fun FatalScreen(message: String) {
    var details by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("The Python runtime could not start", style = MaterialTheme.typography.headlineSmall)
        Text(
            "Your projects are stored on this device and have not been changed. Close and reopen the app to try again. " +
                "If it keeps happening, check the details below.",
            modifier = Modifier.padding(vertical = 12.dp),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row { ToolButton(if (details) "Hide details" else "Show details", onClick = { details = !details }) }
        if (details) {
            SelectionContainer {
                Text(message, fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(top = 12.dp).verticalScroll(rememberScrollState()))
            }
        }
    }
}

@Composable
private fun MainScaffold(vm: IdeViewModel) {
    var dest by rememberSaveable { mutableIntStateOf(Dest.HOME.ordinal) }
    val snackbar = remember { SnackbarHostState() }
    val reduce = LocalReduceMotion.current
    LaunchedEffect(Unit) { vm.messages.collect { snackbar.showSnackbar(it) } }
    fun go(d: Dest) { dest = d.ordinal }

    // Back from the editor returns to the file list; from any other screen it returns Home.
    BackHandler(enabled = dest != Dest.HOME.ordinal) {
        go(if (dest == Dest.EDITOR.ordinal) Dest.PROJECTS else Dest.HOME)
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                Dest.entries.filter { it.inBar }.forEach { d ->
                    NavigationBarItem(
                        selected = barSelection(Dest.entries[dest]) == d,
                        onClick = { go(d) },
                        icon = { Text(d.glyph, fontSize = 18.sp) },
                        label = { Text(d.label) },
                        modifier = Modifier.semantics { contentDescription = "${d.label} tab" },
                    )
                }
            }
        },
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            AnimatedContent(
                targetState = dest,
                transitionSpec = {
                    val d = if (reduce) 0 else Dur.SMALL
                    fadeIn(tween(d)) togetherWith fadeOut(tween(d))
                },
                label = "dest",
            ) { target ->
                when (Dest.entries[target]) {
                    Dest.HOME -> HomeScreen(
                        vm,
                        onOpenProjects = { go(Dest.PROJECTS) },
                        onOpenEditor = { go(Dest.EDITOR) },
                        onOpenTerminal = { go(Dest.TERMINAL) },
                        onOpenSettings = { go(Dest.SETTINGS) },
                        onOpenMore = { go(Dest.MORE) },
                    )
                    Dest.PROJECTS -> FilesScreen(vm, onFileOpened = { go(Dest.EDITOR) })
                    Dest.EDITOR -> EditorScreen(vm, onOpenFiles = { go(Dest.PROJECTS) })
                    Dest.TERMINAL -> TerminalScreen(vm)
                    Dest.TOOLS -> ToolsScreen(vm, onOpenEditor = { go(Dest.EDITOR) }, onOpenTerminal = { go(Dest.TERMINAL) }, onOpenSettings = { go(Dest.SETTINGS) })
                    Dest.MORE -> MoreScreen(vm, onOpenSettings = { go(Dest.SETTINGS) })
                    Dest.SETTINGS -> SettingsScreen(vm)
                }
            }
            // Full-screen pages sit inside this box, so they stop above the phone's navigation bar.
            ToolDialogs(vm)
            val outputVisible by vm.outputVisible.collectAsState()
            val tab = vm.currentTab
            if (outputVisible && tab != null) {
                com.py3x.ide.ui.editor.RunPage(vm, tab, onGoToLine = { vm.toggleOutput(); go(Dest.EDITOR); vm.gotoLine(tab, it) })
            }
            val preview by vm.imagePreview.collectAsState()
            preview?.let { (rel, file) -> com.py3x.ide.ui.files.ImagePreviewDialog(rel, file) { vm.closeImagePreview() } }
            val githubOpen by vm.githubDialogOpen.collectAsState()
            if (githubOpen) com.py3x.ide.ui.github.GitHubDialog(vm)
            val aiOpen by vm.aiDialogOpen.collectAsState()
            if (aiOpen) com.py3x.ide.ui.ai.AiDialog(vm)
            val adminOpen by vm.adminOpen.collectAsState()
            if (adminOpen) com.py3x.ide.ui.admin.AdminHost(vm) { vm.adminOpen.value = false }
        }
    }
    RecoveryDialogs(vm)
    com.py3x.ide.ui.ads.LockedFeatureDialog(vm)
}

@Composable
private fun ToolDialogs(vm: IdeViewModel) {
    val open by vm.toolDialog.collectAsState()
    when (open) {
        "packages" -> com.py3x.ide.ui.packages.PackagesDialog(vm) { vm.closeToolDialog() }
        "opencv" -> com.py3x.ide.ui.vision.OpenCvStudioDialog(vm) { vm.closeToolDialog() }
        "datascience" -> com.py3x.ide.ui.tools.DataScienceDialog(vm) { vm.closeToolDialog() }
        "game" -> com.py3x.ide.ui.tools.GameStudioDialog(vm) { vm.closeToolDialog() }
    }
}

@Composable
private fun RecoveryDialogs(vm: IdeViewModel) {
    val items by vm.recovery.collectAsState()
    val crashed by vm.recoveryCrashed.collectAsState()
    val diff by vm.recoveryDiff.collectAsState()
    val first = items.firstOrNull() ?: return

    if (diff != null) {
        AlertDialog(
            onDismissRequest = { vm.recoveryDiff.value = null },
            title = { Text("Changes in ${first.rel}") },
            text = {
                SelectionContainer {
                    Text(diff.orEmpty().ifBlank { "No differences." }, fontFamily = FontFamily.Monospace, fontSize = 11.sp,
                        modifier = Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()))
                }
            },
            confirmButton = { TextButton(onClick = { vm.recoveryDiff.value = null }) { Text("Close") } },
        )
        return
    }
    AlertDialog(
        onDismissRequest = { vm.dismissRecovery() },
        title = { Text(if (crashed) "Recover your work?" else "Unsaved changes found") },
        text = {
            Column {
                Text(
                    (if (crashed) "The app closed unexpectedly. " else "") +
                        "${items.size} file${if (items.size == 1) "" else "s"} ${if (items.size == 1) "has" else "have"} changes that were never saved to disk:",
                )
                Column(Modifier.padding(top = 8.dp)) {
                    items.take(5).forEach { Text("• ${it.projectName} / ${it.rel}", fontFamily = FontFamily.Monospace, fontSize = 12.sp) }
                    if (items.size > 5) Text("…and ${items.size - 5} more")
                }
                Text("Restoring keeps the older text in version history. Discarding does too.", modifier = Modifier.padding(top = 8.dp),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = { TextButton(onClick = { vm.restoreRecovery(first) }) { Text("RESTORE") } },
        dismissButton = {
            Row {
                TextButton(onClick = { vm.viewRecoveryDiff(first) }) { Text("VIEW CHANGES") }
                TextButton(onClick = { vm.discardRecovery(first) }) { Text("DISCARD") }
            }
        },
    )
}
