package com.py3x.ide.ui.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.py3x.ide.ui.components.FullScreen
import com.py3x.ide.ui.components.GlowCard
import com.py3x.ide.ui.components.GradientButton
import com.py3x.ide.ui.components.PyMark
import com.py3x.ide.ui.components.ToolButton
import com.py3x.ide.ui.theme.Palette
import com.py3x.ide.vm.IdeViewModel
import org.json.JSONObject

/** Shows the password prompt, then the admin panel once signed in. Nothing here is visible to normal users. */
@Composable
fun AdminHost(vm: IdeViewModel, onClose: () -> Unit) {
    val token = vm.adminToken
    val backendOn by vm.backendOn.collectAsState()
    val account by vm.account.collectAsState()
    if (backendOn) {
        // Server-side admin: only a signed-in account whose role is 'admin' on the server gets in.
        if (account?.isAdmin == true) {
            FullScreen(onDismissRequest = onClose) { AdminPanel(vm, backend = true) { vm.signOut(); onClose() } }
        } else {
            AlertDialog(
                onDismissRequest = onClose,
                title = { Text("Admin access") },
                text = {
                    Text(
                        if (account == null) "Sign in from More → Account with an admin account."
                        else "This account (${account?.email}) is not an admin.",
                    )
                },
                confirmButton = { TextButton(onClick = onClose) { Text("OK") } },
            )
        }
    } else if (token == null) {
        PasswordPrompt(vm, onClose)
    } else {
        FullScreen(onDismissRequest = { vm.adminLogout(); onClose() }) {
            AdminPanel(vm) { vm.adminLogout(); onClose() }
        }
    }
}

@Composable
private fun PasswordPrompt(vm: IdeViewModel, onClose: () -> Unit) {
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    fun submit() {
        if (busy || password.isEmpty()) return
        busy = true
        vm.adminLogin(password) { msg -> busy = false; error = msg; password = "" }
    }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Admin access") },
        text = {
            Column {
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it; error = null },
                    label = { Text("Password") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, autoCorrectEnabled = false),
                    isError = error != null,
                )
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp)) }
            }
        },
        confirmButton = { TextButton(onClick = { submit() }, enabled = !busy) { Text(if (busy) "Checking…" else "Sign in") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } },
    )
}

private val AdminTabs = listOf("Overview", "Ad Networks", "Security")

/** The AdMob app ID actually compiled into this build (the SDK can only read it from the manifest). */
private fun builtInAdmobAppId(context: android.content.Context): String = try {
    val info = context.packageManager.getApplicationInfo(context.packageName, android.content.pm.PackageManager.GET_META_DATA)
    info.metaData?.getString("com.google.android.gms.ads.APPLICATION_ID").orEmpty()
} catch (e: Exception) { "" }

@Composable
private fun AdminPanel(vm: IdeViewModel, backend: Boolean = false, onSignOut: () -> Unit) {
    val stats by vm.stats.collectAsState()
    androidx.compose.runtime.LaunchedEffect(backend) { if (backend) vm.loadStats() }
    val ads by vm.ads.collectAsState()
    val unlock by vm.unlock.collectAsState()
    val context = androidx.compose.ui.platform.LocalContext.current
    val builtIn = remember { builtInAdmobAppId(context) }
    // Local editable copy; each Save button sends it to the server/runtime, which validates it again.
    var active by remember(ads) { mutableStateOf(if (ads.adsEnabled) ads.provider else "none") }
    var admobAppId by remember(ads) { mutableStateOf(ads.admobAppId) }
    var rewardedId by remember(ads) { mutableStateOf(ads.rewardedUnitId) }
    var bannerId by remember(ads) { mutableStateOf(ads.bannerUnitId) }
    var unityGame by remember(ads) { mutableStateOf(ads.unityGameId) }
    var unityPlacement by remember(ads) { mutableStateOf(ads.unityPlacementId) }
    var required by remember(ads) { mutableStateOf(ads.adsRequired.coerceIn(1, 10)) }
    var minutes by remember(ads) { mutableStateOf(ads.unlockMinutes.toString()) }
    var showPassword by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf(0) }

    fun save() = vm.updateAds(
        JSONObject().put("ads_enabled", active != "none").put("provider", active)
            .put("banner_enabled", true).put("rewarded_enabled", true)
            .put("banner_unit_id", bannerId.trim()).put("rewarded_unit_id", rewardedId.trim())
            .put("admob_app_id", admobAppId.trim()).put("unity_game_id", unityGame.trim()).put("unity_placement_id", unityPlacement.trim())
            .put("rewarded_unlock_minutes", minutes.toIntOrNull() ?: 0)
            .put("ads_required", required),
    )

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).imePadding().padding(horizontal = 16.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PyMark(34.dp)
            Text("Admin panel", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f).semantics { heading() })
            ToolButton("Sign out", onClick = onSignOut)
        }
        Text(
            if (backend) "Signed-in admin. Saved ad settings are published to every user." else "Local admin controls for this device. The session ends after 15 minutes of inactivity.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(vertical = 6.dp),
        )
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            AdminTabs.forEachIndexed { i, label ->
                ToolButton(label, onClick = { tab = i }, emphasized = tab == i, description = "$label tab" + if (tab == i) ", selected" else "")
            }
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(top = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            when (tab) {
                0 -> {
                    GlowCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Status", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                            Text("Ads: " + if (ads.adsEnabled) "on (${ads.provider})" else "off")
                            Text(
                                if (unlock.unlocked) "Reward unlock active: ${unlock.remainingSeconds / 60} min left" else "Reward unlock: not active",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            if (backend) {
                                val st = stats
                                if (st == null) Text("Loading figures…", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                else {
                                    Text("Users: ${st.optInt("users")} (${st.optInt("new_users_7d")} new this week)")
                                    Text("Active users (7 days): ${st.optInt("active_users_7d")}")
                                    Text("App opens (7 days): ${st.optInt("app_opens_7d")}")
                                    Text("Reward unlocks (7 days): ${st.optInt("ad_unlocks_7d")}")
                                }
                                Text(
                                    "Counts come from your backend. Revenue is not shown: it lives in your AdMob dashboard.",
                                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            } else Text(
                                "Users and activity figures need the online backend, which is not set up in this build. Nothing is shown rather than invented numbers.",
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                    ToolButton("Grant test unlock", onClick = { vm.adminTestUnlock() }, description = "Grant a test reward unlock for testing")
                    Text(
                        "Coding never requires ads. When ads are off, every feature is open.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                1 -> {
                    NetworkCard("AdMob", active == "admob", { active = if (it) "admob" else "none" }) {
                        OutlinedTextField(admobAppId, { admobAppId = it.trim() }, label = { Text("Enter Your AdMob App Id") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        val typed = admobAppId.trim()
                        if (typed.isNotEmpty() && typed == builtIn) {
                            Text("This is the App ID built into the installed app.", style = MaterialTheme.typography.bodySmall, color = Palette.Success)
                        } else {
                            Text(
                                "Save, then publish a new release: the build picks this App ID up from here automatically" +
                                    (if (backend) "." else " (this needs the online backend; without it, put it in py3x-config.env)") +
                                    ". Android lets AdMob read the App ID only from the installed app, so copies already installed" +
                                    (if (builtIn.isNotEmpty()) " (built with $builtIn)" else "") + " keep their old ID until updated. The ad unit IDs below apply at once.",
                                style = MaterialTheme.typography.bodySmall, color = Palette.Warning,
                            )
                        }
                        OutlinedTextField(rewardedId, { rewardedId = it.trim() }, label = { Text("Enter Your AdMob Rewarded Ad Id") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(bannerId, { bannerId = it.trim() }, label = { Text("Enter Your AdMob Banner Ad Id (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Text(
                            "Leave unit IDs empty to use Google's test ads. Use test ads until your app is approved.",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        GradientButton("Save AdMob Settings", { save() }, Modifier.fillMaxWidth())
                    }
                    NetworkCard("Unity Ads", active == "unity", { active = if (it) "unity" else "none" }) {
                        OutlinedTextField(unityGame, { unityGame = it.filter(Char::isDigit).take(12) }, label = { Text("Enter Your Unity Game Id") }, singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(unityPlacement, { unityPlacement = it.trim() }, label = { Text("Enter Your Unity Placement Id") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Text(
                            "Unity Ads is bundled in this build and shows a rewarded ad only (no banner). Switch it on and save to use it. " +
                                "While the Game ID or Placement ID is empty, nothing is locked and no Unity ad is shown. Turn on test mode in your Unity dashboard until you are approved. ",
                            style = MaterialTheme.typography.bodySmall, color = Palette.Warning,
                        )
                        GradientButton("Save Unity Settings", { save() }, Modifier.fillMaxWidth())
                    }
                    NetworkCard("Reward unlock", null, {}) {
                        Text("Ads a user must watch to unlock premium features (AI Assistant, Game Studio, OpenCV Studio, Data Science, Debugger, Packs)", style = MaterialTheme.typography.bodyMedium)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            ToolButton("−", onClick = { if (required > 1) required-- }, description = "Fewer ads required")
                            Text("$required", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            ToolButton("+", onClick = { if (required < 10) required++ }, description = "More ads required")
                            Text(if (required == 1) "ad" else "ads (1–10)", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        OutlinedTextField(
                            minutes, { minutes = it.filter(Char::isDigit).take(4) },
                            label = { Text("Unlock length (minutes, 5–1440)") }, singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth(),
                        )
                        GradientButton("Save Reward Settings", { save() }, Modifier.fillMaxWidth())
                    }
                    Text(
                        "Only one network can be on at a time. Ads stay off unless one is switched on and saved.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                else -> if (backend) {
                    Text(
                        "Admin rights come from your server account. Change the password in your Supabase dashboard; " +
                            "remove admin rights by setting role back to 'user' in the profiles table. Ad settings are protected by server-side rules, not by this screen.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    ToolButton("Change admin password", onClick = { showPassword = true })
                    Text(
                        "Only a salted hash of the password is stored. Clearing the app's data resets it to the initial password.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
    if (showPassword) ChangePasswordDialog(vm) { showPassword = false }
}

/** A titled card in the style of the ad-network screens: name, optional on/off switch, then its fields. */
@Composable
private fun NetworkCard(title: String, on: Boolean?, onToggle: (Boolean) -> Unit, content: @Composable () -> Unit) {
    GlowCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                if (on != null) Switch(on, onToggle)
            }
            content()
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 48.dp).clickable { onChange(!checked) },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, Modifier.weight(1f))
        Switch(checked, onChange)
    }
}

@Composable
private fun ChangePasswordDialog(vm: IdeViewModel, onDismiss: () -> Unit) {
    var current by remember { mutableStateOf("") }
    var new by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val keyboard = KeyboardOptions(keyboardType = KeyboardType.Password, autoCorrectEnabled = false)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Change admin password") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(current, { current = it }, label = { Text("Current password") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(), keyboardOptions = keyboard)
                OutlinedTextField(new, { new = it }, label = { Text("New password (8+ characters)") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(), keyboardOptions = keyboard)
                OutlinedTextField(confirm, { confirm = it }, label = { Text("Repeat new password") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(), keyboardOptions = keyboard)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (new != confirm) { error = "The new passwords do not match."; return@TextButton }
                vm.changeAdminPassword(current, new) { err ->
                    if (err == null) { vm.notify("Password changed. Sign in again."); onDismiss() } else error = err
                }
            }) { Text("Change") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
