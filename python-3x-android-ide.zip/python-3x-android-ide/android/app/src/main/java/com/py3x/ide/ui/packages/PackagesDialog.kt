package com.py3x.ide.ui.packages

import com.py3x.ide.ui.components.FullScreen
import com.py3x.ide.ui.components.GlowCard
import com.py3x.ide.ui.theme.Palette
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.py3x.ide.packs.PacksInfo
import com.py3x.ide.ui.components.ToolButton
import com.py3x.ide.vm.IdeViewModel
import com.py3x.ide.vm.PackageInfo
import kotlinx.coroutines.launch

@Composable
fun PackagesDialog(vm: IdeViewModel, onClose: () -> Unit) {
    FullScreen(onClose) {
        PackagesScreen(vm, onClose)
    }
}

@Composable
private fun PackagesScreen(vm: IdeViewModel, onClose: () -> Unit) {
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<PackageInfo?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var catalog by remember { mutableStateOf<List<PackageInfo>>(emptyList()) }
    var installed by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    val packsInfo by vm.packsInfo.collectAsState()
    var packsMessage by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) { vm.refreshPacks() }
    // Reload whenever the Packs app appears, disappears or reports a different package list.
    var loaded by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf(0) }
    LaunchedEffect(packsInfo) {
        catalog = vm.packageList("packages_catalog")
        installed = vm.installedPackages()
        if (query.isNotBlank()) { val (r, e) = vm.checkPackage(query); result = r; error = e }
        loaded = true
    }
    fun check() { if (query.isNotBlank()) scope.launch { val (r, e) = vm.checkPackage(query); result = r; error = e } }

    // The whole page is one lazy list, so every part of it scrolls however long the lists get.
    LazyColumn(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Package Manager", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
                ToolButton("Close", onClose)
            }
        }
        item {
            Text(
                "Android cannot run pip at runtime. Packages with native code are built for Android and bundled at build time: " +
                    "this app (Python 3.12) and the Packs app (Python 3.10) each carry their own set. This screen says honestly what is where.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (!loaded) item {
            Row(Modifier.fillMaxWidth().padding(vertical = 24.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                androidx.compose.material3.CircularProgressIndicator(Modifier.size(28.dp), strokeWidth = 3.dp)
                Text("  Loading packages…", style = MaterialTheme.typography.bodyMedium)
            }
        }
        item { PacksCard(packsInfo, packsMessage, onInstall = { packsMessage = null; vm.installPacks { packsMessage = it } }, onRefresh = { vm.refreshPacks() }) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Popular", "Installed", "Updates").forEachIndexed { i, label ->
                    ToolButton(label, onClick = { tab = i }, emphasized = tab == i, modifier = Modifier.weight(1f), description = "$label tab" + if (tab == i) ", selected" else "")
                }
            }
        }
        if (!loaded) return@LazyColumn
        when (tab) {
            0 -> {
                item {
                    OutlinedTextField(
                        query, { query = it }, label = { Text("Search or check a package (e.g. numpy)") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search, autoCorrectEnabled = false),
                        keyboardActions = KeyboardActions(onSearch = { check() }),
                    )
                }
                item { ToolButton("Check", onClick = { check() }, emphasized = true) }
                error?.let { e -> item { Text(e, color = MaterialTheme.colorScheme.error) } }
                result?.let { r -> item { PackageCard(r, packsInfo.installed, onInstallPacks = { vm.installPacks { packsMessage = it } }) } }
                item { Text("Popular packages", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 4.dp)) }
                items(catalog, key = { it.name }) { PackageCard(it, packsInfo.installed, onInstallPacks = { vm.installPacks { packsMessage = it } }) }
            }
            1 -> {
                item { Text("In this app (Python 3.12) · ${installed.size}", style = MaterialTheme.typography.titleSmall) }
                if (installed.isEmpty()) item { Text("Only the Python standard library.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                items(installed, key = { "m-" + it.first }) { (n, v) -> InstalledRow(n, v) }
                item { Text("In the Packs app (Python 3.10) · ${packsInfo.packages.size}", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 8.dp)) }
                if (!packsInfo.installed) item { Text("The Packs app is not installed.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                items(packsInfo.packages, key = { "p-" + it.first }) { (n, v) -> InstalledRow(n, v) }
            }
            else -> {
                item {
                    GlowCard(Modifier.fillMaxWidth(), accent = Palette.Warning) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("No in-app updates", style = MaterialTheme.typography.titleSmall)
                            Text(
                                "Packages contain native code built for Android and are bundled when the app is built, so they cannot be updated while the app runs " +
                                    "and this screen cannot know whether newer versions exist. To change versions, edit the package lists in the build and rebuild the app.",
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                    }
                }
                item { Text("Versions in this build", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 4.dp)) }
                items(installed, key = { "u-" + it.first }) { (n, v) -> InstalledRow(n, v) }
            }
        }
    }
}

@Composable
private fun InstalledRow(name: String, version: String) {
    GlowCard(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(name, Modifier.weight(1f), fontFamily = FontFamily.Monospace)
            Text(version, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
        }
    }
}

/** A header button that opens or closes a list of names, one per row. */
@Composable
private fun ListToggle(title: String, rows: List<String>, empty: String) {
    var open by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        ToolButton(
            (if (open) "▾ " else "⋯ ") + title, onClick = { open = !open },
            description = (if (open) "Hide " else "Show ") + title,
        )
        if (open) {
            if (rows.isEmpty()) Text(empty, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall)
            rows.forEach { Text(it, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall) }
        }
    }
}

@Composable
private fun PacksCard(info: PacksInfo, message: String?, onInstall: () -> Unit, onRefresh: () -> Unit) {
    GlowCard(Modifier.fillMaxWidth(), accent = Palette.Violet) {
    Column(
        Modifier.padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Text("Python 3.x Packs (Python 3.10)", style = MaterialTheme.typography.titleSmall)
        when {
            !info.installed -> {
                Text(
                    "Companion app with OpenCV, SciPy, scikit-learn, scikit-image and statsmodels. These only exist for Python 3.10 on Android, " +
                        "so they cannot run inside this Python 3.12 app. It is stored inside this app: nothing is downloaded.",
                    style = MaterialTheme.typography.bodySmall,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ToolButton("Install", onClick = onInstall, emphasized = true, description = "Install the Packs app")
                    ToolButton("Refresh", onClick = onRefresh, description = "Check again whether the Packs app is installed")
                }
            }
            info.problem != null -> {
                Text(info.problem, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                ToolButton("Refresh", onClick = onRefresh, description = "Check the Packs app again")
            }
            else -> {
                Text(
                    "Installed. Python ${info.python}, ${info.packages.size} packages. Use PACKS in the editor to run a file with it; " +
                        "OpenCV Studio uses it automatically.",
                    color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall,
                )
                ListToggle("Packs (${info.packages.size})", info.packages.map { "${it.first} ${it.second}" }, empty = "No packages reported.")
            }
        }
        message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
    }
}

@Composable
private fun PackageCard(p: PackageInfo, packsInstalled: Boolean = true, onInstallPacks: () -> Unit = {}) {
    val label = when (p.status) {
        "stdlib" -> "Included (standard library)"
        "bundled" -> "Bundled in this build"
        "in-packs" -> "Available in the Packs app (Python 3.10)"
        "packs" -> "Needs the Packs app (Python 3.10 only) — tap Install above"
        "buildable" -> "Not in this build — can be added at build time"
        "pure-python" -> "Not in this build — pure Python, can be bundled"
        "unsupported" -> "Not supported on Android"
        else -> "Unknown — nothing is claimed"
    }
    GlowCard(Modifier.fillMaxWidth()) {
    Column(
        Modifier.padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        Text(p.name + if (p.version.isNotEmpty()) "  ${p.version}" else "", style = MaterialTheme.typography.titleSmall)
        Text(label, color = if (p.status == "unsupported") MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
            style = MaterialTheme.typography.labelMedium)
        if (p.note.isNotEmpty()) Text(p.note, style = MaterialTheme.typography.bodySmall)
        if (p.action.isNotEmpty()) Text(p.action, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        // The only thing that can be "installed" from here is the Packs app (stored inside this app); nothing is downloaded.
        if (p.status == "packs" && !packsInstalled) ToolButton("Install Packs app", onClick = onInstallPacks, emphasized = true, description = "Install the Packs app that contains ${p.name}")
    }
    }
}
