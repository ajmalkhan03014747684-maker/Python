package com.py3x.ide.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.py3x.ide.ui.components.GlowCard
import com.py3x.ide.ui.components.GradientButton
import com.py3x.ide.ui.components.ToolButton
import com.py3x.ide.ui.theme.Palette
import com.py3x.ide.vm.IdeViewModel
import com.py3x.ide.vm.TabState

/** Shows breakpoints while idle, and the paused location, call stack and variables while debugging. */
@Composable
fun DebugPanel(vm: IdeViewModel, tab: TabState) {
    val d by vm.debug.collectAsState()
    val lines = vm.breakpoints[tab.key].orEmpty().sorted()
    if (!d.active && d.message == null && lines.isEmpty()) return
    GlowCard(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), accent = Palette.Violet) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Debugger", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Palette.Violet)
                Text(
                    when { d.paused -> "● Paused"; d.active -> "● Running"; else -> "Idle" },
                    style = MaterialTheme.typography.labelMedium,
                    color = when { d.paused -> Palette.Warning; d.active -> Palette.Success; else -> MaterialTheme.colorScheme.onSurfaceVariant },
                )
            }
            if (lines.isNotEmpty()) {
                Text("Breakpoints: " + lines.joinToString(", "), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else if (!d.active) {
                Text("No breakpoints. In the editor, put the cursor on a line and tap ● BP.", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            d.message?.let { Text(it, style = MaterialTheme.typography.labelMedium) }
            if (d.active) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    GradientButton("Continue", { vm.debugCommand("continue") }, enabled = d.paused, glyph = "▶", colors = listOf(Palette.Success, Color(0xFF16A34A)))
                    ToolButton("Step in", { vm.debugCommand("step") }, enabled = d.paused)
                    ToolButton("Step over", { vm.debugCommand("over") }, enabled = d.paused)
                    ToolButton("Step out", { vm.debugCommand("out") }, enabled = d.paused)
                    ToolButton("■ Stop", { vm.debugCommand("stop") })
                }
            }
            if (d.paused) {
                HorizontalDivider()
                Text("Paused at ${d.file}:${d.line} in ${d.function}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                Column(Modifier.heightIn(max = 200.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Call stack", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                    d.stack.forEach { Text("↳ $it", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    Text("Variables", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 4.dp))
                    if (d.variables.isEmpty()) Text("No local variables", fontSize = 12.sp)
                    d.variables.forEach { (k, v) ->
                        Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(8.dp)).padding(horizontal = 8.dp, vertical = 4.dp)) {
                            Text(k, fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = Palette.Cyan, modifier = Modifier.weight(0.4f))
                            Text(v, fontFamily = FontFamily.Monospace, fontSize = 12.sp, modifier = Modifier.weight(0.6f))
                        }
                    }
                }
            }
        }
    }
}
