package com.py3x.ide.ui.editor

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.sp
import com.py3x.ide.ui.components.ConfirmDialog
import com.py3x.ide.ui.components.Dur
import com.py3x.ide.ui.components.NameDialog
import com.py3x.ide.ui.components.ToolButton
import com.py3x.ide.ui.components.motion
import com.py3x.ide.ui.theme.Palette
import com.py3x.ide.vm.IdeViewModel
import com.py3x.ide.vm.RunPhase
import com.py3x.ide.vm.SaveIndicator
import com.py3x.ide.vm.TabState
import kotlinx.coroutines.delay

@Composable
fun EditorScreen(vm: IdeViewModel, onOpenFiles: () -> Unit) {
    val settings by vm.settings.collectAsState()
    val run by vm.run.collectAsState()
    val outputVisible by vm.outputVisible.collectAsState()
    val bracket by vm.bracket.collectAsState()
    val tab = vm.currentTab
    val focus = remember { FocusRequester() }

    Column(Modifier.fillMaxSize().imePadding()) {
        if (tab == null) {
            EmptyEditor(onOpenFiles)
            return@Column
        }
        TabBar(vm)
        RunBar(vm, tab)

        var findOpen by remember { mutableStateOf(false) }
        var replaceOpen by remember { mutableStateOf(false) }
        var gotoOpen by remember { mutableStateOf(false) }

        AnimatedVisibility(
            visible = findOpen,
            enter = expandVertically(motion(Dur.SMALL)) + fadeIn(motion(Dur.SMALL)),
            exit = shrinkVertically(motion(Dur.SMALL)) + fadeOut(motion(Dur.SMALL)),
        ) {
            FindBar(vm, tab, showReplace = replaceOpen, onClose = { findOpen = false; replaceOpen = false })
        }

        Box(Modifier.weight(1f)) {
            CodeField(
                tab = tab,
                settings = settings,
                bracketPair = bracket,
                onValueChange = { vm.onEdit(tab, it) },
                focusRequester = focus,
            )
        }

        EditorStatusBar(tab, settings.tabWidth)
        DebugPanel(vm, tab)
        DiagnosticBar(tab) { vm.gotoLine(tab, it) }

        // Running opens a separate, full-screen Run page (hosted by the app shell) that shows only the output.

        SuggestionStrip(vm, tab)
        EditorToolbar(
            vm = vm,
            tab = tab,
            onFind = { findOpen = true; replaceOpen = false },
            onReplace = { findOpen = true; replaceOpen = true },
            onGoto = { gotoOpen = true },
        )

        if (gotoOpen) {
            NameDialog(
                title = "Go to line",
                hint = "Line number",
                confirmLabel = "Go",
                onConfirm = { text ->
                    text.toIntOrNull()?.let { vm.gotoLine(tab, it) }
                    gotoOpen = false
                },
                onDismiss = { gotoOpen = false },
            )
        }
    }

    vm.pendingClose?.let { t ->
        ConfirmDialog(
            title = "Unsaved changes",
            message = "${t.title} has changes that are not saved to the file. Discarded text stays in version history.",
            confirmLabel = "Save",
            onConfirm = { vm.saveAndClose(t) },
            neutralLabel = "Discard",
            onNeutral = { vm.discardAndClose(t) },
            onDismiss = { vm.pendingClose = null },
        )
    }
}

@Composable
private fun EmptyEditor(onOpenFiles: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("No file open", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.size(8.dp))
        Text(
            "Open a file from your project, or create a new one.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.size(16.dp))
        ToolButton("Browse files", onClick = onOpenFiles, emphasized = true)
    }
}

@Composable
private fun TabBar(vm: IdeViewModel) {
    Row(
        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).horizontalScroll(rememberScrollState()),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        vm.tabs.forEachIndexed { index, t ->
            val selected = index == vm.activeTab
            val bg by animateColorAsState(
                if (selected) MaterialTheme.colorScheme.background else MaterialTheme.colorScheme.surface,
                motion(Dur.SMALL), label = "tabBg",
            )
            Row(
                Modifier
                    .background(bg)
                    .clickable { vm.selectTab(index) }
                    .heightIn(min = 48.dp)
                    .padding(start = 14.dp)
                    .semantics { contentDescription = "Tab ${t.title}${if (t.isDirty) ", unsaved" else ""}" },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column {
                    Text(
                        t.title + if (t.isDirty) " •" else "",
                        color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                        maxLines = 1,
                    )
                    Box(Modifier.padding(top = 2.dp).size(width = 28.dp, height = 3.dp).background(if (selected) MaterialTheme.colorScheme.primary else Color.Transparent, RoundedCornerShape(2.dp)))
                }
                TextButton(
                    onClick = { vm.requestCloseTab(t) },
                    modifier = Modifier.semantics { contentDescription = "Close ${t.title}" },
                ) { Text("✕") }
            }
        }
    }
}

@Composable
private fun RunBar(vm: IdeViewModel, tab: TabState) {
    val run by vm.run.collectAsState()
    val save by vm.saveIndicator.collectAsState()
    val outputVisible by vm.outputVisible.collectAsState()
    val active = run.phase.isActive
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        // The run buttons scroll sideways so a narrow phone never pushes SAVE off screen.
        Row(
            Modifier.weight(1f).horizontalScroll(rememberScrollState()),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            RunButton(active = active, onClick = { vm.runCurrentFile() })
            val dbg by vm.debug.collectAsState()
            val packsInfo by vm.packsInfo.collectAsState()
            ToolButton(
                "PACKS", onClick = { vm.runWithPacks() }, enabled = !active && !dbg.active && packsInfo.installed,
                description = if (packsInfo.installed) "Run with the Packs app (Python 3.10, OpenCV, SciPy, scikit-learn)"
                else "Run with the Packs app (not installed; see Package Manager)",
            )
            ToolButton("AI", onClick = { vm.openAi() }, description = "Open the AI assistant")
            ToolButton("● BP", onClick = { vm.toggleBreakpoint(tab) }, description = "Toggle breakpoint at cursor line")
            ToolButton("↻", onClick = { vm.restartRun() }, enabled = !active && run.phase != RunPhase.READY, description = "Restart script")
        }
        SaveStatus(save, tab.isDirty)
        ToolButton("SAVE", onClick = { vm.saveActive() }, enabled = tab.isDirty, description = "Save file")
        ToolButton("OUTPUT", onClick = { vm.toggleOutput() }, description = "Show the output of the last run")
    }
}

@Composable
private fun RunButton(active: Boolean, onClick: () -> Unit) {
    val source = remember { MutableInteractionSource() }
    val brush = if (active) Brush.linearGradient(listOf(Palette.Violet, Color(0xFF5B3FD6)))
    else Brush.linearGradient(listOf(Palette.Success, Color(0xFF16A34A)))
    Surface(
        onClick = onClick,
        enabled = !active,
        interactionSource = source,
        color = Color.Transparent,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .heightIn(min = 48.dp)
            .semantics { contentDescription = if (active) "Script running" else "Run script" },
    ) {
        AnimatedContent(
            targetState = active,
            transitionSpec = { fadeIn(tween(Dur.MICRO)) togetherWith fadeOut(tween(Dur.MICRO)) },
            label = "runLabel",
            modifier = Modifier.background(brush, RoundedCornerShape(12.dp)).padding(horizontal = 16.dp, vertical = 10.dp),
        ) { isActive ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (isActive) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = Color.White)
                    Spacer(Modifier.width(8.dp))
                    Text("RUNNING…", style = MaterialTheme.typography.labelLarge, color = Color.White)
                } else {
                    Text("▶ RUN", style = MaterialTheme.typography.labelLarge, color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/** Line, column and file facts under the code, like a desktop editor's status bar. */
@Composable
private fun EditorStatusBar(tab: TabState, tabWidth: Int) {
    val v = tab.value
    val pos = v.selection.start.coerceIn(0, v.text.length)
    val before = v.text.substring(0, pos)
    val line = before.count { it == '\n' } + 1
    val col = pos - (before.lastIndexOf('\n') + 1) + 1
    val total = v.text.count { it == '\n' } + 1
    Row(
        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(horizontal = 12.dp, vertical = 3.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        val c = MaterialTheme.colorScheme.onSurfaceVariant
        Text("Ln $line, Col $col", style = MaterialTheme.typography.labelSmall, color = c)
        Text("$total lines", style = MaterialTheme.typography.labelSmall, color = c)
        Text("Spaces: $tabWidth", style = MaterialTheme.typography.labelSmall, color = c)
        Text("UTF-8", style = MaterialTheme.typography.labelSmall, color = c)
        Text("Python", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
private fun SaveStatus(state: SaveIndicator, dirty: Boolean) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(state) {
        visible = state != SaveIndicator.IDLE
        if (state == SaveIndicator.DRAFT_SAVED || state == SaveIndicator.SAVED) {
            delay(2500)
            visible = false
        }
    }
    AnimatedVisibility(visible, enter = fadeIn(motion(Dur.MICRO)), exit = fadeOut(motion(Dur.SMALL))) {
        Text(
            when (state) {
                SaveIndicator.SAVING -> "Saving…"
                SaveIndicator.DRAFT_SAVED -> if (dirty) "Local draft saved" else "✓ Saved"
                SaveIndicator.SAVED -> "✓ Saved"
                SaveIndicator.IDLE -> ""
            },
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.semantics { contentDescription = "Autosave status" },
        )
    }
}

@Composable
private fun DiagnosticBar(tab: TabState, onGoto: (Int) -> Unit) {
    val first = tab.diagnostics.firstOrNull()
    AnimatedVisibility(
        visible = first != null,
        enter = slideInVertically(motion(Dur.SMALL)) { it } + fadeIn(motion(Dur.SMALL)),
        exit = slideOutVertically(motion(Dur.SMALL)) { it } + fadeOut(motion(Dur.SMALL)),
    ) {
        if (first != null) {
            Row(
                Modifier.fillMaxWidth()
                    .background(MaterialTheme.colorScheme.error.copy(alpha = 0.14f))
                    .clickable { onGoto(first.line) }
                    .heightIn(min = 40.dp)
                    .padding(horizontal = 12.dp)
                    .semantics { contentDescription = "Syntax error on line ${first.line}: ${first.message}" },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                // Text marker as well as colour, so the error is not conveyed by colour alone.
                Text("⚠ Line ${first.line}: ${first.message}", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
internal fun StatusChip(run: com.py3x.ide.vm.RunStatus) {
    val (label, color) = when (run.phase) {
        RunPhase.READY -> "Ready" to MaterialTheme.colorScheme.onSurfaceVariant
        RunPhase.PREPARING -> "Preparing…" to MaterialTheme.colorScheme.onSurfaceVariant
        RunPhase.RUNNING -> "◉ Running" to MaterialTheme.colorScheme.secondary
        RunPhase.STOPPED -> "■ Stopped" to Palette.Warning
        RunPhase.COMPLETED -> "✓ Process finished" to Palette.Success
        RunPhase.FAILED -> "⚠ Error" to MaterialTheme.colorScheme.error
    }
    val detail = buildString {
        if (!run.phase.isActive && run.phase != RunPhase.READY) {
            run.exitCode?.let { append(" · exit $it") }
            append(" · ${"%.2f".format(run.durationSec)}s")
        }
    }
    Text(
        label + detail, color = color, style = MaterialTheme.typography.labelLarge,
        modifier = Modifier.semantics { contentDescription = "Run status: $label$detail" },
    )
}

@Composable
private fun SuggestionStrip(vm: IdeViewModel, tab: TabState) {
    val sug by vm.suggestions.collectAsState()
    val (prefix, items) = sug
    AnimatedVisibility(
        visible = items.isNotEmpty(),
        enter = fadeIn(motion(Dur.MICRO)) + expandVertically(motion(Dur.MICRO)),
        exit = fadeOut(motion(Dur.MICRO)) + shrinkVertically(motion(Dur.MICRO)),
    ) {
        Row(
            Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface)
                .horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items.forEach { (label, insert) ->
                val source = remember { MutableInteractionSource() }
                Surface(
                    onClick = { vm.acceptSuggestion(tab, prefix, insert) },
                    interactionSource = source,
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                    modifier = Modifier.heightIn(min = 40.dp).semantics { contentDescription = "Insert $insert" },
                ) {
                    Box(Modifier.padding(horizontal = 12.dp), contentAlignment = Alignment.Center) {
                        Text(label, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun EditorToolbar(
    vm: IdeViewModel,
    tab: TabState,
    onFind: () -> Unit,
    onReplace: () -> Unit,
    onGoto: () -> Unit,
) {
    @Suppress("DEPRECATION")
    val clipboard = LocalClipboardManager.current
    Row(
        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface)
            .horizontalScroll(rememberScrollState()).padding(horizontal = 6.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        val v = tab.value
        ToolButton("Select All", onClick = { tab.value = v.copy(selection = TextRange(0, v.text.length)) })
        ToolButton("Copy", enabled = !v.selection.collapsed, onClick = {
            clipboard.setText(AnnotatedString(v.text.substring(v.selection.min, v.selection.max)))
        })
        ToolButton("Cut", enabled = !v.selection.collapsed, onClick = {
            clipboard.setText(AnnotatedString(v.text.substring(v.selection.min, v.selection.max)))
            vm.applyEdit(tab, TextFieldValue(v.text.removeRange(v.selection.min, v.selection.max), TextRange(v.selection.min)))
        })
        ToolButton("Paste", onClick = {
            val clip = clipboard.getText()?.text.orEmpty()
            if (clip.isNotEmpty()) {
                val text = v.text.replaceRange(v.selection.min, v.selection.max, clip)
                vm.applyEdit(tab, TextFieldValue(text, TextRange(v.selection.min + clip.length)))
            }
        })
        ToolButton("Undo", enabled = tab.undo.canUndo, onClick = { vm.undo() })
        ToolButton("Redo", enabled = tab.undo.canRedo, onClick = { vm.redo() })
        ToolButton("Indent", onClick = { vm.editOp(tab, "indent") })
        ToolButton("Outdent", onClick = { vm.editOp(tab, "outdent") })
        ToolButton("Comment", onClick = { vm.editOp(tab, "toggle_comment") })
        ToolButton("Find", onClick = onFind)
        ToolButton("Replace", onClick = onReplace)
        ToolButton("Go To", onClick = onGoto, description = "Go to line")
        ToolButton("Dup Line", onClick = { vm.editOp(tab, "duplicate_line") }, description = "Duplicate line")
        ToolButton("Del Line", onClick = { vm.editOp(tab, "delete_line") }, description = "Delete line")
        ToolButton("Run Sel.", onClick = { vm.runSelection(tab) }, description = "Run selected code or current line")
    }
}

@Composable
private fun FindBar(vm: IdeViewModel, tab: TabState, showReplace: Boolean, onClose: () -> Unit) {
    var query by remember { mutableStateOf("") }
    var replacement by remember { mutableStateOf("") }
    var caseSensitive by remember { mutableStateOf(false) }
    var regex by remember { mutableStateOf(false) }
    var wholeWord by remember { mutableStateOf(false) }
    val count by vm.findCount.collectAsState()
    val options = IdeViewModel.FindOptions(caseSensitive, regex, wholeWord)

    LaunchedEffect(query, tab.value.text, caseSensitive, regex, wholeWord) {
        delay(200)
        vm.countMatches(tab, query, options)
    }
    Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                placeholder = { Text("Find") }, modifier = Modifier.weight(1f),
                supportingText = { count?.let { Text(if (it == 0) "No matches" else "$it matches") } },
            )
            ToolButton("↑", onClick = { vm.findNext(tab, query, options, forward = false) }, description = "Previous match")
            ToolButton("↓", onClick = { vm.findNext(tab, query, options, forward = true) }, description = "Next match")
            ToolButton("✕", onClick = onClose, description = "Close find")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            ToolButton(if (caseSensitive) "Aa ✓" else "Aa", onClick = { caseSensitive = !caseSensitive }, description = "Match case")
            ToolButton(if (wholeWord) "Word ✓" else "Word", onClick = { wholeWord = !wholeWord }, description = "Whole word")
            ToolButton(if (regex) ".* ✓" else ".*", onClick = { regex = !regex }, description = "Regular expression")
        }
        if (showReplace) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(
                    value = replacement, onValueChange = { replacement = it }, singleLine = true,
                    placeholder = { Text("Replace with") }, modifier = Modifier.weight(1f),
                )
                ToolButton("Replace", onClick = { vm.replaceNext(tab, query, replacement, options) })
                ToolButton("All", onClick = { vm.replaceAll(tab, query, replacement, options) }, description = "Replace all")
            }
        }
    }
}
