package com.py3x.ide.vm

/**
 * A small terminal screen. It understands the control codes that console programs use to draw (cursor moves, clear
 * screen, clear line, colours), so animations such as a spinning donut redraw in place instead of piling up as text.
 *
 * It is not a full terminal: no alternate screen, no mouse, no background colours. Anything it does not understand is
 * ignored, never shown as stray characters.
 */
class AnsiScreen(private val screenRows: Int = 50, private val maxRows: Int = 1500) {
    class Row {
        val chars = StringBuilder()
        val styles = ArrayList<Int>()
    }

    val rows = ArrayList<Row>()
    var curRow = 0
        private set
    var curCol = 0
        private set
    /** Longest line seen so far, in characters. */
    var maxCols = 0
        private set
    /** True once the program moved the cursor or cleared the screen (a drawing program rather than plain printing). */
    var drawing = false
        private set

    private var topRow = 0
    private var style = 0
    private var bold = false
    private var savedRow = 0
    private var savedCol = 0

    private enum class Mode { TEXT, ESC, CSI, OSC, OSC_ESC }
    private var mode = Mode.TEXT
    private val csi = StringBuilder()

    fun reset() {
        rows.clear(); curRow = 0; curCol = 0; maxCols = 0; drawing = false; topRow = 0
        style = 0; bold = false; mode = Mode.TEXT; csi.setLength(0)
    }

    fun feed(text: String, isError: Boolean) {
        for (c in text) {
            when (mode) {
                Mode.TEXT -> plain(c, isError)
                Mode.ESC -> when (c) {
                    '[' -> { mode = Mode.CSI; csi.setLength(0) }
                    ']' -> mode = Mode.OSC
                    'c' -> { clearScreen(); curRow = topRow; curCol = 0; style = 0; bold = false; drawing = true; mode = Mode.TEXT }
                    '7' -> { savedRow = curRow; savedCol = curCol; mode = Mode.TEXT }
                    '8' -> { curRow = savedRow; curCol = savedCol; mode = Mode.TEXT }
                    else -> mode = Mode.TEXT
                }
                Mode.CSI -> {
                    if (c in '@'..'~') { runCsi(c); mode = Mode.TEXT } else if (csi.length < 64) csi.append(c) else mode = Mode.TEXT
                }
                Mode.OSC -> if (c == '\u0007') mode = Mode.TEXT else if (c == '\u001b') mode = Mode.OSC_ESC
                Mode.OSC_ESC -> mode = Mode.TEXT
            }
        }
    }

    private fun plain(c: Char, isError: Boolean) {
        when (c) {
            '\u001b' -> mode = Mode.ESC
            '\n' -> { lineFeed(); curCol = 0 }
            '\r' -> curCol = 0
            '\b' -> if (curCol > 0) curCol--
            '\t' -> curCol = (curCol / 8 + 1) * 8
            else -> if (c >= ' ') put(c, if (style == 0 && isError) ERROR_STYLE else style)
        }
    }

    private fun row(r: Int): Row {
        while (rows.size <= r) rows.add(Row())
        return rows[r]
    }

    private fun put(c: Char, st: Int) {
        val row = row(curRow)
        while (row.chars.length < curCol) { row.chars.append(' '); row.styles.add(0) }
        if (curCol < row.chars.length) { row.chars.setCharAt(curCol, c); row.styles[curCol] = st }
        else { row.chars.append(c); row.styles.add(st) }
        curCol++
        if (curCol > maxCols) maxCols = curCol
    }

    private fun lineFeed() {
        curRow++
        row(curRow)
        if (curRow >= topRow + screenRows) topRow = curRow - screenRows + 1
        if (rows.size > maxRows) {
            val drop = rows.size - maxRows
            repeat(drop) { rows.removeAt(0) }
            topRow = maxOf(0, topRow - drop); curRow = maxOf(0, curRow - drop)
            savedRow = maxOf(0, savedRow - drop)
        }
    }

    private fun clearRow(r: Int) { if (r in rows.indices) { rows[r].chars.setLength(0); rows[r].styles.clear() } }

    private fun clearScreen() { for (r in topRow until rows.size) clearRow(r) }

    private fun params(): List<Int?> {
        val s = csi.toString().trimStart('?', '>', '=')
        if (s.isEmpty()) return emptyList()
        return s.split(';').map { it.toIntOrNull() }
    }

    private fun runCsi(fin: Char) {
        val p = params()
        fun n(i: Int, def: Int) = (p.getOrNull(i) ?: def).let { if (it < 1 && def >= 1) def else it }
        when (fin) {
            'H', 'f' -> {
                drawing = true
                curRow = topRow + (n(0, 1) - 1).coerceIn(0, screenRows - 1); curCol = (n(1, 1) - 1).coerceAtLeast(0); row(curRow)
            }
            'A' -> { drawing = true; curRow = maxOf(topRow, curRow - n(0, 1)) }
            'B' -> { drawing = true; curRow = minOf(topRow + screenRows - 1, curRow + n(0, 1)); row(curRow) }
            'C' -> { drawing = true; curCol += n(0, 1) }
            'D' -> { drawing = true; curCol = maxOf(0, curCol - n(0, 1)) }
            'G' -> { drawing = true; curCol = (n(0, 1) - 1).coerceAtLeast(0) }
            'd' -> { drawing = true; curRow = topRow + (n(0, 1) - 1).coerceIn(0, screenRows - 1); row(curRow) }
            'J' -> {
                drawing = true
                when (p.getOrNull(0) ?: 0) {
                    0 -> { truncateFromCursor(); for (r in curRow + 1 until rows.size) clearRow(r) }
                    1 -> { for (r in topRow until curRow) clearRow(r); blankToCursor() }
                    2 -> clearScreen()
                    3 -> { for (r in rows.indices) clearRow(r) }
                }
            }
            'K' -> when (p.getOrNull(0) ?: 0) {
                0 -> truncateFromCursor()
                1 -> blankToCursor()
                2 -> clearRow(curRow)
            }
            's' -> { savedRow = curRow; savedCol = curCol }
            'u' -> { curRow = savedRow; curCol = savedCol }
            'm' -> sgr(p)
            else -> {}
        }
    }

    private fun truncateFromCursor() {
        if (curRow !in rows.indices) return
        val r = rows[curRow]
        if (curCol < r.chars.length) { r.chars.setLength(curCol); while (r.styles.size > curCol) r.styles.removeAt(r.styles.size - 1) }
    }

    private fun blankToCursor() {
        if (curRow !in rows.indices) return
        val r = rows[curRow]
        for (i in 0..minOf(curCol, r.chars.length - 1)) { r.chars.setCharAt(i, ' '); r.styles[i] = 0 }
    }

    private fun sgr(p: List<Int?>) {
        val list = if (p.isEmpty()) listOf(0) else p.map { it ?: 0 }
        var i = 0
        while (i < list.size) {
            when (val v = list[i]) {
                0 -> { style = 0; bold = false }
                1 -> { bold = true; if (style in 1..8) style += 8 }
                22 -> { bold = false; if (style in 9..16) style -= 8 }
                in 30..37 -> style = (v - 29) + if (bold) 8 else 0
                39 -> style = 0
                in 90..97 -> style = v - 89 + 8
                38 -> {
                    val mode = list.getOrNull(i + 1)
                    if (mode == 5) { style = xterm(list.getOrNull(i + 2) ?: 0); i += 2 }
                    else if (mode == 2) {
                        val r = list.getOrNull(i + 2) ?: 0; val g = list.getOrNull(i + 3) ?: 0; val b = list.getOrNull(i + 4) ?: 0
                        style = RGB_FLAG or ((r and 255) shl 16) or ((g and 255) shl 8) or (b and 255); i += 4
                    }
                }
                48 -> { val mode = list.getOrNull(i + 1); i += if (mode == 5) 2 else if (mode == 2) 4 else 0 }
                else -> {}
            }
            i++
        }
    }

    private fun xterm(n: Int): Int = when {
        n in 0..7 -> n + 1
        n in 8..15 -> n + 1
        n in 16..231 -> {
            val k = n - 16
            fun lvl(x: Int) = if (x == 0) 0 else 55 + x * 40
            RGB_FLAG or (lvl(k / 36) shl 16) or (lvl(k / 6 % 6) shl 8) or lvl(k % 6)
        }
        n in 232..255 -> { val g = 8 + (n - 232) * 10; RGB_FLAG or (g shl 16) or (g shl 8) or g }
        else -> 0
    }

    companion object {
        const val RGB_FLAG = 0x1000000
        /** Style for text written to stderr when the program set no colour. */
        const val ERROR_STYLE = 0x2000000
    }
}
