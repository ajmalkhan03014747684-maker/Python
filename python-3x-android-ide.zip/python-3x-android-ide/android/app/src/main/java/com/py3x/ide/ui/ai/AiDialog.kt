package com.py3x.ide.ui.ai

import com.py3x.ide.ui.components.FullScreen
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.py3x.ide.ui.components.GlowCard
import com.py3x.ide.ui.components.PyMark
import com.py3x.ide.ui.components.ToolButton
import com.py3x.ide.ui.components.ToolTile
import com.py3x.ide.ui.theme.Palette
import androidx.compose.ui.text.font.FontWeight
import com.py3x.ide.vm.IdeViewModel

@Composable
fun AiDialog(vm: IdeViewModel) {
    FullScreen({ vm.closeAi() }) {
        AiScreen(vm)
    }
}

@Composable
private fun AiScreen(vm: IdeViewModel) {
    val busy by vm.aiBusy.collectAsState()
    val messages = vm.aiMessages
    val clipboard = LocalClipboardManager.current
    val listState = rememberLazyListState()
    var question by remember { mutableStateOf("") }

    LaunchedEffect(messages.size) { if (messages.isNotEmpty()) listState.animateScrollToItem(listState.layoutInfo.totalItemsCount - 1) }

    // One scrolling list for the whole page.
    LazyColumn(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).imePadding(),
        state = listState,
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PyMark(34.dp)
                Text("AI Assistant", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                ToolButton("Close", onClick = { vm.closeAi() })
            }
        }
        item {
            Text(
                "Works on this phone, with no key, account or internet. Open a file (or select some code), then tap an action. " +
                    "It follows fixed rules, so it can't judge whether your logic is right.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        item {
            val actions = listOf(
                Triple("?", "Explain", "explain"), Triple("✓", "Fix", "fix"), Triple("↑", "Improve", "improve"),
                Triple("T", "Tests", "tests"), Triple("\"", "Docstrings", "docstring"),
            )
            val tints = listOf(Palette.Blue, Palette.Success, Palette.Violet, Palette.Cyan, Palette.Warning)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                actions.withIndex().chunked(3).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { (i, a) -> ToolTile(a.first, a.second, Modifier.weight(1f), tint = tints[i]) { if (!busy) vm.aiAsk(a.third) } }
                        if (row.size < 3) ToolTile("↺", "New chat", Modifier.weight(1f), tint = Palette.Blue) { if (!busy) vm.newAiChat() }
                        repeat(3 - row.size - (if (row.size < 3) 1 else 0)) { androidx.compose.foundation.layout.Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        }
        item {
            GlowCard(Modifier.fillMaxWidth(), accent = Palette.Cyan) {
                Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        question, { question = it }, label = { Text("Ask a question or paste code") }, modifier = Modifier.weight(1f), maxLines = 4,
                    )
                    ToolButton("Send", onClick = { vm.aiAsk("chat", question); question = "" }, enabled = !busy && question.isNotBlank(), emphasized = true)
                }
            }
        }
        if (messages.isEmpty()) item {
            Text("Try: tap Explain on your open file, or ask “what is a list?”, or paste a line of code.",
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        items(messages.size) { i ->
            val m = messages[i]
            val mine = m.role == "user"
            GlowCard(Modifier.fillMaxWidth(), accent = if (mine) Palette.Violet else Palette.Blue) {
              Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(if (mine) "You" else "Assistant", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                SelectionContainer { Text(m.text, fontFamily = if (mine) null else androidx.compose.ui.text.font.FontFamily.Monospace) }
                if (!mine) Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    m.fix?.let { f ->
                        val tab = vm.currentTab
                        ToolButton("Apply fix", onClick = { if (tab != null) vm.applyFix(tab, f) else vm.notify("Open the file first.") }, emphasized = true, description = "Apply the suggested fix to the open file")
                    }
                    ToolButton("Copy", onClick = { clipboard.setText(AnnotatedString(m.text)); vm.notify("Copied") }, description = "Copy answer")
                }
              }
            }
        }
        if (busy) item { Text("Thinking…", color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}
