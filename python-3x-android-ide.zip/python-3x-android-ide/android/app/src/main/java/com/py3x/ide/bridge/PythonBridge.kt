package com.py3x.ide.bridge

import android.content.Context
import com.chaquo.python.PyObject
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener

/** Raised when the Python side returns {"ok": false, "error": ...}. The message is user-presentable. */
class BridgeException(message: String) : Exception(message)

/**
 * Thin wrapper over the Python backend (`python/main.py`).
 *
 * Every Python API method returns a JSON envelope. [call] unwraps it and returns the
 * parsed `data` (JSONObject, JSONArray, String, Number, Boolean or null).
 *
 * Never call this from the main thread while typing: a long native call inside a running
 * script can hold the GIL. ViewModels use Dispatchers.IO for every call.
 */
class PythonBridge private constructor(private val api: PyObject) {

    fun call(method: String, vararg args: Any?): Any? {
        val raw = api.callAttr(method, *args).toString()
        val envelope = JSONTokener(raw).nextValue() as JSONObject
        if (!envelope.getBoolean("ok")) {
            throw BridgeException(envelope.optString("error", "Unknown error"))
        }
        return if (envelope.isNull("data")) null else envelope.get("data")
    }

    fun obj(method: String, vararg args: Any?): JSONObject = call(method, *args) as JSONObject
    fun arr(method: String, vararg args: Any?): JSONArray = call(method, *args) as JSONArray
    fun str(method: String, vararg args: Any?): String = call(method, *args) as String
    fun bool(method: String, vararg args: Any?): Boolean = call(method, *args) as Boolean
    fun int(method: String, vararg args: Any?): Int = (call(method, *args) as Number).toInt()

    fun shutdown() {
        runCatching { call("end_session") }
    }

    companion object {
        /** Starts the embedded interpreter (first call only) and creates the backend. Blocking. */
        fun start(context: Context): PythonBridge {
            if (!Python.isStarted()) Python.start(AndroidPlatform(context.applicationContext))
            val main = Python.getInstance().getModule("main")
            val dataDir = context.applicationContext.filesDir.absolutePath
            // Chaquopy's Python cannot spawn a python executable, so use the in-process runner.
            val api = main.callAttr("create_app", dataDir, true)
            return PythonBridge(api)
        }
    }
}

/**
 * Receives streamed output from a running script. Python calls these methods by name
 * (see `Py3xApi._callbacks`), on its own worker threads, so implementations must be thread-safe.
 */
class RunListener(
    private val output: (stream: String, text: String) -> Unit,
    private val state: (String) -> Unit,
    private val finish: (JSONObject) -> Unit,
) {
    fun onOutput(stream: String, text: String) = output(stream, text)
    fun onState(state: String) = this.state(state)
    fun onFinish(resultJson: String) = finish(JSONObject(resultJson))
}

/** Receives terminal output; see `Py3xApi.terminal_exec`. */
class TerminalListener(
    private val output: (String) -> Unit,
    private val done: (Int) -> Unit,
) {
    fun onOutput(text: String) = output(text)
    fun onDone(exitCode: Int) = done(exitCode)
}

/** Receives debugger events (output / paused / finished) as JSON; see `Py3xApi.debug_start`. */
class DebugListener(private val handler: (JSONObject) -> Unit) {
    fun onEvent(raw: String) = handler(JSONObject(raw))
}
