package com.py3x.ide

import android.app.Application

class Py3xApplication : Application()
