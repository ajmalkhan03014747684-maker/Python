package com.py3x.ide.ui.ads

import android.os.SystemClock
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.py3x.ide.ui.components.GlowCard
import com.py3x.ide.ui.components.GradientButton
import com.py3x.ide.ui.theme.LocalReduceMotion
import com.py3x.ide.ui.theme.Palette
import com.py3x.ide.vm.IdeViewModel
import kotlinx.coroutines.delay

private val Unlocked = listOf("AI Assistant", "Game Studio", "OpenCV Studio", "Data Science examples", "Pro debugger", "Packs (SciPy, scikit-learn, OpenCV)")

/** "m:ss" (or "h:mm:ss") for the time left on the unlock, ticking once a second. Calls [onExpired] when it reaches zero. */
@Composable
fun rememberCountdown(vm: IdeViewModel, onExpired: () -> Unit = {}): Pair<String, Long> {
    val endsAt by vm.unlockEndsAt.collectAsState()
    var now by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    LaunchedEffect(endsAt) {
        while (true) {
            now = SystemClock.elapsedRealtime()
            if (now >= endsAt) break
            delay(1000)
        }
        if (endsAt > 0L) { vm.refreshAds(); onExpired() }
    }
    val left = maxOf(0L, (endsAt - now + 999) / 1000)
    val h = left / 3600
    val m = left % 3600 / 60
    val s = left % 60
    val text = if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
    return text to left
}

/**
 * Shown when a locked feature is tapped. Watching a finished rewarded ad unlocks everything for the configured time;
 * nothing unlocks if the ad fails or is skipped.
 */
@Composable
fun LockedFeatureDialog(vm: IdeViewModel) {
    val prompt by vm.lockPrompt.collectAsState()
    val p = prompt ?: return
    val ads by vm.ads.collectAsState()
    var earned by remember(p) { mutableStateOf(false) }
    val watched by vm.adsWatched.collectAsState()
    val need = ads.adsRequired.coerceIn(1, 10)
    val (clock, _) = rememberCountdown(vm)
    val reduce = LocalReduceMotion.current
    val pulse by rememberInfiniteTransition(label = "glow")
        .animateFloat(0.35f, 0.9f, infiniteRepeatable(tween(1200), RepeatMode.Reverse), label = "glowAlpha")
    val glow = if (reduce) 0.6f else pulse

    Dialog(onDismissRequest = { vm.dismissLock() }) {
        GlowCard(Modifier.fillMaxWidth(), accent = Palette.Violet) {
            Box {
                if (!reduce) Particles(Modifier.matchParentSize())
                Column(
                    Modifier.background(Brush.verticalGradient(listOf(Palette.Violet.copy(alpha = 0.16f), Color.Transparent))).padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Box(
                        Modifier.size(64.dp).background(Palette.Violet.copy(alpha = glow * 0.35f), RoundedCornerShape(20.dp)),
                        contentAlignment = Alignment.Center,
                    ) { Text(if (earned) "🎉" else "🔒", fontSize = 30.sp) }
                    Text(
                        if (earned) "Advanced Mode Unlocked" else "Unlock Premium Features",
                        style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                    )
                    Text(
                        if (earned) "You can use the advanced tools until the timer runs out."
                        else "“${p.feature}” is an advanced feature. Watch ${if (need == 1) "one short ad" else "$need short ads"} to unlock all advanced tools for ${ads.unlockMinutes} minutes.",
                        textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    if (!earned && need > 1) {
                        Text("Progress: $watched of $need ads watched", fontWeight = FontWeight.SemiBold, color = Palette.Violet)
                    }
                    if (earned) {
                        Text(clock, fontSize = 40.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = Palette.Success)
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Unlocked.forEach { Text("✓  $it", style = MaterialTheme.typography.bodyMedium, color = if (earned) Palette.Success else MaterialTheme.colorScheme.onSurface) }
                    }
                    if (earned) {
                        GradientButton("Continue", onClick = { val go = p.onUnlocked; vm.dismissLock(); go() }, colors = listOf(Palette.Success, Color(0xFF16A34A)), modifier = Modifier.fillMaxWidth())
                    } else {
                        RewardedAction(
                            ads, label = if (need == 1) "WATCH AD & UNLOCK" else "WATCH AD ${minOf(watched + 1, need)} OF $need",
                            onReward = { if (vm.onRewardedAdFinished()) earned = true },
                            modifier = Modifier.fillMaxWidth(),
                        )
                        Text((if (need == 1) "One ad" else "$need ads") + " = ${ads.unlockMinutes} minutes of advanced tools. Coding and running scripts always stay free.",
                            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
                        Text("Not now", color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(6.dp).clickable { vm.dismissLock() })
                    }
                }
            }
        }
    }
}

/** A handful of slow, faint dots drifting upward; cheap enough to leave on. */
@Composable
private fun Particles(modifier: Modifier) {
    val t by rememberInfiniteTransition(label = "particles").animateFloat(0f, 1f, infiniteRepeatable(tween(5000)), label = "t")
    Canvas(modifier) {
        val colors = listOf(Palette.Cyan, Palette.Violet, Palette.Blue, Palette.Warning)
        for (i in 0 until 14) {
            val phase = (t + i / 14f) % 1f
            val x = size.width * ((i * 37 % 100) / 100f)
            val y = size.height * (1f - phase)
            drawCircle(colors[i % colors.size].copy(alpha = (1f - phase) * 0.55f), radius = 2.5f + (i % 3) * 1.5f, center = Offset(x, y))
        }
    }
}

/** Small pill showing the time left on a rewarded unlock; draws nothing when no unlock is running. */
@Composable
fun UnlockChip(vm: IdeViewModel) {
    val endsAt by vm.unlockEndsAt.collectAsState()
    if (endsAt <= SystemClock.elapsedRealtime()) return
    val (text, left) = rememberCountdown(vm)
    if (left <= 0L) return
    Text(
        "🔓 $text",
        style = MaterialTheme.typography.labelMedium,
        color = Palette.Success,
        modifier = Modifier.background(Palette.Success.copy(alpha = 0.14f), RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 5.dp),
    )
}
