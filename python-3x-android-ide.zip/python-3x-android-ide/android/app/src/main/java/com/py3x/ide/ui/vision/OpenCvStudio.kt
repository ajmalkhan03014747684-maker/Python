package com.py3x.ide.ui.vision

import com.py3x.ide.ui.components.FullScreen
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.py3x.ide.ui.components.GlowCard
import com.py3x.ide.ui.components.GradientButton
import com.py3x.ide.ui.components.PyMark
import com.py3x.ide.ui.components.ToolButton
import com.py3x.ide.ui.components.ToolTile
import com.py3x.ide.ui.theme.Palette
import androidx.compose.foundation.layout.Spacer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import com.py3x.ide.vm.IdeViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

private class Param(val name: String, val min: Int, val max: Int, val step: Int)
private class OpDef(val op: String, val label: String, val params: List<Param>, val defaults: Map<String, Int>)
private class Step(val def: OpDef) {
    val values = mutableStateOf(def.defaults)
}

@Composable
fun OpenCvStudioDialog(vm: IdeViewModel, onClose: () -> Unit) {
    FullScreen(onClose) {
        StudioScreen(vm, onClose)
    }
}

private fun parseOps(arr: JSONArray): List<OpDef> = (0 until arr.length()).map { i ->
    val o = arr.getJSONObject(i)
    val ps = o.getJSONArray("params")
    val params = (0 until ps.length()).map { j ->
        ps.getJSONObject(j).let { Param(it.getString("name"), it.getInt("min"), it.getInt("max"), it.getInt("step")) }
    }
    val defaults = (0 until ps.length()).associate { j -> ps.getJSONObject(j).let { it.getString("name") to it.getInt("default") } }
    OpDef(o.getString("op"), o.getString("label"), params, defaults)
}

/** Decodes a downsampled bitmap so big photos don't exhaust memory. */
internal fun decode(file: File, maxSide: Int = 1600): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(file.path, bounds)
    if (bounds.outWidth <= 0) return null
    var sample = 1
    while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
    return BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply { inSampleSize = sample })
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun StudioScreen(vm: IdeViewModel, onClose: () -> Unit) {
    val scope = rememberCoroutineScope()
    var ops by remember { mutableStateOf<List<OpDef>>(emptyList()) }
    val steps = remember { mutableStateListOf<Step>() }
    var sourceRel by remember { mutableStateOf<String?>(null) }
    var original by remember { mutableStateOf<ImageBitmap?>(null) }
    var result by remember { mutableStateOf<ImageBitmap?>(null) }
    var status by remember { mutableStateOf("Pick an image to start.") }
    var busy by remember { mutableStateOf(false) }
    var resultRel by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) { ops = parseOps(vm.visionOperations()) }

    var mode by remember { mutableIntStateOf(0) }            // 0 image, 1 camera, 2 video
    var videoUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var videoLengthMs by remember { mutableStateOf(0L) }
    var videoPos by remember { mutableFloatStateOf(0f) }
    var cameraTarget by remember { mutableStateOf<java.io.File?>(null) }

    fun setSource(rel: String) {
        scope.launch {
            sourceRel = rel
            result = null
            original = vm.projectFile(rel)?.let { f -> withContext(Dispatchers.IO) { decode(f)?.asImageBitmap() } }
            status = if (original == null) "That file could not be shown." else "Add steps below, then tap Apply."
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val file = cameraTarget
        if (ok && file != null) scope.launch {
            busy = true
            val (rel, err) = vm.visionAdoptPhoto(file)
            if (rel != null) setSource(rel) else status = err ?: "No photo was taken."
            busy = false
        } else status = "No photo was taken."
    }

    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            busy = true
            val len = vm.visionVideoLength(uri)
            if (len == null || len <= 0) {
                status = "That video could not be read."
            } else {
                videoUri = uri; videoLengthMs = len; videoPos = 0f
                val (rel, err) = vm.visionVideoFrame(uri, 0)
                if (rel != null) setSource(rel) else status = err ?: "Could not read a frame."
            }
            busy = false
        }
    }

    fun grabFrame() {
        val uri = videoUri ?: return
        scope.launch {
            busy = true
            val (rel, err) = vm.visionVideoFrame(uri, (videoPos * videoLengthMs).toLong())
            if (rel != null) setSource(rel) else status = err ?: "Could not read that frame."
            busy = false
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            busy = true
            val (rel, importError) = vm.visionImport(uri)
            if (importError != null) status = importError
            if (rel != null) {
                sourceRel = rel
                result = null
                original = vm.projectFile(rel)?.let { f -> withContext(Dispatchers.IO) { decode(f)?.asImageBitmap() } }
                status = if (original == null) "That file could not be shown." else "Add steps below, then tap Apply."
            }
            busy = false
        }
    }

    fun apply() {
        val rel = sourceRel ?: return
        val json = JSONArray().also { arr ->
            steps.forEach { s ->
                arr.put(JSONObject().put("op", s.def.op).put("params", JSONObject().also { p -> s.values.value.forEach { (k, v) -> p.put(k, v) } }))
            }
        }
        scope.launch {
            busy = true
            status = "Processing…"
            val (out, error) = vm.visionProcess(rel, json.toString(), "opencv_out/result.png")
            if (out != null) {
                resultRel = out.getString("out")
                result = vm.projectFile(out.getString("out"))?.let { f -> withContext(Dispatchers.IO) { decode(f)?.asImageBitmap() } }
                status = "Done: ${out.getInt("width")}×${out.getInt("height")} px, ${out.getInt("steps")} step(s). Tap Save result to keep it."
            } else {
                status = error ?: "Processing failed."
            }
            busy = false
        }
    }

    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri ->
        if (uri != null) scope.launch { status = vm.visionSave(resultRel ?: "opencv_out/result.png", uri) }
    }

    // One lazy list for the whole screen: everything scrolls, however many steps are added.
    LazyColumn(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                PyMark(34.dp)
                Text("OpenCV Studio", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f).padding(start = 10.dp))
                ToolButton("Close", onClose)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ToolButton("Image", onClick = { mode = 0 }, emphasized = mode == 0, modifier = Modifier.weight(1f))
                ToolButton("Camera", onClick = { mode = 1 }, emphasized = mode == 1, modifier = Modifier.weight(1f))
                ToolButton("Video", onClick = { mode = 2 }, emphasized = mode == 2, modifier = Modifier.weight(1f))
            }
        }
        item {
            Text(
                "Runs real OpenCV on your picture, on this device, inside the Python 3.x Packs app (Python 3.10). " +
                    "No project needed: pick a picture, add steps, tap Apply.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    when (mode) {
                        1 -> GradientButton(
                            "Take photo", {
                                val (file, uri) = vm.visionCameraTarget()
                                cameraTarget = file
                                cameraLauncher.launch(uri)
                            }, Modifier.weight(1f), enabled = !busy, glyph = "◉", description = "Take a photo with the camera app",
                        )
                        2 -> GradientButton("Pick video", { videoPicker.launch(arrayOf("video/*")) }, Modifier.weight(1f), enabled = !busy, glyph = "▶")
                        else -> GradientButton("Pick image", { picker.launch(arrayOf("image/*")) }, Modifier.weight(1f), enabled = !busy, glyph = "▣")
                    }
                    GradientButton(
                        "Apply", { apply() }, Modifier.weight(1f), enabled = !busy && sourceRel != null, glyph = "▶",
                        colors = listOf(Palette.Violet, Color(0xFF5B3FD6)), description = "Apply the steps to the image",
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GradientButton(
                        "Save result", { saver.launch("opencv-result.png") }, Modifier.weight(1f), enabled = !busy && result != null, glyph = "↓",
                        colors = listOf(Palette.Success, Color(0xFF16A34A)), description = "Save the result picture to a file you choose",
                    )
                    ToolButton("Clear steps", onClick = { steps.clear() }, enabled = steps.isNotEmpty(), modifier = Modifier.weight(1f))
                }
            }
        }
        item { Text(status, style = MaterialTheme.typography.labelMedium) }
        if (mode == 1) item {
            Text(
                "Opens your phone's camera app, then brings the photo back here. Nothing is recorded in the background.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (mode == 2) item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    "Works on one frame at a time: move the slider to choose a moment, then add steps and Apply. " +
                        "Processing a whole video is not built yet.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                if (videoUri != null) {
                    val sec = (videoPos * videoLengthMs / 1000f)
                    Text("Frame at %.1f s of %.1f s".format(sec, videoLengthMs / 1000f), style = MaterialTheme.typography.labelMedium)
                    Slider(
                        value = videoPos, onValueChange = { videoPos = it }, onValueChangeFinished = { grabFrame() },
                        enabled = !busy, modifier = Modifier.semantics { contentDescription = "Video position" },
                    )
                }
            }
        }
        original?.let { img -> item { Preview("Original", img) } }
        result?.let { img -> item { Preview("Result", img) } }
        item { HorizontalDivider() }
        item { Text("Add a step", style = MaterialTheme.typography.titleSmall) }
        item {
            val tints = listOf(Palette.Blue, Palette.Cyan, Palette.Violet)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ops.withIndex().chunked(3).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { (i, def) ->
                            ToolTile(def.label.take(1).uppercase(), def.label, Modifier.weight(1f), tint = tints[i % 3]) { if (steps.size < 20) steps.add(Step(def)) }
                        }
                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        }
        item { Text("Steps (run top to bottom)", style = MaterialTheme.typography.titleSmall) }
        if (steps.isEmpty()) item { Text("No steps yet. Tap an effect above.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        itemsIndexed(steps) { index, step ->
            GlowCard(Modifier.fillMaxWidth()) {
              Column(Modifier.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${index + 1}. ${step.def.label}", Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                    ToolButton("Remove", onClick = { steps.remove(step) }, description = "Remove step ${index + 1}")
                }
                step.def.params.forEach { p ->
                    val v = step.values.value[p.name] ?: p.min
                    Text("${p.name}: $v", style = MaterialTheme.typography.bodySmall)
                    Slider(
                        value = v.toFloat(),
                        onValueChange = { f ->
                            val snapped = p.min + ((f - p.min) / p.step).toInt() * p.step
                            step.values.value = step.values.value + (p.name to snapped.coerceIn(p.min, p.max))
                        },
                        valueRange = p.min.toFloat()..p.max.toFloat(),
                        modifier = Modifier.semantics { contentDescription = "${step.def.label} ${p.name}" },
                    )
                }
              }
            }
        }
    }
}

@Composable
private fun Preview(title: String, image: ImageBitmap) {
    GlowCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            Image(
                bitmap = image, contentDescription = "$title image",
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxWidth().heightIn(max = 260.dp),
            )
        }
    }
}
