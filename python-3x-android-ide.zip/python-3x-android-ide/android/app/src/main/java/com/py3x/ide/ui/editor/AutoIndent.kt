package com.py3x.ide.ui.editor

/**
 * Whitespace to insert after Enter. Kotlin mirror of `python/editor/ops.py::auto_indent`
 * (the Python version is the reference and is covered by tests/test_editor.py; the cases are
 * repeated in AutoIndentTest). It runs on every Enter, so it must not call into Python on
 * the UI thread.
 */
object AutoIndent {
    private val dedentWords = setOf("return", "break", "continue", "pass", "raise")

    fun after(lineBeforeCursor: String, useSpaces: Boolean, tabWidth: Int): String {
        val unit = if (useSpaces) " ".repeat(tabWidth) else "\t"
        val current = lineBeforeCursor.takeWhile { it == ' ' || it == '\t' }
        val code = stripComment(lineBeforeCursor).trimEnd()
        if (code.endsWith(":") || code.endsWith("(") || code.endsWith("[") || code.endsWith("{")) {
            return current + unit
        }
        val word = code.trim().substringBefore(' ').substringBefore('(')
        if (word in dedentWords && current.endsWith(unit)) return current.dropLast(unit.length)
        return current
    }

    private fun stripComment(line: String): String {
        var quote: Char? = null
        var i = 0
        while (i < line.length) {
            val ch = line[i]
            when {
                quote != null -> if (ch == '\\') i++ else if (ch == quote) quote = null
                ch == '\'' || ch == '"' -> quote = ch
                ch == '#' -> return line.substring(0, i)
            }
            i++
        }
        return line
    }
}
