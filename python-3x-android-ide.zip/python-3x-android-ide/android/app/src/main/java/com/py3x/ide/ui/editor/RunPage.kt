package com.py3x.ide.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import kotlinx.coroutines.delay
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.layout.size
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.unit.sp
import com.py3x.ide.ui.components.FullScreen
import com.py3x.ide.ui.components.GlowCard
import com.py3x.ide.ui.components.GradientButton
import com.py3x.ide.ui.components.ToolButton
import com.py3x.ide.ui.theme.Palette
import com.py3x.ide.vm.AutoFix
import com.py3x.ide.vm.IdeViewModel
import com.py3x.ide.vm.RunPhase
import com.py3x.ide.vm.TabState

/**
 * Full-screen page shown when a script runs: just the output, with STOP and DEBUG at the top.
 * If the script fails, the error helper appears at the top of this page (explanation, one-tap fix when one exists).
 * The helper runs on this phone and needs no API key.
 */
@Composable
fun RunPage(vm: IdeViewModel, tab: TabState, onGoToLine: (Int) -> Unit) {
    FullScreen(onDismissRequest = { vm.toggleOutput() }) {
        val run by vm.run.collectAsState()
        val dbg by vm.debug.collectAsState()
        val colors = MaterialTheme.colorScheme
        var fix by remember { mutableStateOf<AutoFix?>(null) }
        val err = run.error
        LaunchedEffect(err, run.phase) { fix = if (err != null && !run.phase.isActive) vm.autofixFor(tab, err) else null }
        val active = run.phase.isActive

        Column(Modifier.fillMaxSize().background(colors.background).imePadding()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                ToolButton("‹ Editor", onClick = { vm.toggleOutput() }, description = "Back to the editor")
                Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    ToolButton("■ STOP", onClick = { vm.stopRun() }, enabled = active, description = "Stop script")
                    ToolButton(
                        "DEBUG", onClick = { vm.gated("Debugger") { vm.startDebug() } },
                        enabled = !active && !dbg.active, description = "Debug the script with breakpoints",
                    )
                    ToolButton("↻ RUN", onClick = { vm.runCurrentFile() }, enabled = !active && !dbg.active, emphasized = true, description = "Run again")
                }
            }
            Row(Modifier.padding(horizontal = 12.dp, vertical = 2.dp)) { StatusChip(run) }

            // The error helper sits at the top, above the output.
            if (err != null && !active) {
                GlowCard(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), accent = colors.error) {
                    Column(Modifier.padding(12.dp).heightIn(max = 260.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("⚠ ${err.type}: ${err.message} (line ${err.line})", color = colors.error, style = MaterialTheme.typography.labelLarge)
                        fix?.let { f ->
                            Text(f.title, style = MaterialTheme.typography.titleSmall)
                            Text(f.explanation, style = MaterialTheme.typography.bodySmall)
                            f.steps.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall, color = colors.onSurfaceVariant) }
                            if (f.patchLine != null) {
                                Text(
                                    if (f.patchLine == 0) "Add at the top: ${f.patchNew}" else "Line ${f.patchLine} becomes: ${f.patchNew.trim()}",
                                    fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = Palette.Success,
                                )
                            }
                        }
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            fix?.takeIf { it.patchLine != null }?.let { f ->
                                ToolButton("Apply fix", onClick = { vm.applyFix(tab, f); vm.toggleOutput() }, emphasized = true, description = "Apply the suggested fix to the file")
                            }
                            fix?.takeIf { it.packs }?.let {
                                ToolButton("Run with PACKS", onClick = { vm.runWithPacks() }, description = "Run with the Packs app")
                            }
                            ToolButton("Go to line", onClick = { onGoToLine(err.line) })
                            ToolButton("Ask AI", onClick = { vm.openAi() }, description = "Ask the AI assistant")
                        }
                    }
                }
            }
            if (run.stuck) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("The script is blocked in native code and cannot be interrupted.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                    ToolButton("Restart runtime", onClick = { vm.forceRestartRuntime() })
                }
            }
            if (dbg.active || dbg.message != null) DebugPanel(vm, tab)

            val active2 = run.phase == RunPhase.RUNNING
            // Only scripts that read input get a cursor and keyboard: look for input() / stdin in the file being run.
            val wantsInput = remember(tab.rel) { tab.value.text.contains("input(") || tab.value.text.contains("stdin") }
            Console(vm, running = active2, wantsInput = wantsInput, modifier = Modifier.weight(1f))
        }
    }
}

private val AnsiPalette = intArrayOf(
    0, 0xFF4B5563.toInt(), 0xFFF87171.toInt(), 0xFF4ADE80.toInt(), 0xFFFACC15.toInt(), 0xFF60A5FA.toInt(), 0xFFC084FC.toInt(), 0xFF22D3EE.toInt(), 0xFFE5E7EB.toInt(),
    0xFF9CA3AF.toInt(), 0xFFFCA5A5.toInt(), 0xFF86EFAC.toInt(), 0xFFFDE047.toInt(), 0xFF93C5FD.toInt(), 0xFFD8B4FE.toInt(), 0xFF67E8F9.toInt(), 0xFFFFFFFF.toInt(),
)
private val ConsoleBg = Color(0xFF05070D)
private val ConsoleText = Color(0xFFE6EDF7)

private fun styleColor(style: Int): Color = when {
    style == 0 -> ConsoleText
    style == com.py3x.ide.vm.AnsiScreen.ERROR_STYLE -> Color(0xFFF87171)
    style and com.py3x.ide.vm.AnsiScreen.RGB_FLAG != 0 -> Color(0xFF000000.toInt() or (style and 0xFFFFFF))
    style in 1..16 -> Color(AnsiPalette[style])
    else -> ConsoleText
}

/**
 * The output area, drawn like a real console: dark, colours honoured, and drawing programs (cursor moves, clear screen)
 * redraw in place. When the script reads input, a blinking cursor sits at the end of the output and you type straight
 * there with the keyboard; Enter sends the line. There is no separate input box.
 */
@Composable
private fun Console(vm: IdeViewModel, running: Boolean, wantsInput: Boolean, modifier: Modifier) {
    val version by vm.screenVersion.collectAsState()
    val screen = vm.screen
    val scroll = rememberScrollState()
    val reduce = com.py3x.ide.ui.theme.LocalReduceMotion.current
    val keyboard = androidx.compose.ui.platform.LocalSoftwareKeyboardController.current
    val focus = remember { androidx.compose.ui.focus.FocusRequester() }
    var typed by remember { mutableStateOf(androidx.compose.ui.text.input.TextFieldValue("")) }
    var blink by remember { mutableStateOf(true) }
    val cursorActive = running && wantsInput

    LaunchedEffect(cursorActive) {
        if (cursorActive) {
            runCatching { focus.requestFocus() }
            keyboard?.show()
        }
        while (cursorActive && !reduce) { delay(530); blink = !blink }
        blink = true
    }

    fun submit(line: String) {
        typed = androidx.compose.ui.text.input.TextFieldValue("")
        vm.sendRunInput(line)
    }

    androidx.compose.foundation.layout.BoxWithConstraints(
        modifier.fillMaxWidth().background(ConsoleBg)
            .pointerInput(running) { detectTapGestures(onTap = { if (running) { runCatching { focus.requestFocus() }; keyboard?.show() } }) },
    ) {
        // Drawing programs (like an ASCII animation) set their own layout, so the font shrinks to fit their widest line.
        val fit = screen.drawing
        val fontSp = if (fit) ((maxWidth.value - 24f) / (maxOf(screen.maxCols, 30) * 0.602f)).coerceIn(5f, 14f) else 13f
        val text = remember(version, typed.text, blink, cursorActive) {
            buildAnnotatedString {
                val total = maxOf(screen.rows.size, screen.curRow + 1)
                for (r in 0 until total) {
                    val row = screen.rows.getOrNull(r)
                    val chars = row?.chars?.toString().orEmpty()
                    val styles = row?.styles
                    val atCursor = cursorActive && r == screen.curRow
                    val limit = if (atCursor) minOf(screen.curCol, chars.length) else chars.length
                    var i = 0
                    while (i < limit) {
                        val st = styles?.getOrNull(i) ?: 0
                        var j = i
                        while (j < limit && (styles?.getOrNull(j) ?: 0) == st) j++
                        withStyle(SpanStyle(color = styleColor(st))) { append(chars, i, j) }
                        i = j
                    }
                    if (atCursor) {
                        if (screen.curCol > chars.length) append(" ".repeat(screen.curCol - chars.length))
                        withStyle(SpanStyle(color = Color(0xFF93C5FD))) { append(typed.text) }
                        withStyle(SpanStyle(color = if (blink) Color(0xFFFFFFFF) else Color.Transparent)) { append("█") }
                    }
                    if (r < total - 1) append('\n')
                }
            }
        }
        LaunchedEffect(version, typed.text, scroll.maxValue) { scroll.scrollTo(scroll.maxValue) }
        androidx.compose.foundation.text.selection.SelectionContainer {
            Text(
                text = if (text.isEmpty()) AnnotatedString(if (running) "" else "No output.") else text,
                fontFamily = FontFamily.Monospace, fontSize = fontSp.sp, lineHeight = (fontSp * 1.3f).sp, color = ConsoleText,
                softWrap = !fit,
                modifier = Modifier.fillMaxSize().verticalScroll(scroll).padding(horizontal = 12.dp, vertical = 8.dp),
            )
        }
        if (cursorActive) {
            // Invisible field that only receives the keyboard; what you type is drawn at the cursor above.
            androidx.compose.foundation.text.BasicTextField(
                value = typed,
                onValueChange = { v ->
                    val nl = v.text.indexOf('\n')
                    if (nl >= 0) submit(v.text.substring(0, nl)) else typed = v
                },
                modifier = Modifier.size(1.dp).alpha(0f).focusRequester(focus).semantics { contentDescription = "Type input for the script" },
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                    autoCorrectEnabled = false, capitalization = androidx.compose.ui.text.input.KeyboardCapitalization.None,
                ),
            )
        }
    }
}
