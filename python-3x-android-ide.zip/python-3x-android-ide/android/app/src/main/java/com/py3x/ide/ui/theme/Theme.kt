package com.py3x.ide.ui.theme

import android.provider.Settings as AndroidSettings
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import com.py3x.ide.ui.editor.CodeColors
import com.py3x.ide.vm.Settings

val LocalCodeColors = staticCompositionLocalOf<CodeColors> { error("CodeColors not provided") }
val LocalReduceMotion = compositionLocalOf { false }

/** Brand palette: deep ink surfaces with an electric teal accent and a violet secondary. */
object Palette {
    val Ink = Color(0xFF060A14)
    val Panel = Color(0xFF0D1424)
    val Raised = Color(0xFF141E36)
    val Line = Color(0xFF22325C)
    val Blue = Color(0xFF2F80FF)
    val Violet = Color(0xFF7C5CFF)
    val Cyan = Color(0xFF22D3EE)
    val Success = Color(0xFF34D399)
    val Danger = Color(0xFFF87171)
    val Warning = Color(0xFFFBBF24)
}

private fun parseAccent(hex: String): Color =
    // "#22E3C4" was the old default; people who never changed it get the new blue.
    if (hex.equals("#22E3C4", ignoreCase = true)) Palette.Blue
    else runCatching { Color(android.graphics.Color.parseColor(hex)) }.getOrDefault(Palette.Blue)

private val darkCode = CodeColors(
    keyword = Color(0xFFC792EA), builtin = Color(0xFF82AAFF), string = Color(0xFFC3E88D),
    comment = Color(0xFF6B7A99), number = Color(0xFFF78C6C), decorator = Color(0xFFFFCB6B),
    definition = Palette.Cyan, self = Color(0xFFFF9CAC), error = Palette.Danger,
    bracketMatch = Color(0x5522D3EE),
)
private val lightCode = CodeColors(
    keyword = Color(0xFF7B3FC4), builtin = Color(0xFF1F5FBF), string = Color(0xFF3B7A1E),
    comment = Color(0xFF7A8499), number = Color(0xFFC2511F), decorator = Color(0xFF9A6A00),
    definition = Color(0xFF007A68), self = Color(0xFFB03A52), error = Color(0xFFC62840),
    bracketMatch = Color(0x4400A58E),
)

@Composable
fun Py3xTheme(settings: Settings, content: @Composable () -> Unit) {
    val dark = when (settings.theme) {
        "light" -> false
        "dark" -> true
        else -> isSystemInDarkTheme()
    }
    val accent = parseAccent(settings.accent)
    // On a light surface the accent is darkened so text and controls keep enough contrast.
    val primary = if (dark) accent else lerp(accent, Color.Black, 0.35f)
    val onPrimary = if (primary.luminance() > 0.45f) Color(0xFF04101F) else Color.White
    val scheme = if (dark) {
        darkColorScheme(
            primary = primary, onPrimary = onPrimary, secondary = Palette.Violet, tertiary = Palette.Cyan,
            background = Palette.Ink, onBackground = Color(0xFFE8EEFF),
            surface = Palette.Panel, onSurface = Color(0xFFE8EEFF),
            surfaceVariant = Palette.Raised, onSurfaceVariant = Color(0xFF9FB0D6),
            outline = Palette.Line, error = Palette.Danger,
        )
    } else {
        lightColorScheme(
            primary = primary, onPrimary = onPrimary, secondary = Color(0xFF6A5BE0),
            background = Color(0xFFF6F8FC), onBackground = Color(0xFF12172B),
            surface = Color.White, onSurface = Color(0xFF12172B),
            surfaceVariant = Color(0xFFE8ECF6), onSurfaceVariant = Color(0xFF4A5470),
            outline = Color(0xFFC5CCDD), error = Color(0xFFC62840),
        )
    }
    val context = LocalContext.current
    val systemAnimationsOff = remember {
        AndroidSettings.Global.getFloat(context.contentResolver, AndroidSettings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
    }
    CompositionLocalProvider(
        LocalCodeColors provides (if (dark) darkCode else lightCode),
        LocalReduceMotion provides (settings.reduceMotion || systemAnimationsOff),
    ) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

@Composable
@ReadOnlyComposable
fun codeColors(): CodeColors = LocalCodeColors.current
