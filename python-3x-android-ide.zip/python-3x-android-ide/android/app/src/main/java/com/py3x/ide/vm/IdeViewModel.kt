package com.py3x.ide.vm

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.py3x.ide.bridge.BridgeException
import com.py3x.ide.bridge.DebugListener
import com.py3x.ide.bridge.PythonBridge
import com.py3x.ide.bridge.RunListener
import com.py3x.ide.bridge.TerminalListener
import com.py3x.ide.ui.editor.AutoIndent
import com.py3x.ide.packs.PacksClient
import com.py3x.ide.security.SecureStore
import com.py3x.ide.packs.PacksException
import com.py3x.ide.packs.PacksInfo
import com.py3x.ide.packs.PacksInstaller
import com.py3x.ide.ui.editor.Diagnostic
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import android.os.ParcelFileDescriptor
import java.io.File
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicBoolean

data class OutChunk(val stream: String, val text: String)

class TerminalUi(val id: Int, private val scope: kotlinx.coroutines.CoroutineScope) {
    var output by mutableStateOf("")
    var prompt by mutableStateOf("~$ ")
    var busy by mutableStateOf(false)
    val history = mutableListOf<String>()
    var historyIndex = -1

    private val pending = StringBuilder()
    private val scheduled = AtomicBoolean(false)

    /** Thread-safe. Output is batched to ~25 updates/second so floods don't stall the UI. */
    fun append(text: String) {
        synchronized(pending) { pending.append(text) }
        if (scheduled.compareAndSet(false, true)) {
            scope.launch {
                delay(40)
                scheduled.set(false)
                val chunk = synchronized(pending) { pending.toString().also { pending.setLength(0) } }
                output = (output + chunk).takeLast(MAX_CHARS)
            }
        }
    }

    companion object { const val MAX_CHARS = 200_000 }
}

enum class FileClipMode { COPY, CUT }
data class FileClip(val projectId: Int, val rel: String, val mode: FileClipMode)

class IdeViewModel(app: Application) : AndroidViewModel(app) {

    // ------------------------------------------------------------- start-up
    private lateinit var bridge: PythonBridge
    private val _ready = MutableStateFlow(false)
    val ready: StateFlow<Boolean> = _ready.asStateFlow()
    private val _stage = MutableStateFlow("Initializing Runtime...")
    val stage: StateFlow<String> = _stage.asStateFlow()
    private val _fatal = MutableStateFlow<String?>(null)
    val fatal: StateFlow<String?> = _fatal.asStateFlow()

    private val _settings = MutableStateFlow(Settings())
    val settings: StateFlow<Settings> = _settings.asStateFlow()
    private val _runtimeInfo = MutableStateFlow<RuntimeInfo?>(null)
    val runtimeInfo: StateFlow<RuntimeInfo?> = _runtimeInfo.asStateFlow()

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    init {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                bridge = PythonBridge.start(getApplication())
                _stage.value = "Loading Editor..."
                loadSettings()
                loadRuntimeInfo()
                _stage.value = "Loading Tools..."
                refreshProjects()
                refreshRecents()
                scanRecovery()
                _packsInfo.value = PacksInfo(installed = packs.isInstalled()) // the package list is fetched when needed
                runCatching { loadAdsNow() }
                runCatching { startBackend() }
                _ready.value = true
                startPeriodicAutosave()
            } catch (t: Throwable) {
                _fatal.value = "Could not start the Python runtime: ${t.message ?: t.javaClass.simpleName}"
            }
        }
    }

    private fun say(message: String) {
        _messages.tryEmit(message)
    }

    /** Lets screens show a snackbar through the same channel as background errors. */
    fun notify(message: String) = say(message)

    /** Run [block] on the IO dispatcher and report bridge errors as snackbars. */
    private fun io(block: suspend () -> Unit): Job = viewModelScope.launch(Dispatchers.IO) {
        try {
            block()
        } catch (e: BridgeException) {
            say(e.message ?: "Something went wrong")
        } catch (e: Exception) {
            say("Unexpected error: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    // ------------------------------------------------------------- settings
    private fun loadSettings() {
        _settings.value = Settings.from(bridge.obj("get_settings"))
    }

    private fun loadRuntimeInfo() {
        val o = bridge.obj("runtime_info")
        _runtimeInfo.value = RuntimeInfo(
            o.getString("python"), o.getString("backend"), o.getBoolean("can_hard_stop"), o.getString("notes"),
        )
    }

    fun setSetting(key: String, valueJson: String) = io {
        bridge.call("set_setting", key, valueJson)
        loadSettings()
    }

    // ------------------------------------------------------------- projects
    private val _projects = MutableStateFlow<List<Project>>(emptyList())
    val projects: StateFlow<List<Project>> = _projects.asStateFlow()
    private val _recents = MutableStateFlow<List<RecentFile>>(emptyList())
    val recents: StateFlow<List<RecentFile>> = _recents.asStateFlow()
    private val _deletedProjects = MutableStateFlow<List<Project>>(emptyList())
    val deletedProjects: StateFlow<List<Project>> = _deletedProjects.asStateFlow()
    private val _current = MutableStateFlow<Project?>(null)
    val currentProject: StateFlow<Project?> = _current.asStateFlow()

    private fun refreshProjects() {
        val arr = bridge.arr("list_projects")
        _projects.value = (0 until arr.length()).map { Project.from(arr.getJSONObject(it)) }
        _current.value?.let { cur -> _current.value = _projects.value.firstOrNull { it.id == cur.id } }
    }

    private fun refreshRecents() {
        val arr = bridge.arr("recent_files", 8)
        _recents.value = (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            RecentFile(o.getInt("project_id"), o.getString("project_name"), o.getString("rel"))
        }
    }

    fun loadDeletedProjects() = io {
        val arr = bridge.arr("list_deleted_projects")
        _deletedProjects.value = (0 until arr.length()).map { Project.from(arr.getJSONObject(it)) }
    }

    fun createProject(name: String, thenOpenMain: Boolean = true) = io {
        val p = Project.from(bridge.obj("create_project", name))
        refreshProjects()
        selectProjectInternal(p)
        if (thenOpenMain) openFileInternal(p.id, p.mainFile)
    }

    fun selectProject(p: Project) = io { selectProjectInternal(p) }

    private fun selectProjectInternal(p: Project) {
        _current.value = p
        expanded.value = emptySet()
        treeCache.value = emptyMap()
        searchResults.value = emptyList()
        favorites.value = bridge.arr("favorites", p.id).let { a -> (0 until a.length()).map { a.getString(it) }.toSet() }
        loadDir("")
    }

    fun renameProject(p: Project, name: String) = io {
        bridge.call("rename_project", p.id, name)
        refreshProjects()
    }

    fun deleteProject(p: Project) = io {
        tabs.filter { it.projectId == p.id }.forEach { t -> viewModelScope.launch { tabs.remove(t) } }
        bridge.call("delete_project", p.id)
        if (_current.value?.id == p.id) _current.value = null
        refreshProjects()
        refreshRecents()
        say("Moved \"${p.name}\" to Recently Deleted")
    }

    fun restoreProject(p: Project) = io {
        bridge.call("restore_project", p.id)
        refreshProjects()
        loadDeletedProjectsNow()
    }

    private fun loadDeletedProjectsNow() {
        val arr = bridge.arr("list_deleted_projects")
        _deletedProjects.value = (0 until arr.length()).map { Project.from(arr.getJSONObject(it)) }
    }

    fun purgeProject(p: Project) = io {
        bridge.call("purge_project", p.id)
        loadDeletedProjectsNow()
    }

    fun duplicateProject(p: Project) = io {
        bridge.call("duplicate_project", p.id)
        refreshProjects()
    }

    fun setMainFile(rel: String) = io {
        val p = _current.value ?: return@io
        bridge.call("set_main_file", p.id, rel)
        refreshProjects()
        say("Main file is now $rel")
    }

    fun importZip(uri: Uri) = io {
        val tmp = File(getApplication<Application>().cacheDir, "import-${System.nanoTime()}.zip")
        try {
            getApplication<Application>().contentResolver.openInputStream(uri)?.use { input ->
                tmp.outputStream().use { input.copyTo(it) }
            } ?: throw BridgeException("Could not read that file.")
            val name = displayName(uri)?.removeSuffix(".zip")?.takeIf { it.isNotBlank() } ?: "Imported project"
            val p = Project.from(bridge.obj("import_project", tmp.absolutePath, name))
            refreshProjects()
            say("Imported \"${p.name}\"")
        } finally {
            tmp.delete()
        }
    }

    private fun displayName(uri: Uri): String? =
        getApplication<Application>().contentResolver
            .query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }

    fun exportProject(p: Project, uri: Uri) = io {
        val tmp = File(getApplication<Application>().cacheDir, "export-${System.nanoTime()}.zip")
        try {
            bridge.call("export_project", p.id, tmp.absolutePath)
            getApplication<Application>().contentResolver.openOutputStream(uri)?.use { out ->
                tmp.inputStream().use { it.copyTo(out) }
            } ?: throw BridgeException("Could not write to that location.")
            say("Exported \"${p.name}\"")
        } finally {
            tmp.delete()
        }
    }

    // ----------------------------------------------------------- file tree
    val treeCache = MutableStateFlow<Map<String, List<FileEntry>>>(emptyMap())
    val expanded = MutableStateFlow<Set<String>>(emptySet())
    val favorites = MutableStateFlow<Set<String>>(emptySet())
    val sort = MutableStateFlow("name")
    val searchResults = MutableStateFlow<List<Pair<String, Int>>>(emptyList())
    val fileClip = MutableStateFlow<FileClip?>(null)
    private val _trash = MutableStateFlow<List<TrashItem>>(emptyList())
    val trash: StateFlow<List<TrashItem>> = _trash.asStateFlow()

    private fun loadDir(rel: String) {
        val p = _current.value ?: return
        val arr = bridge.arr("list_dir", p.id, rel, sort.value)
        val entries = (0 until arr.length()).map { FileEntry.from(arr.getJSONObject(it)) }
        treeCache.update { it + (rel to entries) }
    }

    fun refreshTree() = io {
        val keys = setOf("") + expanded.value
        keys.forEach { runCatching { loadDir(it) } }
    }

    fun toggleFolder(rel: String) = io {
        if (rel in expanded.value) {
            expanded.update { it - rel }
        } else {
            loadDir(rel)
            expanded.update { it + rel }
        }
    }

    fun setSort(value: String) {
        sort.value = value
        refreshTree()
    }

    fun search(query: String, inContent: Boolean) = io {
        val p = _current.value ?: return@io
        if (query.isBlank()) { searchResults.value = emptyList(); return@io }
        val arr = bridge.arr("search_files", p.id, query, inContent)
        searchResults.value = (0 until arr.length()).map {
            val o = arr.getJSONObject(it); o.getString("rel") to o.getInt("line")
        }
    }

    fun createFile(parentRel: String, name: String) = io {
        val p = _current.value ?: return@io
        val rel = if (parentRel.isEmpty()) name else "$parentRel/$name"
        bridge.call("create_file", p.id, rel)
        loadDir(parentRel)
        openFileInternal(p.id, rel)
    }

    fun createFolder(parentRel: String, name: String) = io {
        val p = _current.value ?: return@io
        bridge.call("create_folder", p.id, if (parentRel.isEmpty()) name else "$parentRel/$name")
        loadDir(parentRel)
        expanded.update { it + parentRel }
    }

    fun renameEntry(entry: FileEntry, newName: String) = io {
        val p = _current.value ?: return@io
        pushDrafts() // unsaved edits travel with the file (Python moves drafts on rename)
        val wasOpen = tabs.any { it.projectId == p.id && it.rel == entry.rel }
        val res = bridge.obj("rename", p.id, entry.rel, newName)
        closeTabsMatching(p.id, entry.rel)
        refreshTree()
        refreshProjects()
        if (wasOpen && !entry.isDir) openFileInternal(p.id, res.getString("rel"))
    }

    fun deleteEntry(entry: FileEntry) = io {
        val p = _current.value ?: return@io
        closeTabsMatching(p.id, entry.rel)
        bridge.call("delete", p.id, entry.rel) // unsaved drafts move to version history
        refreshTree()
        refreshRecents()
        say("Deleted ${entry.name} (see Recently Deleted to undo)")
    }

    fun loadTrash() = io {
        val p = _current.value ?: return@io
        val arr = bridge.arr("list_trash", p.id)
        _trash.value = (0 until arr.length()).map {
            val o = arr.getJSONObject(it); TrashItem(o.getInt("id"), o.getString("original_rel"), o.getBoolean("is_dir"))
        }
    }

    fun restoreTrash(item: TrashItem) = io {
        val p = _current.value ?: return@io
        bridge.call("restore_trash", p.id, item.id)
        refreshTree()
        val arr = bridge.arr("list_trash", p.id)
        _trash.value = (0 until arr.length()).map {
            val o = arr.getJSONObject(it); TrashItem(o.getInt("id"), o.getString("original_rel"), o.getBoolean("is_dir"))
        }
    }

    fun toggleFavorite(entry: FileEntry) = io {
        val p = _current.value ?: return@io
        val now = bridge.bool("toggle_favorite", p.id, entry.rel)
        favorites.update { if (now) it + entry.rel else it - entry.rel }
    }

    fun clip(entry: FileEntry, mode: FileClipMode) {
        val p = _current.value ?: return
        fileClip.value = FileClip(p.id, entry.rel, mode)
        say(if (mode == FileClipMode.COPY) "Copied ${entry.name}" else "Cut ${entry.name}")
    }

    fun paste(destDirRel: String) = io {
        val p = _current.value ?: return@io
        val clip = fileClip.value ?: return@io
        if (clip.projectId != p.id) throw BridgeException("Paste into the same project it came from.")
        if (clip.mode == FileClipMode.COPY) bridge.call("copy", p.id, clip.rel, destDirRel)
        else { bridge.call("move", p.id, clip.rel, destDirRel); fileClip.value = null }
        refreshTree()
    }

    private fun closeTabsMatching(projectId: Int, rel: String) {
        viewModelScope.launch {
            tabs.removeAll { it.projectId == projectId && (it.rel == rel || it.rel.startsWith("$rel/")) }
            activeTab = activeTab.coerceIn(0, maxOf(0, tabs.size - 1))
        }
    }

    // ------------------------------------------------------------- editor
    val tabs = mutableStateListOf<TabState>()
    var activeTab by mutableIntStateOf(0)
    val currentTab: TabState? get() = tabs.getOrNull(activeTab)
    private val _saveIndicator = MutableStateFlow(SaveIndicator.IDLE)
    val saveIndicator: StateFlow<SaveIndicator> = _saveIndicator.asStateFlow()
    private val _suggestions = MutableStateFlow<Pair<String, List<Pair<String, String>>>>("" to emptyList())
    val suggestions: StateFlow<Pair<String, List<Pair<String, String>>>> = _suggestions.asStateFlow()
    private val _bracket = MutableStateFlow<Pair<Int, Int>?>(null)
    val bracket: StateFlow<Pair<Int, Int>?> = _bracket.asStateFlow()
    var pendingClose by mutableStateOf<TabState?>(null)

    fun openFile(projectId: Int, rel: String) = io { openFileInternal(projectId, rel) }

    /** Image files open in a preview instead of the text editor. */
    private val _imagePreview = MutableStateFlow<Pair<String, File>?>(null)
    val imagePreview: StateFlow<Pair<String, File>?> = _imagePreview.asStateFlow()
    fun closeImagePreview() { _imagePreview.value = null }

    private suspend fun openFileInternal(projectId: Int, rel: String) {
        if (rel.substringAfterLast('.', "").lowercase() in setOf("png", "jpg", "jpeg", "bmp", "webp", "gif")) {
            _imagePreview.value = rel to File(bridge.str("vision_project_path", projectId), rel)
            return
        }
        val existing = tabs.indexOfFirst { it.projectId == projectId && it.rel == rel }
        if (existing >= 0) {
            withContext(Dispatchers.Main) { activeTab = existing }
            return
        }
        val o = bridge.obj("open_file", projectId, rel)
        val disk = o.getString("content")
        val draft = if (o.isNull("draft")) null else o.getString("draft")
        val tab = TabState(projectId, rel, draft ?: disk, o.getString("hash"))
        tab.savedText = disk
        refreshRecents()
        withContext(Dispatchers.Main) {
            tabs.add(tab)
            activeTab = tabs.lastIndex
            if (draft != null) say("Restored unsaved changes in ${tab.title}")
        }
        scheduleDiagnostics(tab)
    }

    fun selectTab(i: Int) { activeTab = i.coerceIn(0, maxOf(0, tabs.lastIndex)); _suggestions.value = "" to emptyList(); _bracket.value = null }

    fun requestCloseTab(tab: TabState) {
        if (tab.isDirty) pendingClose = tab else closeTab(tab)
    }

    fun closeTab(tab: TabState) {
        pendingClose = null
        val i = tabs.indexOf(tab)
        if (i < 0) return
        tabs.removeAt(i)
        activeTab = when {
            tabs.isEmpty() -> 0
            i <= activeTab -> (activeTab - 1).coerceAtLeast(0)
            else -> activeTab
        }
    }

    fun saveAndClose(tab: TabState) = io {
        saveTabInternal(tab)
        withContext(Dispatchers.Main) { closeTab(tab) }
    }

    fun discardAndClose(tab: TabState) = io {
        runCatching { bridge.call("recovery_discard", tab.projectId, tab.rel) }
        withContext(Dispatchers.Main) { closeTab(tab) }
    }

    /** Applies an edit coming from the text field, handling undo history, auto-indent and autosave. */
    fun onEdit(tab: TabState, new: TextFieldValue) {
        val old = tab.value
        val s = _settings.value
        var result = new
        val typedChar = new.text.length == old.text.length + 1 && new.selection.collapsed && old.selection.collapsed
        if (s.autoIndent && typedChar && new.selection.start > 0 && new.text[new.selection.start - 1] == '\n') {
            val cursor = new.selection.start
            val lineStart = new.text.lastIndexOf('\n', cursor - 2).let { if (it == -1) 0 else it + 1 }
            val indent = AutoIndent.after(new.text.substring(lineStart, cursor - 1), s.useSpaces, s.tabWidth)
            if (indent.isNotEmpty()) {
                val text = new.text.substring(0, cursor) + indent + new.text.substring(cursor)
                result = TextFieldValue(text, TextRange(cursor + indent.length))
            }
        }
        if (result.text != old.text) {
            tab.undo.record(old, coalescible = typedChar, nowMs = System.currentTimeMillis())
            tab.value = result
            onTextChanged(tab)
        } else {
            tab.value = result // selection-only change
        }
        requestSuggestions(tab)
    }

    /** Replace the whole value as one undoable step (toolbar operations, replace, completion). */
    fun applyEdit(tab: TabState, new: TextFieldValue) {
        tab.undo.record(tab.value, coalescible = false, nowMs = System.currentTimeMillis())
        tab.value = new
        onTextChanged(tab)
    }

    fun undo() { currentTab?.let { t -> t.undo.undo(t.value)?.let { t.value = it; onTextChanged(t) } } }
    fun redo() { currentTab?.let { t -> t.undo.redo(t.value)?.let { t.value = it; onTextChanged(t) } } }

    private var autosaveJob: Job? = null
    private var diagJobs = HashMap<String, Job>()

    private fun onTextChanged(tab: TabState) {
        _saveIndicator.value = SaveIndicator.IDLE
        autosaveJob?.cancel()
        autosaveJob = viewModelScope.launch(Dispatchers.IO) {
            delay(_settings.value.autosaveDebounceMs.toLong())
            pushDrafts()
        }
        scheduleDiagnostics(tab)
    }

    private fun scheduleDiagnostics(tab: TabState) {
        if (!tab.rel.endsWith(".py") && !tab.rel.endsWith(".pyw")) return
        diagJobs[tab.key]?.cancel()
        diagJobs[tab.key] = viewModelScope.launch(Dispatchers.IO) {
            delay(450)
            val text = tab.value.text
            val arr = runCatching { bridge.arr("diagnostics", text) }.getOrNull() ?: return@launch
            val list = (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Diagnostic(o.getInt("line"), o.getInt("col"), o.getInt("end_line"), o.getInt("end_col"), o.getString("message"))
            }
            if (tab.value.text == text) tab.diagnostics = list // ignore stale results
        }
    }

    private var suggestJob: Job? = null
    private var bracketJob: Job? = null

    private fun requestSuggestions(tab: TabState) {
        val v = tab.value
        suggestJob?.cancel()
        bracketJob?.cancel()
        if (!v.selection.collapsed) { _suggestions.value = "" to emptyList(); _bracket.value = null; return }
        val text = v.text
        val cursor = v.selection.start
        if (_settings.value.autocomplete) {
            suggestJob = viewModelScope.launch(Dispatchers.IO) {
                delay(150)
                val o = runCatching { bridge.obj("complete", text, cursor) }.getOrNull() ?: return@launch
                val items = o.getJSONArray("items")
                val list = (0 until items.length()).map { items.getJSONObject(it).let { i -> i.getString("label") to i.getString("insert") } }
                if (tab === currentTab && tab.value.text == text) _suggestions.value = o.getString("prefix") to list
            }
        } else _suggestions.value = "" to emptyList()
        bracketJob = viewModelScope.launch(Dispatchers.IO) {
            delay(120)
            val r = runCatching { bridge.call("match_bracket", text, cursor) }.getOrNull()
            _bracket.value = (r as? JSONArray)?.let { it.getInt(0) to it.getInt(1) }
        }
    }

    fun acceptSuggestion(tab: TabState, prefix: String, insert: String) {
        val v = tab.value
        val end = v.selection.start
        val start = (end - prefix.length).coerceAtLeast(0)
        val text = v.text.substring(0, start) + insert + v.text.substring(end)
        applyEdit(tab, TextFieldValue(text, TextRange(start + insert.length)))
        _suggestions.value = "" to emptyList()
    }

    /** Toolbar operations implemented in Python (`editor/ops.py`): comment, indent, outdent, duplicate, delete. */
    fun editOp(tab: TabState, name: String) = io {
        val s = _settings.value
        val v = tab.value
        val opts = JSONObject().put("use_spaces", s.useSpaces).put("tab_width", s.tabWidth).toString()
        val o = bridge.obj("edit_op", name, v.text, v.selection.min, v.selection.max, opts)
        if (tab.value.text != v.text) return@io // user kept typing; drop the stale result
        val result = TextFieldValue(o.getString("text"), TextRange(o.getInt("start"), o.getInt("end")))
        withContext(Dispatchers.Main) { applyEdit(tab, result) }
    }

    // ---------------------------------------------------------- find / replace
    data class FindOptions(val caseSensitive: Boolean = false, val regex: Boolean = false, val wholeWord: Boolean = false) {
        fun json(): String = JSONObject().put("case_sensitive", caseSensitive).put("regex", regex).put("whole_word", wholeWord).toString()
    }

    val findCount = MutableStateFlow<Int?>(null)

    fun countMatches(tab: TabState, query: String, o: FindOptions) = io {
        if (query.isEmpty()) { findCount.value = null; return@io }
        findCount.value = bridge.arr("find_all", tab.value.text, query, o.json()).length()
    }

    fun findNext(tab: TabState, query: String, o: FindOptions, forward: Boolean) = io {
        if (query.isEmpty()) return@io
        val v = tab.value
        val from = if (forward) v.selection.max else v.selection.min
        val r = bridge.call("find_next", v.text, query, from, forward, o.json()) as? JSONArray
        if (r == null) { say("No matches"); return@io }
        withContext(Dispatchers.Main) { tab.value = tab.value.copy(selection = TextRange(r.getInt(0), r.getInt(1))) }
    }

    fun replaceNext(tab: TabState, query: String, with: String, o: FindOptions) = io {
        if (query.isEmpty()) return@io
        val v = tab.value
        val r = bridge.obj("replace_next", v.text, query, with, v.selection.min, o.json())
        if (!r.getBoolean("replaced")) { say("No matches"); return@io }
        val p = r.getInt("pos")
        withContext(Dispatchers.Main) { applyEdit(tab, TextFieldValue(r.getString("text"), TextRange(p))) }
    }

    fun replaceAll(tab: TabState, query: String, with: String, o: FindOptions) = io {
        if (query.isEmpty()) return@io
        val r = bridge.obj("replace_all", tab.value.text, query, with, o.json())
        val n = r.getInt("count")
        if (n == 0) { say("No matches"); return@io }
        withContext(Dispatchers.Main) {
            applyEdit(tab, TextFieldValue(r.getString("text"), TextRange(minOf(tab.value.selection.start, r.getString("text").length))))
        }
        say("Replaced $n")
    }

    fun gotoLine(tab: TabState, line: Int) = io {
        val offset = bridge.int("goto_line", tab.value.text, line)
        withContext(Dispatchers.Main) { tab.value = tab.value.copy(selection = TextRange(offset)) }
    }

    // ---------------------------------------------------------------- autosave
    /** Store drafts of all modified tabs (never touches the files on disk). */
    fun pushDrafts() {
        val dirty = tabs.filter { it.isDirty }
        if (dirty.isEmpty()) return
        _saveIndicator.value = SaveIndicator.SAVING
        val arr = JSONArray()
        dirty.forEach {
            arr.put(JSONObject().put("project_id", it.projectId).put("rel", it.rel).put("content", it.value.text).put("base_hash", it.baseHash))
        }
        try {
            bridge.call("update_drafts", arr.toString())
            _saveIndicator.value = SaveIndicator.DRAFT_SAVED
        } catch (e: Exception) {
            say("Autosave failed: ${e.message}")
            _saveIndicator.value = SaveIndicator.IDLE
        }
    }

    /** Called from Activity.onStop so nothing typed in the last moments is lost. */
    fun flushForBackground() {
        if (!_ready.value) return
        runBlocking(Dispatchers.IO) { pushDrafts() }
    }

    /** Called on a deliberate exit (finishing, not rotation) so the next launch is not reported as a crash. */
    fun cleanShutdown() {
        if (!_ready.value) return
        runBlocking(Dispatchers.IO) { pushDrafts(); bridge.shutdown() }
    }

    private fun startPeriodicAutosave() {
        viewModelScope.launch(Dispatchers.IO) {
            while (true) {
                delay(30_000)
                if (tabs.any { it.isDirty }) pushDrafts()
            }
        }
    }

    fun saveActive() { currentTab?.let { t -> io { saveTabInternal(t) } } }

    private fun saveTabInternal(tab: TabState) {
        _saveIndicator.value = SaveIndicator.SAVING
        val text = tab.value.text
        val r = bridge.obj("save_file", tab.projectId, tab.rel, text)
        tab.savedText = text
        tab.baseHash = r.getString("hash")
        _saveIndicator.value = SaveIndicator.SAVED
        viewModelScope.launch(Dispatchers.IO) { refreshProjects() }
    }

    // --------------------------------------------------------------- recovery
    private val _recovery = MutableStateFlow<List<RecoveryItem>>(emptyList())
    val recovery: StateFlow<List<RecoveryItem>> = _recovery.asStateFlow()
    val recoveryCrashed = MutableStateFlow(false)
    val recoveryDiff = MutableStateFlow<String?>(null)

    private fun scanRecovery() {
        val o = bridge.obj("recovery_scan")
        recoveryCrashed.value = o.getBoolean("crashed")
        val items = o.getJSONArray("items")
        _recovery.value = (0 until items.length()).map {
            val i = items.getJSONObject(it)
            RecoveryItem(i.getInt("project_id"), i.getString("project_name"), i.getString("rel"))
        }
    }

    fun restoreRecovery(item: RecoveryItem) = io {
        bridge.call("recovery_restore", item.projectId, item.rel)
        _recovery.update { it - item }
        refreshProjects()
        openFileInternal(item.projectId, item.rel)
    }

    fun discardRecovery(item: RecoveryItem) = io {
        bridge.call("recovery_discard", item.projectId, item.rel)
        _recovery.update { it - item }
        say("Discarded. The text is kept in version history.")
    }

    fun viewRecoveryDiff(item: RecoveryItem) = io {
        recoveryDiff.value = bridge.str("recovery_diff", item.projectId, item.rel)
    }

    fun dismissRecovery() { _recovery.value = emptyList() } // drafts stay stored; nothing is deleted

    // -------------------------------------------------------------------- run
    private val _run = MutableStateFlow(RunStatus())
    val run: StateFlow<RunStatus> = _run.asStateFlow()
    private val _output = MutableStateFlow<List<OutChunk>>(emptyList())
    val output: StateFlow<List<OutChunk>> = _output.asStateFlow()
    val outputVisible = MutableStateFlow(false)
    /** What the Run page shows: the output drawn on a small terminal screen (cursor moves and colours are honoured). */
    val screen = AnsiScreen()
    private val _screenVersion = MutableStateFlow(0)
    val screenVersion: StateFlow<Int> = _screenVersion.asStateFlow()
    private val pendingOut = ConcurrentLinkedQueue<OutChunk>()
    private val flushScheduled = AtomicBoolean(false)

    private fun appendOut(stream: String, text: String) {
        pendingOut.add(OutChunk(stream, text))
        if (flushScheduled.compareAndSet(false, true)) {
            viewModelScope.launch {
                delay(40)
                flushScheduled.set(false)
                val drained = ArrayList<OutChunk>()
                while (true) drained.add(pendingOut.poll() ?: break)
                if (drained.isNotEmpty()) {
                    _output.update { trimOutput(it + drained) }
                    drained.forEach { screen.feed(it.text, it.stream == "stderr") }
                    _screenVersion.value = _screenVersion.value + 1
                }
            }
        }
    }

    private fun trimOutput(list: List<OutChunk>): List<OutChunk> {
        var total = list.sumOf { it.text.length }
        var start = 0
        while (total > MAX_OUTPUT_CHARS && start < list.size - 1) { total -= list[start].text.length; start++ }
        return if (start == 0) list else list.drop(start)
    }

    private fun newListener() = RunListener(
        output = { stream, text -> appendOut(stream, text) },
        state = { s -> _run.update { it.copy(phase = RunPhase.from(s)) } },
        finish = { r ->
            val err = r.optJSONObject("error")?.let {
                RunError(it.getInt("line"), it.getString("error_type"), it.getString("message"), it.getString("file"))
            }
            _run.value = RunStatus(
                phase = RunPhase.from(r.getString("state")),
                exitCode = if (r.isNull("exit_code")) null else r.getInt("exit_code"),
                durationSec = r.getDouble("duration"),
                error = err,
                stuck = r.getBoolean("stuck"),
                backend = r.getString("backend"),
            )
        },
    )

    private fun beginRun() {
        _output.value = emptyList()
        screen.reset(); _screenVersion.value = _screenVersion.value + 1
        pendingOut.clear()
        outputVisible.value = true
        _run.value = RunStatus(phase = RunPhase.PREPARING)
    }

    /** Run the active file. Modified tabs are stored as drafts first; Python commits them before executing. */
    fun runCurrentFile() { currentTab?.let { t -> startRun { id -> bridge.obj("run_file", t.projectId, t.rel, id) } } }

    fun runProject(project: Project) = startRun { id -> bridge.obj("run_project", project.id, id) }

    fun runSelection(tab: TabState) {
        val v = tab.value
        val code = if (v.selection.collapsed) {
            val s = v.text.lastIndexOf('\n', v.selection.start - 1) + 1
            val e = v.text.indexOf('\n', v.selection.start).let { if (it == -1) v.text.length else it }
            v.text.substring(s, e)
        } else v.text.substring(v.selection.min, v.selection.max)
        startRun { id -> bridge.obj("run_code", tab.projectId, code, id) }
    }

    private fun startRun(call: (RunListener) -> JSONObject) = io {
        if (_run.value.phase.isActive) throw BridgeException("A script is already running.")
        withContext(Dispatchers.Main) { beginRun() }
        pushDrafts()
        val snapshot = tabs.associate { it.key to it.value.text }
        try {
            val res = call(newListener())
            val saved = res.getJSONArray("saved")
            for (i in 0 until saved.length()) {
                val rel = saved.getString(i)
                tabs.filter { it.rel == rel && snapshot[it.key] == it.value.text }.forEach { it.savedText = it.value.text }
            }
        } catch (e: BridgeException) {
            _run.value = RunStatus(phase = RunPhase.FAILED)
            throw e
        }
    }

    fun stopRun() {
        if (packsRun?.isActive == true) { packsRun?.cancel(); return }
        io { bridge.call("stop_run") }
    }

    fun restartRun() = io {
        bridge.call("stop_run")
        delay(300)
        withContext(Dispatchers.Main) { runCurrentFile() }
    }

    fun sendRunInput(text: String) = io {
        appendOut("stdout", text + "\n")
        bridge.call("send_run_input", text)
    }

    fun toggleOutput() { outputVisible.value = !outputVisible.value }

    /** Offline explanation and (when mechanical) one-line fix for a run error. Needs no key and no network. */
    suspend fun autofixFor(tab: TabState, e: RunError): AutoFix? = withContext(Dispatchers.IO) {
        val inThisFile = e.file.endsWith("/" + tab.rel) || e.file == tab.rel
        try {
            val o = bridge.obj("autofix", if (inThisFile) tab.value.text else "", e.type, e.message, e.line)
            val patch = o.optJSONObject("patch")
            val steps = o.optJSONArray("steps")
            AutoFix(
                o.getString("title"), o.getString("explanation"),
                (0 until (steps?.length() ?: 0)).map { steps!!.getString(it) },
                if (inThisFile && patch != null) patch.getInt("line") else null,
                patch?.optString("new").orEmpty(), o.optBoolean("packs"),
            )
        } catch (x: BridgeException) { null }
    }

    /** Applies a proposed one-line fix to the open file. The person sees it first and can undo it. */
    fun applyFix(tab: TabState, fix: AutoFix) {
        val line = fix.patchLine ?: return
        val v = tab.value
        val lines = v.text.split("\n").toMutableList()
        if (line == 0) lines.add(0, fix.patchNew)
        else if (line in 1..lines.size) lines[line - 1] = fix.patchNew
        else return
        val text = lines.joinToString("\n")
        applyEdit(tab, androidx.compose.ui.text.input.TextFieldValue(text, androidx.compose.ui.text.TextRange(0)))
        notify("Fix applied. Tap Undo to take it back.")
    }

    /** Last-resort recovery when a script is blocked in native code: restart the app process. Drafts are already stored. */
    fun forceRestartRuntime() {
        pushDrafts()
        android.os.Process.killProcess(android.os.Process.myPid())
    }

    // ---------------------------------------------------------------- terminal
    val terminals = mutableStateListOf<TerminalUi>()
    var activeTerminal by mutableIntStateOf(0)

    fun openTerminal() = io {
        val id = bridge.int("terminal_open", _current.value?.id)
        val t = TerminalUi(id, viewModelScope)
        t.prompt = bridge.str("terminal_prompt", id)
        withContext(Dispatchers.Main) {
            terminals.add(t)
            activeTerminal = terminals.lastIndex
            t.append("Python 3.x terminal. Type 'help' for commands.\n")
        }
    }

    fun closeTerminal(t: TerminalUi) = io {
        runCatching { bridge.call("terminal_close", t.id) }
        withContext(Dispatchers.Main) {
            terminals.remove(t)
            activeTerminal = activeTerminal.coerceIn(0, maxOf(0, terminals.lastIndex))
        }
    }

    fun terminalSubmit(t: TerminalUi, line: String) = io {
        if (t.busy) {
            bridge.call("terminal_input", t.id, line)
            t.append(line + "\n")
            return@io
        }
        t.append("${t.prompt}$line\n")
        if (line.isNotBlank()) { t.history.add(line); t.historyIndex = -1 }
        t.busy = true
        val listener = TerminalListener(
            output = { t.append(it) },
            done = { _ ->
                t.busy = false
                viewModelScope.launch(Dispatchers.IO) { runCatching { t.prompt = bridge.str("terminal_prompt", t.id) } }
            },
        )
        val r = bridge.obj("terminal_exec", t.id, line, listener)
        if (r.getBoolean("clear")) withContext(Dispatchers.Main) { t.output = "" }
        t.prompt = r.getString("prompt")
        if (!r.getBoolean("async")) t.busy = false
    }

    fun terminalInterrupt(t: TerminalUi) = io { bridge.call("terminal_interrupt", t.id) }

    fun terminalComplete(t: TerminalUi, line: String, onResult: (String) -> Unit) = io {
        val arr = bridge.arr("terminal_complete", t.id, line)
        if (arr.length() == 0) return@io
        val words = (0 until arr.length()).map { arr.getString(it) }
        val common = words.reduce { a, b -> a.commonPrefixWith(b) }
        val head = line.substringBeforeLast(' ', "").let { if (it.isEmpty() && !line.contains(' ')) "" else "$it " }
        withContext(Dispatchers.Main) {
            if (words.size == 1 || common.isNotEmpty()) onResult(head + (if (words.size == 1) words[0] else common))
            if (words.size > 1) t.append(words.joinToString("  ") + "\n")
        }
    }

    // ----------------------------------------------------------- Packs companion app
    private val packs = PacksClient(app)
    private val _packsInfo = MutableStateFlow(PacksInfo(installed = false))
    val packsInfo: StateFlow<PacksInfo> = _packsInfo.asStateFlow()
    private var packsRun: Job? = null

    /** Asks the Packs app (if installed) what it contains. Cheap to call again, e.g. when a screen opens. */
    fun refreshPacks() {
        viewModelScope.launch { _packsInfo.value = packs.info() }
    }

    /** Called when the app returns to the foreground: notices a Packs install/uninstall done in the meantime. */
    fun onAppResumed() {
        if (_ready.value && packs.isInstalled() != _packsInfo.value.installed) refreshPacks()
    }

    private fun packsJson(): String = JSONArray().also { arr ->
        _packsInfo.value.packages.forEach { (n, v) -> arr.put(JSONObject().put("name", n).put("version", v)) }
    }.toString()

    /** Opens Android's installer for the Packs app that ships inside this one. [onMessage] explains anything the person must do. */
    fun installPacks(onMessage: (String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val msg = try {
                PacksInstaller.install(getApplication())
            } catch (e: Exception) {
                "Could not start the installer: ${e.message ?: e.javaClass.simpleName}"
            }
            withContext(Dispatchers.Main) {
                onMessage(msg ?: "Confirm the installation on the Android screen, then come back to this app.")
            }
        }
    }

    private class PacksOutcome(val json: JSONObject, val changed: List<String>)

    /** Zips the project, runs a job in the Packs app and applies the files it created or changed. */
    private suspend fun runInPacks(project: Project, kind: String, arg: String, onOutput: (String, String) -> Unit): PacksOutcome =
        withContext(Dispatchers.IO) {
            val cache = getApplication<Application>().cacheDir
            val sent = File(cache, "packs-sent-${System.nanoTime()}.zip")
            val back = File(cache, "packs-back-${System.nanoTime()}.zip")
            try {
                bridge.str("packs_export", project.id, sent.absolutePath)
                val res = packs.run("j${System.nanoTime()}", kind, arg, sent, onOutput)
                var changed = emptyList<String>()
                res.zip?.let { pfd ->
                    ParcelFileDescriptor.AutoCloseInputStream(pfd).use { input -> back.outputStream().use { input.copyTo(it) } }
                    val arr = bridge.arr("packs_apply", project.id, back.absolutePath)
                    changed = (0 until arr.length()).map { arr.getString(it) }
                }
                if (changed.isNotEmpty()) (setOf("") + expanded.value).forEach { runCatching { loadDir(it) } }
                PacksOutcome(res.json, changed)
            } finally {
                sent.delete()
                back.delete()
            }
        }

    /** Runs the active file with Python 3.10 + the heavy libraries in the Packs app. */
    fun runWithPacks() = gated("Run with Packs") { runWithPacksNow() }

    private fun runWithPacksNow() {
        val tab = currentTab ?: return
        val project = _current.value ?: return
        if (_run.value.phase.isActive) { say("A script is already running."); return }
        if (!packs.isInstalled()) {
            say("The Python 3.x Packs app is not installed. Open Home → Package Manager to install it.")
            return
        }
        packsRun = viewModelScope.launch {
            val started = System.nanoTime()
            beginRun()
            fun seconds() = (System.nanoTime() - started) / 1e9
            try {
                withContext(Dispatchers.IO) { pushDrafts() }
                appendOut("stdout", "[Running ${tab.rel} in the Packs app (Python ${_packsInfo.value.python.ifEmpty { "3.10" }})]\n")
                _run.value = RunStatus(phase = RunPhase.RUNNING, backend = "packs")
                val outcome = runInPacks(project, "script", tab.rel) { stream, text -> appendOut(stream, text) }
                val r = outcome.json
                if (outcome.changed.isNotEmpty()) appendOut("stdout", "[Updated files: ${outcome.changed.joinToString(", ")}]\n")
                _run.value = RunStatus(
                    phase = RunPhase.from(r.optString("state", "failed")),
                    exitCode = if (r.isNull("exit_code")) null else r.optInt("exit_code"),
                    durationSec = r.optDouble("duration", seconds()),
                    stuck = r.optBoolean("stuck"),
                    backend = "packs",
                )
            } catch (e: kotlinx.coroutines.CancellationException) {
                _run.value = RunStatus(phase = RunPhase.STOPPED, durationSec = seconds(), backend = "packs")
                throw e
            } catch (e: Exception) {
                appendOut("stderr", (e.message ?: e.javaClass.simpleName) + "\n")
                _run.value = RunStatus(phase = RunPhase.FAILED, durationSec = seconds(), backend = "packs")
            }
        }
    }

    // ---------------------------------------------------------------- opencv studio
    private val VISION_PROJECT = "OpenCV Studio"
    suspend fun visionOperations(): JSONArray = withContext(Dispatchers.IO) {
        try { bridge.arr("vision_operations") } catch (e: BridgeException) { say(e.message ?: "Failed"); JSONArray() }
    }

    /** Copies a picked image into <project>/images and returns its project-relative path. */
    suspend fun visionImport(uri: Uri): Pair<String?, String?> = withContext(Dispatchers.IO) {
        try {
            val project = visionProject()
            val dir = File(bridge.str("vision_project_path", project.id), "images").apply { mkdirs() }
            val raw = displayName(uri) ?: "image.png"
            val name = raw.replace(Regex("[^A-Za-z0-9._-]"), "_").take(80).ifBlank { "image.png" }
            val target = File(dir, name)
            getApplication<Application>().contentResolver.openInputStream(uri)?.use { input ->
                target.outputStream().use { input.copyTo(it) }
            } ?: throw BridgeException("Could not open the picked image.")
            (setOf("") + expanded.value).forEach { runCatching { loadDir(it) } }
            "images/$name" to null
        } catch (e: BridgeException) { null to (e.message ?: "Import failed") }
        catch (e: Exception) { null to "Import failed: ${e.message}" }
    }

    /** Runs OpenCV in the Packs app. Returns the result, or the error text (shown inside the dialog, where snackbars would be hidden). */
    suspend fun visionProcess(rel: String, stepsJson: String, outRel: String): Pair<JSONObject?, String?> = withContext(Dispatchers.IO) {
        if (!packs.isInstalled()) {
            return@withContext null to "OpenCV runs in the Python 3.x Packs app, which is not installed. Open Home → Package Manager and tap Install."
        }
        try {
            val project = visionProject()
            val arg = JSONObject().put("rel", rel).put("steps", JSONArray(stepsJson)).put("out", outRel).toString()
            val outcome = runInPacks(project, "vision", arg) { _, _ -> }
            val r = outcome.json
            val info = r.optJSONObject("vision")
            if (info != null && r.optString("state") == "completed") info to null
            else null to (r.optString("error").ifEmpty { "Processing failed." })
        } catch (e: PacksException) { null to e.message }
        catch (e: BridgeException) { null to (e.message ?: "Processing failed") }
    }

    suspend fun projectFile(rel: String): File? = withContext(Dispatchers.IO) {
        runCatching { File(bridge.str("vision_project_path", visionProject().id), rel) }.getOrNull()
    }

    /**
     * OpenCV Studio keeps its images in its own project, "OpenCV Studio", created on first use, so the person never has to
     * create or open a project just to process a picture.
     */
    private fun visionProject(): Project {
        _projects.value.firstOrNull { it.name == VISION_PROJECT }?.let { return it }
        refreshProjects()
        _projects.value.firstOrNull { it.name == VISION_PROJECT }?.let { return it }
        val p = Project.from(bridge.obj("create_project", VISION_PROJECT))
        refreshProjects()
        return p
    }

    /** A temporary file plus a content URI the camera app can write a photo into. */
    fun visionCameraTarget(): Pair<File, Uri> {
        val dir = File(getApplication<Application>().cacheDir, "camera").apply { mkdirs() }
        val file = File(dir, "photo-${System.currentTimeMillis()}.jpg")
        val uri = androidx.core.content.FileProvider.getUriForFile(getApplication(), "${getApplication<Application>().packageName}.packsfiles", file)
        return file to uri
    }

    /** Moves a photo the camera app wrote into the OpenCV Studio project and returns its project-relative path. */
    suspend fun visionAdoptPhoto(file: File): Pair<String?, String?> = withContext(Dispatchers.IO) {
        try {
            if (!file.isFile || file.length() == 0L) return@withContext null to "No photo was taken."
            val dir = File(bridge.str("vision_project_path", visionProject().id), "images").apply { mkdirs() }
            val target = File(dir, file.name)
            file.copyTo(target, overwrite = true)
            file.delete()
            "images/${target.name}" to null
        } catch (e: Exception) { null to "Could not keep the photo: ${e.message}" }
    }

    /** Length of a picked video in milliseconds, or null if it cannot be read. */
    suspend fun visionVideoLength(uri: Uri): Long? = withContext(Dispatchers.IO) {
        val r = android.media.MediaMetadataRetriever()
        try {
            r.setDataSource(getApplication<Application>(), uri)
            r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
        } catch (e: Exception) { null } finally { runCatching { r.release() } }
    }

    /** Saves the frame of a picked video at [timeMs] as an image in the OpenCV Studio project. */
    suspend fun visionVideoFrame(uri: Uri, timeMs: Long): Pair<String?, String?> = withContext(Dispatchers.IO) {
        val r = android.media.MediaMetadataRetriever()
        try {
            r.setDataSource(getApplication<Application>(), uri)
            val bmp = r.getFrameAtTime(timeMs * 1000, android.media.MediaMetadataRetriever.OPTION_CLOSEST)
                ?: return@withContext null to "That frame could not be read."
            val dir = File(bridge.str("vision_project_path", visionProject().id), "images").apply { mkdirs() }
            val name = "video-frame-${timeMs}.png"
            File(dir, name).outputStream().use { bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
            "images/$name" to null
        } catch (e: Exception) { null to "Could not read the video: ${e.message}" } finally { runCatching { r.release() } }
    }

    /** Copies the last result picture to a place the person chose with the system file picker. */
    suspend fun visionSave(rel: String, uri: Uri): String = withContext(Dispatchers.IO) {
        try {
            val src = File(bridge.str("vision_project_path", visionProject().id), rel)
            if (!src.isFile) return@withContext "There is no result to save yet. Tap Apply first."
            getApplication<Application>().contentResolver.openOutputStream(uri, "w")?.use { out ->
                src.inputStream().use { it.copyTo(out) }
            } ?: return@withContext "Could not write to that location."
            "Saved."
        } catch (e: Exception) { "Save failed: ${e.message}" }
    }

    // ---------------------------------------------------------------- debugger
    private val _debug = MutableStateFlow(DebugState())
    val debug: StateFlow<DebugState> = _debug.asStateFlow()

    /** Breakpoints per file, keyed "projectId:rel". Survive between runs, not between app launches. */
    val breakpoints = androidx.compose.runtime.mutableStateMapOf<String, Set<Int>>()

    private fun cursorLine(tab: TabState): Int =
        tab.value.text.take(tab.value.selection.start.coerceIn(0, tab.value.text.length)).count { it == '\n' } + 1

    fun toggleBreakpoint(tab: TabState) {
        val line = cursorLine(tab)
        val current = breakpoints[tab.key] ?: emptySet()
        val next = if (line in current) current - line else current + line
        if (next.isEmpty()) breakpoints.remove(tab.key) else breakpoints[tab.key] = next
        notify(if (line in current) "Breakpoint removed at line $line" else "Breakpoint set at line $line")
        if (_debug.value.active) io { bridge.call("debug_set_breakpoints", tab.rel, JSONArray(next.sorted()).toString()) }
    }

    fun startDebug(stopOnEntry: Boolean = false) {
        val tab = currentTab ?: return
        io {
            if (_run.value.phase.isActive) throw BridgeException("A script is running. Stop it before debugging.")
            pushDrafts()
            tabs.filter { it.isDirty && it.projectId == tab.projectId }.forEach { saveTabInternal(it) }
            val bp = JSONObject()
            breakpoints.filterKeys { it.startsWith("${tab.projectId}:") }.forEach { (k, v) ->
                bp.put(k.substringAfter(':'), JSONArray(v.sorted()))
            }
            withContext(Dispatchers.Main) {
                _output.value = emptyList(); pendingOut.clear(); screen.reset(); _screenVersion.value = _screenVersion.value + 1; outputVisible.value = true
                _debug.value = DebugState(active = true, message = "Running to the first breakpoint…")
            }
            val listener = DebugListener { ev ->
                when (ev.getString("event")) {
                    "output" -> appendOut(ev.getString("stream"), ev.getString("text"))
                    "paused" -> {
                        val vars = ev.getJSONObject("variables")
                        val stack = ev.getJSONArray("stack")
                        _debug.value = DebugState(
                            active = true, paused = true, file = ev.getString("file"), line = ev.getInt("line"),
                            function = ev.getString("function"),
                            stack = (0 until stack.length()).map { i -> stack.getJSONObject(i).let { "${it.getString("function")}  ${it.getString("file")}:${it.getInt("line")}" } },
                            variables = vars.keys().asSequence().map { it to vars.getString(it) }.toList(),
                        )
                    }
                    "finished" -> {
                        val err = if (ev.isNull("error")) null else ev.getString("error")
                        _debug.value = DebugState(active = false, message = err ?: "Debug session finished (exit ${ev.getInt("exit_code")})")
                    }
                }
            }
            try {
                bridge.call("debug_start", tab.projectId, tab.rel, bp.toString(), stopOnEntry, listener)
            } catch (e: BridgeException) {
                _debug.value = DebugState()
                throw e
            }
        }
    }

    fun debugCommand(cmd: String) = io { bridge.call("debug_command", cmd) }

    // ---------------------------------------------------------------- packages
    suspend fun packageList(call: String, vararg args: Any?): List<PackageInfo> = withContext(Dispatchers.IO) {
        val arr = bridge.arr(call, *args, packsJson())
        (0 until arr.length()).map { PackageInfo.from(arr.getJSONObject(it)) }
    }

    suspend fun installedPackages(): List<Pair<String, String>> = withContext(Dispatchers.IO) {
        val arr = bridge.arr("packages_installed")
        (0 until arr.length()).map { arr.getJSONObject(it).let { o -> o.getString("name") to o.getString("version") } }
    }

    suspend fun checkPackage(name: String): Pair<PackageInfo?, String?> = withContext(Dispatchers.IO) {
        try { PackageInfo.from(bridge.obj("packages_check", name, packsJson())) to null } catch (e: BridgeException) { null to (e.message ?: "Invalid name") }
    }

    // ------------------------------------------------------------------ GitHub
    private val secure = SecureStore(app)
    val githubDialogOpen = MutableStateFlow(false)
    /** Admin panel is hosted by the app shell so it covers the whole screen, not just the Home list. */
    val adminOpen = MutableStateFlow(false)
    fun openGithub() { githubDialogOpen.value = true; refreshGithub() }
    fun closeGithub() { githubDialogOpen.value = false }

    private val _githubUser = MutableStateFlow<String?>(null)
    val githubUser: StateFlow<String?> = _githubUser.asStateFlow()
    private val _githubRepos = MutableStateFlow<List<GitRepo>>(emptyList())
    val githubRepos: StateFlow<List<GitRepo>> = _githubRepos.asStateFlow()
    private val _githubStatus = MutableStateFlow<JSONObject?>(null)
    val githubStatus: StateFlow<JSONObject?> = _githubStatus.asStateFlow()
    private val _githubBusy = MutableStateFlow(false)
    val githubBusy: StateFlow<Boolean> = _githubBusy.asStateFlow()
    private val _githubMessage = MutableStateFlow<String?>(null)
    val githubMessage: StateFlow<String?> = _githubMessage.asStateFlow()
    val hasGithubToken = MutableStateFlow(false)

    /** Runs [block] with the stored token; errors become an inline message (snackbars hide behind dialogs). */
    private fun githubTask(needToken: Boolean = true, block: suspend (token: String) -> String?) {
        viewModelScope.launch(Dispatchers.IO) {
            val token = secure.get("github_token").orEmpty()
            if (needToken && token.isEmpty()) { _githubMessage.value = "Add your GitHub token first."; return@launch }
            _githubBusy.value = true
            _githubMessage.value = null
            try {
                _githubMessage.value = block(token)
            } catch (e: BridgeException) {
                _githubMessage.value = e.message ?: "GitHub request failed"
            } catch (e: Exception) {
                _githubMessage.value = "Unexpected error: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                _githubBusy.value = false
            }
        }
    }

    fun refreshGithub() {
        hasGithubToken.value = secure.has("github_token")
        val p = _current.value
        if (p == null) { _githubStatus.value = null; return }
        viewModelScope.launch(Dispatchers.IO) {
            _githubStatus.value = try { bridge.obj("github_status", p.id) } catch (e: Exception) { null }
        }
    }

    fun githubConnect(token: String) {
        val clean = token.trim()
        githubTask(needToken = false) {
            val login = bridge.obj("github_user", clean).getString("login")
            secure.put("github_token", clean)
            hasGithubToken.value = true
            _githubUser.value = login
            "Connected as $login."
        }
    }

    fun githubForget() {
        secure.remove("github_token")
        hasGithubToken.value = false
        _githubUser.value = null
        _githubRepos.value = emptyList()
        _githubMessage.value = "Token removed from this device."
    }

    fun githubLoadRepos() = githubTask { token ->
        val arr = bridge.arr("github_repos", token)
        _githubRepos.value = (0 until arr.length()).map { arr.getJSONObject(it).let { o ->
            GitRepo(o.getString("owner"), o.getString("name"), o.getBoolean("private"), o.getString("default_branch"))
        } }
        "Found ${arr.length()} repositories."
    }

    fun githubClone(owner: String, repo: String) = githubTask { token ->
        val p = Project.from(bridge.obj("github_clone", token, owner.trim(), repo.trim(), "", ""))
        refreshProjects()
        selectProjectInternal(p)
        _githubStatus.value = bridge.obj("github_status", p.id)
        "Cloned $owner/$repo into the project \"${p.name}\"."
    }

    fun githubPush(message: String, newBranch: String) = githubTask { token ->
        val p = _current.value ?: return@githubTask "Open a project first."
        val r = bridge.obj("github_push", token, p.id, message, newBranch.trim())
        _githubStatus.value = bridge.obj("github_status", p.id)
        "Pushed commit ${r.getString("commit")} to ${r.getString("branch")} (${r.getInt("added")} added, ${r.getInt("modified")} changed, ${r.getInt("deleted")} deleted)."
    }

    fun githubPull() = githubTask { token ->
        val p = _current.value ?: return@githubTask "Open a project first."
        val r = bridge.obj("github_pull", token, p.id)
        withContext(Dispatchers.Main) {
            // Open files that were not edited are closed so they reload with the new content.
            tabs.removeAll { it.projectId == p.id && !it.isDirty }
            activeTab = activeTab.coerceIn(0, maxOf(0, tabs.lastIndex))
        }
        (setOf("") + expanded.value).forEach { runCatching { loadDir(it) } }
        _githubStatus.value = bridge.obj("github_status", p.id)
        if (r.getInt("updated") == 0 && r.getInt("removed") == 0) "Already up to date."
        else "Pulled ${r.getString("commit")}: ${r.getInt("updated")} files updated, ${r.getInt("removed")} moved to the trash."
    }

    fun githubUnlink() = githubTask(needToken = false) {
        val p = _current.value ?: return@githubTask null
        bridge.call("github_unlink", p.id)
        _githubStatus.value = bridge.obj("github_status", p.id)
        "This project is no longer linked."
    }

    // ------------------------------------------------------------ AI assistant
    // The assistant runs entirely on this phone (rules + Python's own parser). It needs no key, account or network.
    val aiDialogOpen = MutableStateFlow(false)
    fun openAi() { aiDialogOpen.value = true }
    fun closeAi() { aiDialogOpen.value = false }

    val aiMessages = mutableStateListOf<ChatMsg>()
    private val _aiBusy = MutableStateFlow(false)
    val aiBusy: StateFlow<Boolean> = _aiBusy.asStateFlow()

    fun newAiChat() { aiMessages.clear() }

    /** [action] is chat, explain, fix, improve, tests or docstring. Uses the selection, or the whole open file. */
    fun aiAsk(action: String, question: String = "") {
        if (_aiBusy.value) return
        val tab = currentTab
        val text = tab?.value?.text.orEmpty()
        val selection = tab?.value?.let { v -> if (!v.selection.collapsed) text.substring(v.selection.min, v.selection.max) else "" }.orEmpty()
        val err = _run.value.error?.takeIf { _run.value.phase == RunPhase.FAILED }
        val errJson = err?.let { JSONObject().put("type", it.type).put("message", it.message).put("line", it.line).toString() }.orEmpty()
        val label = when (action) {
            "explain" -> "Explain this code"; "fix" -> "Fix this code"; "improve" -> "Improve this code"
            "tests" -> "Write tests"; "docstring" -> "Add docstrings"; else -> question
        }
        if (action == "chat" && question.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            _aiBusy.value = true
            try {
                withContext(Dispatchers.Main) { aiMessages.add(ChatMsg("user", label)) }
                val o = bridge.obj("assist", action, text, selection, question, errJson, tab?.rel ?: "main.py")
                val f = o.optJSONObject("fix")
                val fix = f?.let { AutoFix("Suggested fix", "", emptyList(), it.getInt("line"), it.getString("new"), false) }
                withContext(Dispatchers.Main) { aiMessages.add(ChatMsg("assistant", o.getString("text"), fix)) }
            } catch (e: BridgeException) {
                withContext(Dispatchers.Main) { aiMessages.add(ChatMsg("assistant", "Something went wrong: ${e.message ?: "unknown error"}")) }
            } finally {
                _aiBusy.value = false
            }
        }
    }

    // ------------------------------------------------------------------- ads
    fun refreshAds() {
        viewModelScope.launch(Dispatchers.IO) { runCatching { loadAdsNow() } }
    }

    /** Called only after the ad SDK reports that the viewer earned the reward. */
    fun grantRewardUnlock() {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                val u = bridge.obj("ads_grant_unlock")
                _unlock.value = UnlockStatus(u.getBoolean("unlocked"), u.getInt("remaining_seconds"))
                _unlockEndsAt.value = u.getInt("remaining_seconds").let { r -> if (r > 0) android.os.SystemClock.elapsedRealtime() + r * 1000L else 0L }
            }
            _account.value?.let { acc -> runCatching { bridge.call("backend_log_event", acc.accessToken, "ad_unlock") } }
        }
    }

    // ----------------------------------------------------- locked features (rewarded unlock)
    /** SystemClock.elapsedRealtime() value at which the current unlock ends (0 = not unlocked). */
    private val _unlockEndsAt = MutableStateFlow(0L)
    val unlockEndsAt: StateFlow<Long> = _unlockEndsAt.asStateFlow()

    /** Features are gated only while the admin has real ads switched on; with ads off everything is open. */
    private fun gateActive(): Boolean {
        val a = _ads.value
        if (!a.adsEnabled || !a.rewardedEnabled) return false
        // Never lock people out: Unity locks only when it has the IDs it needs to actually serve an ad.
        return a.provider == "admob" || (a.provider == "unity" && a.unityGameId.isNotBlank() && a.unityPlacementId.isNotBlank())
    }
    fun isUnlocked(): Boolean = !gateActive() || _unlock.value.unlocked && _unlockEndsAt.value > android.os.SystemClock.elapsedRealtime()
    fun gateIsOn(): Boolean = gateActive()

    class LockPrompt(val feature: String, val onUnlocked: () -> Unit)
    private val _lockPrompt = MutableStateFlow<LockPrompt?>(null)
    val lockPrompt: StateFlow<LockPrompt?> = _lockPrompt.asStateFlow()
    fun dismissLock() { _lockPrompt.value = null }

    /** Runs [action] now if the feature is open, otherwise asks the person to watch a rewarded ad first. */
    fun gated(feature: String, action: () -> Unit) {
        if (isUnlocked()) action() else _lockPrompt.value = LockPrompt(feature, action)
    }

    // ------------------------------------------------------------- tool dialogs
    /** Which full-screen tool dialog is open: packages, opencv, datascience or game (null = none). */
    private val _toolDialog = MutableStateFlow<String?>(null)
    val toolDialog: StateFlow<String?> = _toolDialog.asStateFlow()
    fun closeToolDialog() { _toolDialog.value = null }

    /** Opens a tool. OpenCV Studio and the Data Science examples are advanced features and respect the rewarded unlock. */
    fun openTool(name: String) {
        when (name) {
            "opencv" -> gated("OpenCV Studio") { _toolDialog.value = "opencv" }
            "datascience" -> gated("Data Science") { _toolDialog.value = "datascience" }
            else -> _toolDialog.value = name
        }
    }

    // --------------------------------------------------------- onboarding & examples
    private val uiPrefs = app.getSharedPreferences("py3x_ui", android.content.Context.MODE_PRIVATE)
    private val _onboarded = MutableStateFlow(uiPrefs.getBoolean("onboarded", false))
    val onboarded: StateFlow<Boolean> = _onboarded.asStateFlow()
    fun finishOnboarding() { uiPrefs.edit().putBoolean("onboarded", true).apply(); _onboarded.value = true }

    suspend fun exampleList(): List<ExampleInfo> = withContext(Dispatchers.IO) {
        try {
            val arr = bridge.arr("templates_list")
            (0 until arr.length()).map { arr.getJSONObject(it).let { o ->
                ExampleInfo(o.getString("key"), o.getString("title"), o.getString("desc"), o.getString("needs"), o.getString("runs_in"), o.optString("category", "data"))
            } }
        } catch (e: BridgeException) { emptyList() }
    }

    /** Creates the example as a new project, opens its main file and reports a ready-made message. */
    fun createExample(key: String, onDone: (String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val msg = try {
                val p = Project.from(bridge.obj("templates_create", key))
                refreshProjects()
                selectProjectInternal(p)
                openFileInternal(p.id, p.mainFile)
                "Created “${p.name}”. Open the Editor and tap RUN" + if (key == "machine-learning") " — this one needs PACKS." else if (key.startsWith("game-")) ". Type your answers in the input box on the Run page." else "."
            } catch (e: BridgeException) { e.message ?: "Could not create the example" }
            withContext(Dispatchers.Main) { onDone(msg) }
        }
    }

    // ------------------------------------------------------------ backend (Supabase)
    data class Account(val email: String, val role: String, val accessToken: String) {
        val isAdmin get() = role == "admin"
    }
    private val _backendOn = MutableStateFlow(false)
    /** True only when this build was given a Supabase URL + public key. Otherwise the app is fully offline. */
    val backendOn: StateFlow<Boolean> = _backendOn.asStateFlow()
    private val _account = MutableStateFlow<Account?>(null)
    val account: StateFlow<Account?> = _account.asStateFlow()
    private val _stats = MutableStateFlow<JSONObject?>(null)
    val stats: StateFlow<JSONObject?> = _stats.asStateFlow()
    private val _accountBusy = MutableStateFlow(false)
    val accountBusy: StateFlow<Boolean> = _accountBusy.asStateFlow()
    private val _accountError = MutableStateFlow<String?>(null)
    val accountError: StateFlow<String?> = _accountError.asStateFlow()
    fun clearAccountError() { _accountError.value = null }

    private fun startBackend() {
        val r = bridge.obj("backend_configure", com.py3x.ide.BuildConfig.SUPABASE_URL, com.py3x.ide.BuildConfig.SUPABASE_ANON_KEY)
        _backendOn.value = r.getBoolean("configured")
        if (!_backendOn.value) return
        val refresh = secure.get("sb_refresh")
        if (refresh != null) {
            try { adoptSession(bridge.obj("backend_refresh", refresh)) } catch (e: BridgeException) { secure.remove("sb_refresh") }
        }
        runCatching { _ads.value = AdsConfig.from(bridge.obj("backend_pull_ads")) }
        if (_account.value != null) runCatching { bridge.call("backend_log_event", _account.value!!.accessToken, "app_open") }
    }

    private fun adoptSession(o: JSONObject) {
        secure.put("sb_refresh", o.optString("refresh_token"))
        _account.value = Account(o.optString("email"), o.optString("role", "user"), o.getString("access_token"))
    }

    fun signIn(email: String, password: String, create: Boolean) {
        if (_accountBusy.value) return
        _accountBusy.value = true; _accountError.value = null
        viewModelScope.launch(Dispatchers.IO) {
            try {
                if (create) {
                    val r = bridge.obj("backend_sign_up", email, password)
                    if (r.getBoolean("needs_confirmation")) {
                        say("Check your email to confirm the account, then sign in.")
                        return@launch
                    }
                }
                adoptSession(bridge.obj("backend_sign_in", email, password))
                runCatching { _ads.value = AdsConfig.from(bridge.obj("backend_pull_ads")) }
            } catch (e: BridgeException) {
                _accountError.value = e.message ?: "Sign-in failed"
            } catch (e: Exception) {
                _accountError.value = "Unexpected error: ${e.message}"
            } finally { _accountBusy.value = false }
        }
    }

    fun signOut() {
        val a = _account.value
        _account.value = null; _stats.value = null
        secure.remove("sb_refresh")
        if (a != null) io { bridge.call("backend_sign_out", a.accessToken) }
    }

    fun loadStats() {
        val a = _account.value ?: return
        if (!a.isAdmin) return
        io { _stats.value = bridge.obj("backend_admin_stats", a.accessToken) }
    }

    // ------------------------------------------------------------ admin & ads
    var adminToken by mutableStateOf<String?>(null)
        private set
    private val _ads = MutableStateFlow(AdsConfig())
    val ads: StateFlow<AdsConfig> = _ads.asStateFlow()
    private val _unlock = MutableStateFlow(UnlockStatus())
    val unlock: StateFlow<UnlockStatus> = _unlock.asStateFlow()

    /** Reports failure text through [onError]; success sets [adminToken]. */
    fun adminLogin(password: String, onError: (String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val token = bridge.str("admin_login", password)
                loadAdsNow()
                withContext(Dispatchers.Main) { adminToken = token }
            } catch (e: BridgeException) {
                withContext(Dispatchers.Main) { onError(e.message ?: "Sign-in failed") }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { onError("Unexpected error: ${e.message}") }
            }
        }
    }

    fun adminLogout() {
        val token = adminToken
        adminToken = null
        if (token != null) io { bridge.call("admin_logout", token) }
    }

    private fun loadAdsNow() {
        _ads.value = AdsConfig.from(bridge.obj("ads_get_config"))
        val u = bridge.obj("ads_unlock_status")
        _unlock.value = UnlockStatus(u.getBoolean("unlocked"), u.getInt("remaining_seconds"))
        _unlockEndsAt.value = u.getInt("remaining_seconds").let { r -> if (r > 0) android.os.SystemClock.elapsedRealtime() + r * 1000L else 0L }
    }

    /** Session problems (expired token) sign the admin out so they see the password screen again. */
    private fun adminIo(block: suspend (String) -> Unit) = viewModelScope.launch(Dispatchers.IO) {
        val token = adminToken ?: return@launch
        try {
            block(token)
        } catch (e: BridgeException) {
            if (e.message?.contains("session expired", ignoreCase = true) == true) withContext(Dispatchers.Main) { adminToken = null }
            say(e.message ?: "Something went wrong")
        } catch (e: Exception) {
            say("Unexpected error: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    fun updateAds(updates: JSONObject) {
        val a = _account.value
        if (_backendOn.value) {
            if (a == null || !a.isAdmin) { say("Sign in with an admin account first."); return }
            io {
                _ads.value = AdsConfig.from(bridge.obj("backend_push_ads", a.accessToken, updates.toString()))
                say("Ad settings saved for all users")
            }
            return
        }
        adminIo { token ->
            _ads.value = AdsConfig.from(bridge.obj("admin_set_ads_config", token, updates.toString()))
            say("Ad settings saved")
        }
    }

    fun adminTestUnlock() {
        if (_backendOn.value) {
            io {
                val u = bridge.obj("ads_grant_unlock")
                _unlock.value = UnlockStatus(u.getBoolean("unlocked"), u.getInt("remaining_seconds"))
                loadAdsNow()
                say("Test unlock granted")
            }
            return
        }
        adminTestUnlockLocal()
    }

    private fun adminTestUnlockLocal() = adminIo { token ->
        val u = bridge.obj("admin_test_unlock", token)
        _unlock.value = UnlockStatus(u.getBoolean("unlocked"), u.getInt("remaining_seconds"))
        say("Test unlock granted")
    }

    fun changeAdminPassword(current: String, new: String, onResult: (String?) -> Unit) {
        val token = adminToken ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                bridge.call("admin_change_password", token, current, new)
                withContext(Dispatchers.Main) { adminToken = null; onResult(null) }
            } catch (e: BridgeException) {
                withContext(Dispatchers.Main) { onResult(e.message ?: "Could not change password") }
            }
        }
    }

    // ---------------------------------------------------------------- logs
    suspend fun logTail(): String = withContext(Dispatchers.IO) { runCatching { bridge.str("log_tail", 200) }.getOrDefault("") }

    override fun onCleared() {
        super.onCleared()
    }

    companion object {
        const val MAX_OUTPUT_CHARS = 300_000
    }
}
