package com.py3x.ide.ui.ads

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import com.py3x.ide.ui.components.ToolButton
import com.py3x.ide.vm.AdsConfig
import com.unity3d.ads.IUnityAdsInitializationListener
import com.unity3d.ads.IUnityAdsLoadListener
import com.unity3d.ads.IUnityAdsShowListener
import com.unity3d.ads.UnityAds
import com.unity3d.ads.UnityAdsShowOptions
import com.unity3d.ads.metadata.MetaData
import com.py3x.ide.vm.IdeViewModel
import kotlinx.coroutines.delay

/** Google's published sample unit ids: they only ever show clearly labelled test ads and earn nothing. */
private const val TEST_BANNER = "ca-app-pub-3940256099942544/6300978111"
private const val TEST_REWARDED = "ca-app-pub-3940256099942544/5224354917"

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

private var sdkStarted = false
private var consentRunning = false

/** True once the person has made their privacy choice (or none is needed) and the ad SDK may start. */
private val adsReady = mutableStateOf(false)

/**
 * Ads start only after Google's consent flow (UMP) says ads may be requested. The form is shown only where the law
 * requires it. Nothing here runs unless ads are switched on in the admin panel; coding never depends on it.
 */
private fun ensureAds(context: Context) {
    if (sdkStarted || consentRunning) return
    val activity = context.findActivity() ?: return
    consentRunning = true
    val info = UserMessagingPlatform.getConsentInformation(activity)
    info.requestConsentInfoUpdate(
        activity, ConsentRequestParameters.Builder().build(),
        {
            UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { _ ->
                consentRunning = false
                startIfAllowed(activity)
            }
        },
        { _ -> consentRunning = false; startIfAllowed(activity) },
    )
}

private fun startIfAllowed(activity: Activity) {
    if (sdkStarted) return
    if (UserMessagingPlatform.getConsentInformation(activity).canRequestAds()) {
        MobileAds.initialize(activity.applicationContext)
        sdkStarted = true
        adsReady.value = true
    }
}

/** Whether Google requires an "Ad privacy choices" entry in the app (shown in More). */
fun privacyChoicesRequired(context: Context): Boolean = try {
    UserMessagingPlatform.getConsentInformation(context).privacyOptionsRequirementStatus ==
        com.google.android.ump.ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED
} catch (e: Exception) { false }

fun showPrivacyChoices(context: Context) {
    val a = context.findActivity() ?: return
    UserMessagingPlatform.showPrivacyOptionsForm(a) { _ -> }
}

@Composable
private fun Banner(unitId: String) {
    AndroidView(
        modifier = Modifier.fillMaxWidth(),
        factory = { ctx ->
            AdView(ctx).apply {
                setAdSize(AdSize.BANNER)
                adUnitId = unitId
                loadAd(AdRequest.Builder().build())
            }
        },
        onRelease = { it.destroy() },
    )
}

/**
 * Home-screen ads block. Shows nothing unless the admin enabled ads with the AdMob provider, and nothing
 * while a rewarded unlock is active. AdMob shows a banner and a rewarded ad; Unity shows the rewarded ad only.
 */
@Composable
fun AdsBlock(vm: IdeViewModel, modifier: Modifier = Modifier) {
    val ads by vm.ads.collectAsState()
    val unlock by vm.unlock.collectAsState()
    val context = LocalContext.current

    // Re-read the unlock timer now and then so the banner returns when it runs out.
    LaunchedEffect(Unit) { while (true) { vm.refreshAds(); delay(30_000) } }

    if (!ads.adsEnabled || ads.provider == "none") return
    if (unlock.unlocked) {
        Text("Ad-free for about ${maxOf(1, unlock.remainingSeconds / 60)} more minutes.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary, modifier = modifier)
        return
    }
    LaunchedEffect(Unit) { ensureAds(context) }
    val ready by adsReady
    if (!ready) {
        Text("Ads start after the ad privacy choice is made.", style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = modifier)
        return
    }
    if (ads.provider == "unity") {
        Column(modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface, MaterialTheme.shapes.medium).padding(10.dp)) {
            if (ads.rewardedEnabled) RewardedAction(ads, "Watch ad · ad-free for ${ads.unlockMinutes} min", onReward = { vm.grantRewardUnlock() })
        }
        return
    }

    val bannerId = ads.bannerUnitId.ifBlank { TEST_BANNER }
    val rewardedId = ads.rewardedUnitId.ifBlank { TEST_REWARDED }
    val isTest = ads.bannerUnitId.isBlank() || ads.rewardedUnitId.isBlank()

    Column(modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface, MaterialTheme.shapes.medium).padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (isTest) Text("Test ads (no AdMob unit ids set in the admin panel).", style = MaterialTheme.typography.labelSmall)
        if (ads.bannerEnabled) BannerBox(bannerId)
        if (ads.rewardedEnabled) RewardedAction(ads, "Watch ad · ad-free for ${ads.unlockMinutes} min", onReward = { vm.grantRewardUnlock() })
    }
}

@Composable
private fun BannerBox(unitId: String) {
    androidx.compose.foundation.layout.Box(Modifier.fillMaxWidth().heightIn(min = 50.dp)) { Banner(unitId) }
}

/** Loads a rewarded ad and shows it on tap. [onReward] runs only if the SDK reports that the viewer earned the reward. */
@Composable
private fun AdMobRewarded(unitId: String, minutes: Int, label: String, onReward: () -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val ready by adsReady
    var loaded by remember(unitId) { mutableStateOf<RewardedAd?>(null) }
    var status by remember(unitId) { mutableStateOf("Loading a reward ad…") }

    fun load() {
        if (!ready) { status = "Waiting for the ad privacy choice…"; return }
        status = "Loading a reward ad…"
        RewardedAd.load(context, unitId, AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
            override fun onAdLoaded(ad: RewardedAd) { loaded = ad; status = "Watch a short ad to unlock for $minutes minutes." }
            override fun onAdFailedToLoad(error: LoadAdError) { loaded = null; status = "No reward ad available right now (${error.message}). Nothing is unlocked without a finished ad." }
        })
    }
    LaunchedEffect(Unit) { ensureAds(context) }
    DisposableEffect(unitId, ready) { load(); onDispose { loaded = null } }

    Column(modifier, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(status, style = MaterialTheme.typography.bodySmall)
        ToolButton(label, enabled = loaded != null, emphasized = true, onClick = {
            val ad = loaded
            val activity = context.findActivity()
            if (ad != null && activity != null) {
                loaded = null
                ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() { load() }
                }
                ad.show(activity) { _ -> onReward() }
            }
        })
        if (loaded == null) ToolButton("Try again", onClick = { load() })
    }
}

/** Unit id for the rewarded ad: the admin's value, or Google's sample id (test ads only). */
fun rewardedUnitId(configured: String): String = configured.ifBlank { TEST_REWARDED }

/** Rewarded ad for whichever network the admin switched on. The reward callback runs only for a finished ad. */
@Composable
fun RewardedAction(ads: AdsConfig, label: String, onReward: () -> Unit, modifier: Modifier = Modifier) {
    if (ads.provider == "unity") UnityRewarded(ads, label, onReward, modifier)
    else AdMobRewarded(rewardedUnitId(ads.rewardedUnitId), ads.unlockMinutes, label, onReward, modifier)
}

private var unityInitFor: String? = null

@Composable
private fun UnityRewarded(ads: AdsConfig, label: String, onReward: () -> Unit, modifier: Modifier) {
    val context = LocalContext.current
    val ready by adsReady
    val game = ads.unityGameId
    val placement = ads.unityPlacementId
    var loaded by remember(game, placement) { mutableStateOf(false) }
    var status by remember(game, placement) { mutableStateOf("Loading a reward ad…") }

    fun load() {
        loaded = false
        status = "Loading a reward ad…"
        UnityAds.load(placement, object : IUnityAdsLoadListener {
            override fun onUnityAdsAdLoaded(placementId: String) { loaded = true; status = "Watch a short ad to unlock for ${ads.unlockMinutes} minutes." }
            override fun onUnityAdsFailedToLoad(placementId: String, error: UnityAds.UnityAdsLoadError, message: String) {
                loaded = false; status = "No reward ad available right now ($message). Nothing is unlocked without a finished ad."
            }
        })
    }

    LaunchedEffect(Unit) { ensureAds(context) }
    DisposableEffect(game, placement, ready) {
        when {
            game.isBlank() || placement.isBlank() -> status = "Unity Game ID and Placement ID are not set in the admin panel."
            !ready -> status = "Waiting for the ad privacy choice…"
            unityInitFor == game -> load()
            else -> {
                MetaData(context.applicationContext).apply { set("gdpr.consent", true); commit() }
                UnityAds.initialize(context.applicationContext, game, false, object : IUnityAdsInitializationListener {
                    override fun onInitializationComplete() { unityInitFor = game; load() }
                    override fun onInitializationFailed(error: UnityAds.UnityAdsInitializationError, message: String) {
                        status = "Unity could not start ($message)."
                    }
                })
            }
        }
        onDispose { }
    }

    Column(modifier, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(status, style = MaterialTheme.typography.bodySmall)
        ToolButton(label, enabled = loaded, emphasized = true, onClick = {
            val activity = context.findActivity()
            if (loaded && activity != null) {
                loaded = false
                UnityAds.show(activity, placement, UnityAdsShowOptions(), object : IUnityAdsShowListener {
                    override fun onUnityAdsShowFailure(placementId: String, error: UnityAds.UnityAdsShowError, message: String) { status = "The ad could not be shown ($message)." }
                    override fun onUnityAdsShowStart(placementId: String) {}
                    override fun onUnityAdsShowClick(placementId: String) {}
                    override fun onUnityAdsShowComplete(placementId: String, state: UnityAds.UnityAdsShowCompletionState) {
                        if (state == UnityAds.UnityAdsShowCompletionState.COMPLETED) onReward()
                        load()
                    }
                })
            }
        })
        if (!loaded && game.isNotBlank() && placement.isNotBlank() && ready && unityInitFor == game) ToolButton("Try again", onClick = { load() })
    }
}
