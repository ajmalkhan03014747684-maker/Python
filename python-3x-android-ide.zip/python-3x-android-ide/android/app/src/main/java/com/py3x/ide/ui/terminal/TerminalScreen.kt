package com.py3x.ide.ui.terminal

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.py3x.ide.ui.components.ToolButton
import com.py3x.ide.ui.theme.Palette
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Color
import com.py3x.ide.vm.IdeViewModel
import com.py3x.ide.vm.TerminalUi

@Composable
fun TerminalScreen(vm: IdeViewModel) {
    // A terminal is created lazily the first time the screen is opened.
    LaunchedEffect(Unit) { if (vm.terminals.isEmpty()) vm.openTerminal() }
    val terminal = vm.terminals.getOrNull(vm.activeTerminal)
    val project by vm.currentProject.collectAsState()

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).imePadding()) {
        Row(Modifier.padding(start = 12.dp, end = 12.dp, top = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            com.py3x.ide.ui.components.PyMark(30.dp)
            Text("Terminal", style = MaterialTheme.typography.titleLarge, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
        }
        // Tabs scroll sideways so any number of terminals fits.
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            vm.terminals.forEachIndexed { i, _ ->
                ToolButton(
                    label = "${i + 1}",
                    onClick = { vm.activeTerminal = i },
                    emphasized = i == vm.activeTerminal,
                    description = "Terminal ${i + 1}" + if (i == vm.activeTerminal) ", selected" else "",
                )
            }
            ToolButton("+", onClick = { vm.openTerminal() }, description = "New terminal")
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Box(Modifier.weight(1f))
            if (terminal != null) {
                val clipboard = LocalClipboardManager.current
                ToolButton("Copy", onClick = {
                    clipboard.setText(AnnotatedString(terminal.output))
                    vm.notify("Terminal output copied")
                }, description = "Copy terminal output")
                ToolButton("Close", onClick = { vm.closeTerminal(terminal) }, description = "Close terminal")
            }
        }
        Text(
            text = project?.let { "Working in project: ${it.name}" } ?: "No project selected — commands run in a scratch area",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp),
        )
        if (terminal == null) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("Starting terminal…", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            TerminalPane(vm, terminal, Modifier.weight(1f))
        }
    }
}

@Composable
private fun TerminalPane(vm: IdeViewModel, t: TerminalUi, modifier: Modifier) {
    val scroll = rememberScrollState()
    var input by remember(t.id) { mutableStateOf(TextFieldValue("")) }
    val focus = remember(t.id) { FocusRequester() }
    LaunchedEffect(t.id) { runCatching { focus.requestFocus() } }
    // The console stays dark in every theme, like a real terminal.
    val consoleBg = Palette.Ink
    val consoleText = Color(0xFFE6EDF7)
    val mono = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp, lineHeight = 19.sp, color = consoleText)

    // Follow new output.
    LaunchedEffect(t.output.length) { scroll.scrollTo(scroll.maxValue) }

    fun submit() {
        val line = input.text
        input = TextFieldValue("")
        vm.terminalSubmit(t, line)
    }

    fun history(delta: Int) {
        if (t.history.isEmpty()) return
        val next = when {
            t.historyIndex == -1 && delta < 0 -> t.history.lastIndex
            else -> (t.historyIndex + delta).coerceIn(-1, t.history.lastIndex)
        }
        t.historyIndex = next
        val text = if (next == -1) "" else t.history[next]
        input = TextFieldValue(text, TextRange(text.length))
    }

    Column(modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp).background(consoleBg, RoundedCornerShape(16.dp))) {
        Box(Modifier.weight(1f).fillMaxWidth().verticalScroll(scroll)) {
            SelectionContainer {
                Text(
                    text = t.output,
                    style = mono,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .semantics { contentDescription = "Terminal output" },
                )
            }
        }
        Row(
            Modifier.fillMaxWidth().background(Palette.Panel).padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(if (t.busy) "› " else t.prompt, style = mono.copy(color = Palette.Success))
            BasicTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f).padding(vertical = 12.dp).focusRequester(focus).semantics { contentDescription = "Terminal input" },
                textStyle = mono,
                singleLine = true,
                cursorBrush = SolidColor(Palette.Cyan),
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.None,
                    autoCorrectEnabled = false,
                    imeAction = ImeAction.Send,
                ),
                keyboardActions = KeyboardActions(onSend = { submit() }),
            )
        }
        Row(
            Modifier.fillMaxWidth().background(Palette.Panel).horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            // One-tap commands. They run exactly as if typed.
            listOf("ls", "pwd", "python main.py", "pip list", "help", "clear").forEach { c ->
                ToolButton(c, onClick = { vm.terminalSubmit(t, c) }, enabled = !t.busy, description = "Run $c")
            }
        }
        Row(
            Modifier.fillMaxWidth().background(Palette.Panel, RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp)).padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            ToolButton("Tab", onClick = {
                vm.terminalComplete(t, input.text) { input = TextFieldValue(it, TextRange(it.length)) }
            }, description = "Complete")
            ToolButton("↑", onClick = { history(-1) }, description = "Previous command")
            ToolButton("↓", onClick = { history(+1) }, description = "Next command")
            ToolButton("Ctrl-C", onClick = { vm.terminalInterrupt(t) }, enabled = t.busy, description = "Interrupt running command")
            Box(Modifier.weight(1f))
            ToolButton("Run", onClick = { submit() }, emphasized = true, description = "Run command")
        }
    }
}
