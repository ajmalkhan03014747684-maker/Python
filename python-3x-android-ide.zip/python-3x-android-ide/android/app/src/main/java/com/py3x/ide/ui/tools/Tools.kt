package com.py3x.ide.ui.tools

import com.py3x.ide.ui.components.FullScreen
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.py3x.ide.ui.components.GlowCard
import com.py3x.ide.ui.components.GradientButton
import com.py3x.ide.ui.components.PyMark
import com.py3x.ide.ui.components.SectionHeader
import com.py3x.ide.ui.components.ToolButton
import com.py3x.ide.ui.components.ToolRow
import com.py3x.ide.ui.components.ToolTile
import com.py3x.ide.ui.theme.Palette
import com.py3x.ide.vm.ExampleInfo
import com.py3x.ide.vm.IdeViewModel

/** The Tools hub: every tool the app really has, plus an honest card for the one that cannot exist on Android. */
@Composable
fun ToolsScreen(vm: IdeViewModel, onOpenEditor: () -> Unit, onOpenTerminal: () -> Unit, onOpenSettings: () -> Unit) {
    val gateOn = vm.gateIsOn()
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            Column {
                Text("Tools", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("Everything you need to code, analyse and build.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item { SectionHeader("Develop") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ToolTile("✎", "Editor", Modifier.weight(1f), onClick = onOpenEditor)
                ToolTile("›_", "Terminal", Modifier.weight(1f), tint = Palette.Cyan, onClick = onOpenTerminal)
                ToolTile("⬚", "Packages", Modifier.weight(1f), tint = Palette.Violet) { vm.openTool("packages") }
            }
        }
        item { SectionHeader("Analyse") }
        item {
            ToolRow("◉", "OpenCV Studio", "Open an image, apply filters, edge detection and more.", Palette.Cyan, badge = if (gateOn) "Reward" else null) { vm.openTool("opencv") }
        }
        item {
            ToolRow("∿", "Data Science", "Ready-made examples: analysis, plots, statistics, machine learning.", Palette.Violet, badge = if (gateOn) "Reward" else null) { vm.openTool("datascience") }
        }
        item { SectionHeader("Assist & share") }
        item { ToolRow("✧", "AI Assistant", "Explain, fix or improve your code. Bring your own API key.", Palette.Blue) { vm.openAi() } }
        item { ToolRow("⑂", "GitHub", "Clone a repository, then push or pull your changes.", Palette.Success) { vm.openGithub() } }
        item { SectionHeader("Play") }
        item { ToolRow("▦", "Game Studio", "Text games you can play and edit. pygame cannot run on Android.", Palette.Success) { vm.openTool("game") } }
        item { AccountCard(vm) }
        item { ToolRow("⚙", "Settings", "Theme, editor, run options and ads.", Palette.Blue, onClick = onOpenSettings) }
    }
}

/** The More tab: settings, account-free utilities and plain information about the app. */
@Composable
fun MoreScreen(vm: IdeViewModel, onOpenSettings: () -> Unit) {
    var about by remember { mutableStateOf(false) }
    val endsAt by vm.unlockEndsAt.collectAsState()
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                PyMark(48.dp)
                Column {
                    Text("Python 3.x", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Version ${com.py3x.ide.BuildConfig.VERSION_NAME}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        item { ToolRow("⚙", "Settings", "Theme, editor, run options and ads.", Palette.Blue, onClick = onOpenSettings) }
        item { ToolRow("⬚", "Package Manager", "Install and review Python packages.", Palette.Violet) { vm.openTool("packages") } }
        item { ToolRow("⑂", "GitHub", "Clone, push and pull.", Palette.Success) { vm.openGithub() } }
        item { ToolRow("✧", "AI Assistant", "Offline helper: explains and fixes errors. No key needed.", Palette.Blue) { vm.openAi() } }
        if (vm.gateIsOn()) {
            item {
                ToolRow(
                    "🔓", "Unlock status",
                    if (endsAt > android.os.SystemClock.elapsedRealtime()) "Advanced tools are unlocked right now." else "Advanced tools are locked until you watch a rewarded ad.",
                    Palette.Success,
                ) { vm.gated("Advanced tools") {} }
            }
        }
        item {
            val ctx = androidx.compose.ui.platform.LocalContext.current
            val ads by vm.ads.collectAsState()
            if (ads.adsEnabled && com.py3x.ide.ui.ads.privacyChoicesRequired(ctx)) {
                ToolRow("◐", "Ad privacy choices", "Review or change your consent for ads.", Palette.Cyan) { com.py3x.ide.ui.ads.showPrivacyChoices(ctx) }
            }
        }
        item { ToolRow("i", "About & privacy", "What the app does and does not do with your data.", Palette.Cyan) { about = true } }
    }
    if (about) {
        AlertDialog(
            onDismissRequest = { about = false },
            title = { Text("About Python 3.x") },
            text = {
                Text(
                    "Your code and projects stay on this device. The app only uses the internet when you ask it to: " +
                        "installing packages, GitHub, signing in to an optional account, or showing ads when they are switched on. " +
                        "API keys are stored encrypted with the Android Keystore and are never shown or logged.",
                )
            },
            confirmButton = { TextButton(onClick = { about = false }) { Text("OK") } },
        )
    }
}

/** Data Science examples. Each one creates a real runnable project; machine learning needs the Packs app. */
@Composable
fun DataScienceDialog(vm: IdeViewModel, onClose: () -> Unit) {
    FullScreen(onClose) {
        var items by remember { mutableStateOf<List<ExampleInfo>?>(null) }
        var message by remember { mutableStateOf<String?>(null) }
        LaunchedEffect(Unit) { items = vm.exampleList() }
        Column(Modifier.fillMaxSize().background0().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Data Science", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = onClose) { Text("Close") }
            }
            Text("Pick an example. It becomes a new project you can edit and run.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            message?.let { m -> GlowCard(Modifier.fillMaxWidth()) { Text(m, Modifier.padding(12.dp)) } }
            val list = items
            when {
                list == null -> Text("Loading…")
                list.none { it.category == "data" } -> Text("No examples could be loaded.")
                else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(list.filter { it.category == "data" }, key = { it.key }) { ex ->
                        GlowCard(Modifier.fillMaxWidth(), accent = if (ex.runsIn == "packs") Palette.Violet else Palette.Cyan) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(ex.title, style = MaterialTheme.typography.titleSmall)
                                Text(ex.desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    if (ex.runsIn == "packs") "Runs in the Packs app · needs ${ex.needs}" else "Runs here · needs ${ex.needs}",
                                    style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.tertiary,
                                )
                                GradientButton("Create project", { vm.createExample(ex.key) { message = it } }, Modifier.fillMaxWidth())
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Game Studio. pygame cannot run on Android, so this offers real console games you can play and edit: they run in the
 * normal runner and take input from the Run page.
 */
@Composable
fun GameStudioDialog(vm: IdeViewModel, onClose: () -> Unit) {
    FullScreen(onClose) {
        var items by remember { mutableStateOf<List<ExampleInfo>?>(null) }
        var message by remember { mutableStateOf<String?>(null) }
        LaunchedEffect(Unit) { items = vm.exampleList() }
        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Game Studio", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = onClose) { Text("Close") }
            }
            GlowCard(Modifier.fillMaxWidth(), accent = Palette.Warning) {
                Text(
                    "pygame (graphics windows) cannot run on Android, so these are text games. Each one is a real, editable project: " +
                        "create it, tap RUN and play by typing in the input box on the Run page.",
                    style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(12.dp),
                )
            }
            message?.let { m -> GlowCard(Modifier.fillMaxWidth()) { Text(m, Modifier.padding(12.dp)) } }
            val list = items?.filter { it.category == "game" }
            when {
                list == null -> Text("Loading…")
                list.isEmpty() -> Text("No games could be loaded.")
                else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(list, key = { it.key }) { g ->
                        GlowCard(Modifier.fillMaxWidth(), accent = Palette.Success) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(g.title.removePrefix("Game: "), style = MaterialTheme.typography.titleSmall)
                                Text(g.desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                GradientButton("Create game project", { vm.createExample(g.key) { message = it } }, Modifier.fillMaxWidth())
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Modifier.background0(): Modifier = this.then(Modifier.background(MaterialTheme.colorScheme.background))

/** Optional account. The app is fully usable without it; it is only shown when this build has a backend. */
@Composable
private fun AccountCard(vm: IdeViewModel) {
    val on by vm.backendOn.collectAsState()
    if (!on) {
        GlowCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Account", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(
                    "Online backend is not set up in this build, so accounts are unavailable. " +
                        "Add PY3X_SUPABASE_URL and PY3X_SUPABASE_ANON_KEY as GitHub variables and rebuild.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        return
    }
    val account by vm.account.collectAsState()
    val busy by vm.accountBusy.collectAsState()
    val error by vm.accountError.collectAsState()
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    GlowCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Account", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            val a = account
            if (a != null) {
                Text(a.email + if (a.isAdmin) "  ·  admin" else "")
                Text("Signing in is optional. It never changes what your code can do.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                ToolButton("Sign out", onClick = { vm.signOut() })
            } else {
                androidx.compose.material3.OutlinedTextField(email, { email = it; vm.clearAccountError() }, label = { Text("Email") }, singleLine = true,
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Email), modifier = Modifier.fillMaxWidth())
                androidx.compose.material3.OutlinedTextField(password, { password = it; vm.clearAccountError() }, label = { Text("Password (8+ characters)") }, singleLine = true,
                    visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Password, autoCorrectEnabled = false),
                    modifier = Modifier.fillMaxWidth())
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ToolButton(if (busy) "Please wait…" else "Sign in", onClick = { vm.signIn(email, password, false) }, emphasized = true)
                    ToolButton("Create account", onClick = { vm.signIn(email, password, true) })
                }
            }
        }
    }
}
