package com.py3x.ide.ui.components

import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import com.py3x.ide.ui.theme.LocalReduceMotion

/** Duration guide from the design spec: micro 100-180, small 180-250, page 200-350, large 300-500 ms. */
object Dur {
    const val MICRO = 140
    const val SMALL = 220
    const val PAGE = 280
    const val LARGE = 400
}

/** A tween, or an instant change when the user turned animations off (system setting or in-app). */
@Composable
fun <T> motion(ms: Int): FiniteAnimationSpec<T> = if (LocalReduceMotion.current) snap() else tween(ms)

/** Slight scale-down while pressed. Disabled under reduced motion. */
@Composable
fun Modifier.pressScale(source: MutableInteractionSource): Modifier {
    val pressed by source.collectIsPressedAsState()
    val reduce = LocalReduceMotion.current
    val scale by animateFloatAsState(
        targetValue = if (pressed && !reduce) 0.94f else 1f,
        animationSpec = tween(Dur.MICRO),
        label = "pressScale",
    )
    return this.graphicsLayer {
        scaleX = scale
        scaleY = scale
    }
}

/** Fades and slides content up shortly after the screen appears; [index] staggers siblings. */
@Composable
fun StaggeredIn(index: Int, content: @Composable () -> Unit) {
    val reduce = LocalReduceMotion.current
    var shown by remember { mutableStateOf(reduce) }
    LaunchedEffect(Unit) {
        if (!reduce) delay(index * 50L)
        shown = true
    }
    AnimatedVisibility(
        visible = shown,
        enter = fadeIn(motion(Dur.PAGE)) + slideInVertically(motion(Dur.PAGE)) { it / 8 },
    ) { content() }
}
