package com.py3x.ide.ui.home

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import com.py3x.ide.ui.components.GlowCard
import com.py3x.ide.ui.components.GradientButton
import com.py3x.ide.ui.components.PyMark
import com.py3x.ide.ui.components.SectionHeader
import com.py3x.ide.ui.components.ToolTile
import com.py3x.ide.ui.theme.Palette
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.py3x.ide.ui.components.Dur
import com.py3x.ide.ui.components.NameDialog
import com.py3x.ide.ui.components.StaggeredIn
import com.py3x.ide.ui.components.ToolButton
import com.py3x.ide.ui.components.motion
import com.py3x.ide.ui.components.pressScale
import com.py3x.ide.vm.IdeViewModel
import com.py3x.ide.vm.Project
import java.util.Calendar

private enum class HomeDialog { NEW_PROJECT, NEW_FILE }

@Composable
fun HomeScreen(
    vm: IdeViewModel,
    onOpenProjects: () -> Unit,
    onOpenEditor: () -> Unit,
    onOpenTerminal: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenMore: () -> Unit,
) {
    val projects by vm.projects.collectAsState()
    val recents by vm.recents.collectAsState()
    val current by vm.currentProject.collectAsState()
    var dialog by remember { mutableStateOf<HomeDialog?>(null) }
    val tapTimes = remember { mutableListOf<Long>() }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { vm.importZip(it) }
    }
    val launchImport = { importLauncher.launch(arrayOf("application/zip", "application/octet-stream")) }

    fun newFile() {
        if (current == null) vm.notify("Open or create a project first.") else dialog = HomeDialog.NEW_FILE
    }


    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                StaggeredIn(0) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            PyMark(34.dp)
                            Text("Python 3.x", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            com.py3x.ide.ui.ads.UnlockChip(vm)
                        }
                        Text(
                            greeting(),
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(top = 10.dp).clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null,
                            ) {
                                // Hidden entry: four quick taps open the admin sign-in. No ripple, no hint.
                                val now = System.currentTimeMillis()
                                tapTimes.removeAll { now - it > 3000 }
                                tapTimes.add(now)
                                if (tapTimes.size >= 4) { tapTimes.clear(); vm.adminOpen.value = true }
                            },
                        )
                        Text("Ready to build something amazing?", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            item {
                StaggeredIn(1) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        GradientButton("New Project", { dialog = HomeDialog.NEW_PROJECT }, Modifier.weight(1f), glyph = "＋")
                        GradientButton(
                            "Open Project", onOpenProjects, Modifier.weight(1f), glyph = "▤",
                            colors = listOf(Palette.Violet, Color(0xFF5B3FD6)),
                        )
                    }
                }
            }
            item {
                StaggeredIn(1) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        QuickAction("New Python File", "py", Modifier.weight(1f)) { newFile() }
                        QuickAction("Import Project", "↓", Modifier.weight(1f)) { launchImport() }
                    }
                }
            }
            item { StaggeredIn(2) { SectionHeader("Recent Projects") } }
            if (projects.isEmpty()) {
                item {
                    StaggeredIn(3) {
                        EmptyCard("No projects yet", "Tap New Project to create one. Everything is stored on your device.")
                    }
                }
            }
            items(projects.take(5), key = { it.id }) { p ->
                StaggeredIn(3) {
                    ProjectCard(
                        p,
                        onRun = { vm.selectProject(p); vm.runProject(p); vm.openFile(p.id, p.mainFile); onOpenEditor() },
                        onOpen = { vm.selectProject(p); onOpenProjects() },
                    )
                }
            }
            if (recents.isNotEmpty()) {
                item { StaggeredIn(4) { SectionHeader("Recent Files") } }
                items(recents, key = { "${it.projectId}:${it.rel}" }) { r ->
                    StaggeredIn(4) {
                        GlowCard(Modifier.fillMaxWidth().heightIn(min = 56.dp), onClick = { vm.openFile(r.projectId, r.rel); onOpenEditor() }) {
                            Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                                Text(r.rel, fontFamily = FontFamily.Monospace, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(r.projectName, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
            item { StaggeredIn(5) { SectionHeader("Developer Tools") } }
            item {
                StaggeredIn(5) {
                    val tools = listOf(
                        Triple("⬚", "Packages", { vm.openTool("packages") }),
                        Triple("◉", "OpenCV", { vm.openTool("opencv") }),
                        Triple("∿", "Data Science", { vm.openTool("datascience") }),
                        Triple("✧", "AI Assistant", { vm.openAi() }),
                        Triple("⑂", "GitHub", { vm.openGithub() }),
                        Triple("›_", "Terminal", onOpenTerminal),
                        Triple("⚙", "Settings", onOpenSettings),
                        Triple("⋯", "More", onOpenMore),
                    )
                    val tints = listOf(Palette.Blue, Palette.Cyan, Palette.Violet, Palette.Blue, Palette.Success, Palette.Cyan, Palette.Violet, Palette.Blue)
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        tools.withIndex().chunked(4).forEach { row ->
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                row.forEach { (i, t) -> ToolTile(t.first, t.second, Modifier.weight(1f), tint = tints[i], onClick = t.third) }
                            }
                        }
                    }
                }
            }
            item { com.py3x.ide.ui.ads.AdsBlock(vm) }
        }
        ExpandableFab(
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
            onNewFile = { newFile() },
            onNewProject = { dialog = HomeDialog.NEW_PROJECT },
            onImport = { launchImport() },
            onClone = { vm.openGithub() },
        )
    }

    when (dialog) {
        HomeDialog.NEW_PROJECT -> NameDialog("New project", "", "Create", "Project name", {
            vm.createProject(it); dialog = null; onOpenEditor()
        }, { dialog = null })
        HomeDialog.NEW_FILE -> NameDialog("New Python file", "untitled.py", "Create", "File name", {
            vm.createFile("", it); dialog = null; onOpenEditor()
        }, { dialog = null })
        null -> {}
    }
}

@Composable
private fun QuickAction(label: String, glyph: String, modifier: Modifier, onClick: () -> Unit) {
    GlowCard(modifier.heightIn(min = 52.dp), accent = Palette.Cyan, onClick = onClick) {
        Row(Modifier.padding(12.dp).semantics { contentDescription = label }, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(glyph, color = Palette.Cyan, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.labelLarge, maxLines = 1)
        }
    }
}

private fun greeting(): String = when (Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) {
    in 5..11 -> "Good morning"
    in 12..16 -> "Good afternoon"
    in 17..21 -> "Good evening"
    else -> "Burning the midnight oil?"
}

@Composable
private fun EmptyCard(title: String, body: String) {
    Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(body, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun ProjectCard(p: Project, onRun: () -> Unit, onOpen: () -> Unit) {
    GlowCard(Modifier.fillMaxWidth(), accent = Palette.Violet) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.18f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center,
            ) { Text(p.name.take(1).uppercase(), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.secondary) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(p.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${p.mainFile} · ${relativeTime(p.modifiedAt)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            ToolButton("▶", onClick = onRun, emphasized = true, description = "Quick run ${p.name}")
            Spacer(Modifier.width(6.dp))
            ToolButton("Open", onClick = onOpen, description = "Open ${p.name}")
        }
    }
}

@Composable
private fun ExpandableFab(
    modifier: Modifier,
    onNewFile: () -> Unit,
    onNewProject: () -> Unit,
    onImport: () -> Unit,
    onClone: () -> Unit,
) {
    var open by remember { mutableStateOf(false) }
    val rotation by animateFloatAsState(if (open) 45f else 0f, motion(Dur.SMALL), label = "fabRotation")
    Column(modifier, horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(
            "New File" to onNewFile,
            "New Project" to onNewProject,
            "Import" to onImport,
            "Clone from GitHub" to onClone,
        ).forEach { (label, action) ->
            AnimatedVisibility(
                visible = open,
                enter = fadeIn(motion(Dur.SMALL)) + scaleIn(motion(Dur.SMALL)),
                exit = fadeOut(motion(Dur.MICRO)) + scaleOut(motion(Dur.MICRO)),
            ) {
                ToolButton(label, onClick = { open = false; action() }, modifier = Modifier.alpha(if (label.contains("planned")) 0.7f else 1f))
            }
        }
        FloatingActionButton(
            onClick = { open = !open },
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier.semantics { contentDescription = if (open) "Close actions" else "Create or import" },
        ) { Text("＋", style = MaterialTheme.typography.titleLarge, modifier = Modifier.rotate(rotation)) }
    }
}

internal fun relativeTime(epochSeconds: Double, nowMs: Long = System.currentTimeMillis()): String {
    val diff = (nowMs / 1000.0 - epochSeconds).toLong()
    return when {
        diff < 60 -> "just now"
        diff < 3600 -> "${diff / 60} min ago"
        diff < 86400 -> "${diff / 3600} h ago"
        diff < 7 * 86400 -> "${diff / 86400} d ago"
        else -> "${diff / (7 * 86400)} w ago"
    }
}
