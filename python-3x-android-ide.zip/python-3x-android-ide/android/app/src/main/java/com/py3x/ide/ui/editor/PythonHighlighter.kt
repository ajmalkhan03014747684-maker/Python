package com.py3x.ide.ui.editor

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight

enum class TokenKind { KEYWORD, BUILTIN, STRING, COMMENT, NUMBER, DECORATOR, DEFINITION, SELF }

data class Token(val start: Int, val end: Int, val kind: TokenKind)

/** A syntax problem reported by the Python side (`editor/diagnostics.py`). Lines are 1-based. */
data class Diagnostic(val line: Int, val col: Int, val endLine: Int, val endCol: Int, val message: String)

data class CodeColors(
    val keyword: Color,
    val builtin: Color,
    val string: Color,
    val comment: Color,
    val number: Color,
    val decorator: Color,
    val definition: Color,
    val self: Color,
    val error: Color,
    val bracketMatch: Color,
)

/**
 * Hand-written single-pass tokenizer. It only needs to be fast and forgiving (the user is
 * mid-edit, so the text is often invalid); accuracy for errors comes from Python's own parser.
 */
object PythonHighlighter {
    private val keywords = setOf(
        "False", "None", "True", "and", "as", "assert", "async", "await", "break", "class",
        "continue", "def", "del", "elif", "else", "except", "finally", "for", "from", "global",
        "if", "import", "in", "is", "lambda", "nonlocal", "not", "or", "pass", "raise",
        "return", "try", "while", "with", "yield", "match", "case",
    )
    private val builtins = setOf(
        "print", "len", "range", "int", "str", "float", "bool", "list", "dict", "set", "tuple",
        "input", "open", "enumerate", "zip", "map", "filter", "sorted", "reversed", "sum", "min",
        "max", "abs", "round", "type", "isinstance", "issubclass", "getattr", "setattr", "hasattr",
        "super", "object", "repr", "format", "any", "all", "iter", "next", "id", "hash", "bytes",
        "Exception", "ValueError", "TypeError", "KeyError", "IndexError", "OSError",
    )
    private val stringPrefixes = setOf("r", "b", "f", "u", "rb", "br", "fr", "rf")

    fun tokenize(text: String): List<Token> {
        val out = ArrayList<Token>()
        val n = text.length
        var i = 0
        var afterDef = false
        while (i < n) {
            val c = text[i]
            when {
                c == '#' -> {
                    val end = text.indexOf('\n', i).let { if (it == -1) n else it }
                    out += Token(i, end, TokenKind.COMMENT)
                    i = end
                }
                c == '"' || c == '\'' -> {
                    val end = stringEnd(text, i)
                    out += Token(i, end, TokenKind.STRING)
                    i = end
                }
                c == '@' && isLineStart(text, i) -> {
                    var j = i + 1
                    while (j < n && (text[j].isLetterOrDigit() || text[j] == '_' || text[j] == '.')) j++
                    out += Token(i, j, TokenKind.DECORATOR)
                    i = j
                }
                c.isDigit() -> {
                    var j = i + 1
                    while (j < n && (text[j].isLetterOrDigit() || text[j] == '_' || text[j] == '.')) j++
                    out += Token(i, j, TokenKind.NUMBER)
                    i = j
                }
                c.isLetter() || c == '_' -> {
                    var j = i + 1
                    while (j < n && (text[j].isLetterOrDigit() || text[j] == '_')) j++
                    val word = text.substring(i, j)
                    if (j < n && (text[j] == '"' || text[j] == '\'') && word.lowercase() in stringPrefixes) {
                        val end = stringEnd(text, j)
                        out += Token(i, end, TokenKind.STRING)
                        i = end
                        afterDef = false
                        continue
                    }
                    when {
                        afterDef -> out += Token(i, j, TokenKind.DEFINITION)
                        word in keywords -> out += Token(i, j, TokenKind.KEYWORD)
                        word == "self" || word == "cls" -> out += Token(i, j, TokenKind.SELF)
                        word in builtins -> out += Token(i, j, TokenKind.BUILTIN)
                    }
                    afterDef = word == "def" || word == "class"
                    i = j
                }
                else -> {
                    if (!c.isWhitespace()) afterDef = false
                    i++
                }
            }
        }
        return out
    }

    /** End offset (exclusive) of the string literal that starts at [start] (a quote char). */
    private fun stringEnd(text: String, start: Int): Int {
        val n = text.length
        val q = text[start]
        val triple = text.startsWith("$q$q$q", start)
        var i = start + if (triple) 3 else 1
        while (i < n) {
            val ch = text[i]
            if (ch == '\\') { i += 2; continue }
            if (triple) {
                if (text.startsWith("$q$q$q", i)) return i + 3
            } else {
                if (ch == q) return i + 1
                if (ch == '\n') return i // unterminated single-line string stops at the line end
            }
            i++
        }
        return n
    }

    private fun isLineStart(text: String, i: Int): Boolean {
        var j = i - 1
        while (j >= 0 && (text[j] == ' ' || text[j] == '\t')) j--
        return j < 0 || text[j] == '\n'
    }

    /** Offset of (1-based line, 0-based col), clamped into the text. */
    fun offsetOf(text: String, line: Int, col: Int): Int {
        var offset = 0
        var l = 1
        while (l < line) {
            val nl = text.indexOf('\n', offset)
            if (nl == -1) return text.length
            offset = nl + 1
            l++
        }
        val lineEnd = text.indexOf('\n', offset).let { if (it == -1) text.length else it }
        return (offset + col).coerceIn(offset, lineEnd)
    }

    fun diagnosticRange(text: String, d: Diagnostic): IntRange? {
        if (text.isEmpty()) return null
        val start = offsetOf(text, d.line, d.col).coerceAtMost(text.length - 1)
        var end = offsetOf(text, d.endLine, d.endCol)
        if (end <= start) end = start + 1 // always underline at least one character
        return start until minOf(end, text.length)
    }

    fun annotate(
        text: String,
        colors: CodeColors,
        highlight: Boolean,
        diagnostics: List<Diagnostic> = emptyList(),
        bracketPair: Pair<Int, Int>? = null,
    ): AnnotatedString = buildAnnotatedString {
        append(text)
        if (highlight) {
            for (t in tokenize(text)) {
                val style = when (t.kind) {
                    TokenKind.KEYWORD -> SpanStyle(color = colors.keyword, fontWeight = FontWeight.SemiBold)
                    TokenKind.BUILTIN -> SpanStyle(color = colors.builtin)
                    TokenKind.STRING -> SpanStyle(color = colors.string)
                    TokenKind.COMMENT -> SpanStyle(color = colors.comment, fontStyle = FontStyle.Italic)
                    TokenKind.NUMBER -> SpanStyle(color = colors.number)
                    TokenKind.DECORATOR -> SpanStyle(color = colors.decorator)
                    TokenKind.DEFINITION -> SpanStyle(color = colors.definition, fontWeight = FontWeight.SemiBold)
                    TokenKind.SELF -> SpanStyle(color = colors.self, fontStyle = FontStyle.Italic)
                }
                addStyle(style, t.start, t.end)
            }
        }
        for (d in diagnostics) {
            val r = diagnosticRange(text, d) ?: continue
            addStyle(SpanStyle(background = colors.error.copy(alpha = 0.28f)), r.first, r.last + 1)
        }
        bracketPair?.let { (a, b) ->
            for (p in listOf(a, b)) {
                if (p in 0 until text.length) addStyle(SpanStyle(background = colors.bracketMatch), p, p + 1)
            }
        }
    }
}
