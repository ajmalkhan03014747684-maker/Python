package com.py3x.ide.ui.files

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.py3x.ide.ui.components.ConfirmDialog
import com.py3x.ide.ui.components.FullScreen
import com.py3x.ide.ui.components.GlowCard
import com.py3x.ide.ui.components.GradientButton
import com.py3x.ide.ui.theme.Palette
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import com.py3x.ide.ui.components.NameDialog
import com.py3x.ide.ui.components.ToolButton
import com.py3x.ide.vm.FileClipMode
import com.py3x.ide.vm.FileEntry
import com.py3x.ide.vm.IdeViewModel
import com.py3x.ide.vm.Project
import kotlinx.coroutines.delay

private sealed interface FileDialog {
    data class NewFile(val parent: String) : FileDialog
    data class NewFolder(val parent: String) : FileDialog
    data class Rename(val entry: FileEntry) : FileDialog
    data class Delete(val entry: FileEntry) : FileDialog
    data object NewProject : FileDialog
    data object RenameProject : FileDialog
    data object DeleteProject : FileDialog
    data object Projects : FileDialog
    data object Trash : FileDialog
}

private fun humanSize(n: Long): String = when {
    n < 1024 -> "$n B"
    n < 1024 * 1024 -> "%.1f KB".format(n / 1024.0)
    else -> "%.1f MB".format(n / 1048576.0)
}

/** Badge text and colour for a file or folder, so the type is clear at a glance (not by colour alone: the text says it too). */
private fun fileBadge(e: FileEntry, open: Boolean): Pair<String, Color> {
    if (e.isDir) return (if (open) "▾" else "▸") to Palette.Violet
    return when (e.name.substringAfterLast('.', "").lowercase()) {
        "py" -> "py" to Palette.Blue
        "md", "txt" -> "txt" to Palette.Cyan
        "json", "yaml", "yml", "toml", "cfg", "ini" -> "{ }" to Palette.Warning
        "csv" -> "csv" to Palette.Success
        "png", "jpg", "jpeg", "bmp", "webp", "gif" -> "img" to Palette.Violet
        else -> "•" to Color(0xFF8A94A8)
    }
}

private data class TreeRow(val entry: FileEntry, val depth: Int)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FilesScreen(vm: IdeViewModel, onFileOpened: () -> Unit) {
    val project by vm.currentProject.collectAsState()
    val projects by vm.projects.collectAsState()
    val tree by vm.treeCache.collectAsState()
    val expanded by vm.expanded.collectAsState()
    val favorites by vm.favorites.collectAsState()
    val sort by vm.sort.collectAsState()
    val clip by vm.fileClip.collectAsState()
    val results by vm.searchResults.collectAsState()
    var dialog by remember { mutableStateOf<FileDialog?>(null) }
    var query by remember { mutableStateOf("") }
    var contentSearch by remember { mutableStateOf(false) }
    var sortMenu by remember { mutableStateOf(false) }
    var projectMenu by remember { mutableStateOf(false) }
    var exportTarget by remember { mutableStateOf<Project?>(null) }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { vm.importZip(it) }
    }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        val p = exportTarget
        if (uri != null && p != null) vm.exportProject(p, uri)
        exportTarget = null
    }

    LaunchedEffect(query, contentSearch) {
        delay(250)
        vm.search(query, contentSearch)
    }

    Column(Modifier.fillMaxSize()) {
        // ---- project header
        GlowCard(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), accent = Palette.Violet) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Column(Modifier.weight(1f).combinedClickable(onClick = { dialog = FileDialog.Projects }, onLongClick = {})) {
                Text("PROJECT", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                    (project?.name ?: "Choose a project") + "  ▾",
                    style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.semantics { contentDescription = "Current project. Tap to switch." },
                )
            }
            Box {
                ToolButton("⋮", onClick = { projectMenu = true }, description = "Project menu")
                DropdownMenu(projectMenu, { projectMenu = false }) {
                    DropdownMenuItem(text = { Text("New project") }, onClick = { projectMenu = false; dialog = FileDialog.NewProject })
                    DropdownMenuItem(text = { Text("Import project (.zip)") }, onClick = {
                        projectMenu = false; importLauncher.launch(arrayOf("application/zip", "application/octet-stream"))
                    })
                    if (project != null) {
                        DropdownMenuItem(text = { Text("Rename project") }, onClick = { projectMenu = false; dialog = FileDialog.RenameProject })
                        DropdownMenuItem(text = { Text("Duplicate project") }, onClick = { projectMenu = false; project?.let(vm::duplicateProject) })
                        DropdownMenuItem(text = { Text("Export as .zip") }, onClick = {
                            projectMenu = false
                            exportTarget = project
                            project?.let { exportLauncher.launch("${it.name}.zip") }
                        })
                        DropdownMenuItem(text = { Text("Recently deleted files") }, onClick = { projectMenu = false; vm.loadTrash(); dialog = FileDialog.Trash })
                        DropdownMenuItem(text = { Text("Delete project") }, onClick = { projectMenu = false; dialog = FileDialog.DeleteProject })
                    }
                }
            }
        }
        }

        if (project == null) {
            Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Text("No project selected", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.heightIn(min = 8.dp))
                Text("Create a project or open an existing one.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.heightIn(min = 16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GradientButton("New project", { dialog = FileDialog.NewProject }, glyph = "＋")
                    if (projects.isNotEmpty()) GradientButton("Open project", { dialog = FileDialog.Projects }, glyph = "▤", colors = listOf(Palette.Violet, Color(0xFF5B3FD6)))
                }
            }
        } else {
            // ---- actions + search
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                GradientButton("File", { dialog = FileDialog.NewFile("") }, glyph = "＋", description = "New file")
                GradientButton("Folder", { dialog = FileDialog.NewFolder("") }, glyph = "＋", colors = listOf(Palette.Violet, Color(0xFF5B3FD6)), description = "New folder")
                if (clip != null) ToolButton("Paste", onClick = { vm.paste("") }, description = "Paste into project root")
                Spacer(Modifier.weight(1f))
                Box {
                    ToolButton("Sort: $sort", onClick = { sortMenu = true }, description = "Sort files")
                    DropdownMenu(sortMenu, { sortMenu = false }) {
                        listOf("name", "modified", "size", "type").forEach {
                            DropdownMenuItem(text = { Text(it.replaceFirstChar { c -> c.uppercase() }) }, onClick = { sortMenu = false; vm.setSort(it) })
                        }
                    }
                }
            }
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                placeholder = { Text(if (contentSearch) "Search inside files" else "Search file names") },
                trailingIcon = { TextButton(onClick = { contentSearch = !contentSearch }) { Text(if (contentSearch) "Text ✓" else "Text") } },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
            )

            if (query.isNotBlank()) {
                LazyColumn(Modifier.fillMaxSize()) {
                    if (results.isEmpty()) item { Text("No results", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    items(results) { (rel, line) ->
                        Column(
                            Modifier.fillMaxWidth().heightIn(min = 56.dp)
                                .combinedClickable(onClick = { vm.openFile(project!!.id, rel); onFileOpened() }, onLongClick = {})
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                        ) {
                            Text(rel, fontFamily = FontFamily.Monospace)
                            if (line > 0) Text("line $line", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            } else {
                val rows = remember(tree, expanded) { flatten(tree, expanded, "", 0) }
                LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 16.dp)) {
                    if (rows.isEmpty()) item { Text("This project is empty.", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    items(rows, key = { it.entry.rel }) { row ->
                        FileRow(
                            row = row, isOpen = row.entry.rel in expanded, isFavorite = row.entry.rel in favorites,
                            isMain = row.entry.rel == project?.mainFile, hasClip = clip != null,
                            onClick = {
                                if (row.entry.isDir) vm.toggleFolder(row.entry.rel)
                                else { vm.openFile(project!!.id, row.entry.rel); onFileOpened() }
                            },
                            onNewFile = { dialog = FileDialog.NewFile(row.entry.rel) },
                            onNewFolder = { dialog = FileDialog.NewFolder(row.entry.rel) },
                            onRename = { dialog = FileDialog.Rename(row.entry) },
                            onDelete = { dialog = FileDialog.Delete(row.entry) },
                            onCopy = { vm.clip(row.entry, FileClipMode.COPY) },
                            onCut = { vm.clip(row.entry, FileClipMode.CUT) },
                            onPaste = { vm.paste(row.entry.rel) },
                            onFavorite = { vm.toggleFavorite(row.entry) },
                            onSetMain = { vm.setMainFile(row.entry.rel) },
                        )
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                    }
                }
            }
        }
    }

    // ---- dialogs
    when (val d = dialog) {
        null -> {}
        is FileDialog.NewFile -> NameDialog("New file", "untitled.py", "Create", "File name", { vm.createFile(d.parent, it); dialog = null }, { dialog = null })
        is FileDialog.NewFolder -> NameDialog("New folder", "", "Create", "Folder name", { vm.createFolder(d.parent, it); dialog = null }, { dialog = null })
        is FileDialog.Rename -> NameDialog("Rename", d.entry.name, "Rename", "New name", { vm.renameEntry(d.entry, it); dialog = null }, { dialog = null })
        is FileDialog.Delete -> ConfirmDialog(
            "Delete ${d.entry.name}?",
            "It moves to Recently Deleted, so you can restore it from the project menu.",
            "Delete", { vm.deleteEntry(d.entry); dialog = null }, { dialog = null },
        )
        FileDialog.NewProject -> NameDialog("New project", "", "Create", "Project name", { vm.createProject(it); dialog = null }, { dialog = null })
        FileDialog.RenameProject -> NameDialog("Rename project", project?.name.orEmpty(), "Rename", "Project name", { n -> project?.let { vm.renameProject(it, n) }; dialog = null }, { dialog = null })
        FileDialog.DeleteProject -> ConfirmDialog(
            "Delete \"${project?.name}\"?",
            "The project moves to Recently Deleted and can be restored from Settings.",
            "Delete", { project?.let(vm::deleteProject); dialog = null }, { dialog = null },
        )
        FileDialog.Projects -> ProjectManager(
            vm, projects, project?.id,
            onClose = { dialog = null },
            onNew = { dialog = FileDialog.NewProject },
            onImport = { dialog = null; importLauncher.launch(arrayOf("application/zip", "application/octet-stream")) },
        )
        FileDialog.Trash -> {
            val trash by vm.trash.collectAsState()
            AlertDialog(
                onDismissRequest = { dialog = null },
                title = { Text("Recently deleted") },
                text = {
                    Column {
                        if (trash.isEmpty()) Text("Nothing here.")
                        trash.forEach { t ->
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text((if (t.isDir) "📁 " else "") + t.originalRel, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                TextButton(onClick = { vm.restoreTrash(t) }) { Text("Restore") }
                            }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { dialog = null }) { Text("Close") } },
            )
        }
    }
}

private fun flatten(tree: Map<String, List<FileEntry>>, expanded: Set<String>, rel: String, depth: Int): List<TreeRow> {
    val out = ArrayList<TreeRow>()
    for (e in tree[rel].orEmpty()) {
        out += TreeRow(e, depth)
        if (e.isDir && e.rel in expanded) out += flatten(tree, expanded, e.rel, depth + 1)
    }
    return out
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun androidx.compose.foundation.lazy.LazyItemScope.FileRow(
    row: TreeRow,
    isOpen: Boolean,
    isFavorite: Boolean,
    isMain: Boolean,
    hasClip: Boolean,
    onClick: () -> Unit,
    onNewFile: () -> Unit,
    onNewFolder: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
    onCopy: () -> Unit,
    onCut: () -> Unit,
    onPaste: () -> Unit,
    onFavorite: () -> Unit,
    onSetMain: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    val e = row.entry
    Box(Modifier.animateItem()) {
        Row(
            Modifier.fillMaxWidth().heightIn(min = 52.dp)
                .combinedClickable(onClick = onClick, onLongClick = { menu = true })
                .padding(start = (12 + row.depth * 20).dp, end = 12.dp)
                .semantics { contentDescription = (if (e.isDir) "Folder " else "File ") + e.name + if (isMain) ", main file" else "" },
            verticalAlignment = Alignment.CenterVertically,
        ) {
            val (glyph, tint) = fileBadge(e, isOpen)
            Box(Modifier.size(34.dp).background(tint.copy(alpha = 0.16f), RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
                Text(glyph, color = tint, style = MaterialTheme.typography.labelMedium, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(e.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontFamily = FontFamily.Monospace)
                if (!e.isDir) Text(humanSize(e.size), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (isMain) Text("MAIN", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            if (isFavorite) Text(" ★", color = MaterialTheme.colorScheme.secondary)
        }
        DropdownMenu(menu, { menu = false }) {
            if (e.isDir) {
                DropdownMenuItem(text = { Text("New file here") }, onClick = { menu = false; onNewFile() })
                DropdownMenuItem(text = { Text("New folder here") }, onClick = { menu = false; onNewFolder() })
                if (hasClip) DropdownMenuItem(text = { Text("Paste here") }, onClick = { menu = false; onPaste() })
            }
            DropdownMenuItem(text = { Text("Rename") }, onClick = { menu = false; onRename() })
            DropdownMenuItem(text = { Text("Copy") }, onClick = { menu = false; onCopy() })
            DropdownMenuItem(text = { Text("Cut (move)") }, onClick = { menu = false; onCut() })
            DropdownMenuItem(text = { Text(if (isFavorite) "Remove favorite" else "Add to favorites") }, onClick = { menu = false; onFavorite() })
            if (!e.isDir && e.name.endsWith(".py")) DropdownMenuItem(text = { Text("Set as main file") }, onClick = { menu = false; onSetMain() })
            DropdownMenuItem(text = { Text("Delete") }, onClick = { menu = false; onDelete() })
        }
    }
}

/** Full-screen list of every project: open, run, or start a new one. */
@Composable
private fun ProjectManager(vm: IdeViewModel, projects: List<Project>, currentId: Int?, onClose: () -> Unit, onNew: () -> Unit, onImport: () -> Unit) {
    FullScreen(onClose) {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Projects", style = MaterialTheme.typography.headlineSmall, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, modifier = Modifier.weight(1f))
                    ToolButton("Close", onClose)
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GradientButton("New project", onNew, Modifier.weight(1f), glyph = "＋")
                    GradientButton("Import .zip", onImport, Modifier.weight(1f), glyph = "↓", colors = listOf(Palette.Violet, Color(0xFF5B3FD6)))
                }
            }
            if (projects.isEmpty()) item { Text("No projects yet.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(projects, key = { it.id }) { p ->
                GlowCard(Modifier.fillMaxWidth(), accent = if (p.id == currentId) Palette.Success else Palette.Blue) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(p.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                "${p.mainFile} · ${com.py3x.ide.ui.home.relativeTime(p.modifiedAt)}" + if (p.id == currentId) " · open" else "",
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        ToolButton("Open", onClick = { vm.selectProject(p); onClose() }, description = "Open ${p.name}")
                        Spacer(Modifier.width(6.dp))
                        ToolButton("▶", onClick = { vm.selectProject(p); vm.runProject(p); vm.openFile(p.id, p.mainFile); onClose() }, emphasized = true, description = "Run ${p.name}")
                    }
                }
            }
        }
    }
}
