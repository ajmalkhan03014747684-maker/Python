package com.py3x.ide.packs

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import android.os.ParcelFileDescriptor
import android.os.RemoteException
import androidx.core.os.BundleCompat
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeout
import org.json.JSONObject
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class PacksException(message: String) : Exception(message)

data class PacksInfo(
    val installed: Boolean,
    val python: String = "",
    val packages: List<Pair<String, String>> = emptyList(),
    /** Set when the app is installed but did not answer (for example a version mismatch). */
    val problem: String? = null,
) {
    val ready get() = installed && problem == null
}

class JobResult(val json: JSONObject, val zip: ParcelFileDescriptor?)

/**
 * Talks to the companion "Python 3.x Packs" app over a bound Messenger service.
 * Access is protected by a signature-level permission, so only apps signed with the same key
 * (these two) can use it. One short-lived connection per request keeps the state simple.
 */
class PacksClient(private val context: Context) {

    fun isInstalled(): Boolean =
        runCatching { context.packageManager.getPackageInfo(PACKAGE, 0) }.isSuccess

    private class Conn(val messenger: Messenger, private val connection: ServiceConnection, private val context: Context) {
        @Volatile var onLost: (() -> Unit)? = null
        fun close() { runCatching { context.unbindService(connection) } }
    }

    private suspend fun connect(): Conn = withTimeout(20_000) {
        suspendCancellableCoroutine { cont ->
            var conn: Conn? = null
            val sc = object : ServiceConnection {
                override fun onServiceConnected(name: ComponentName, service: IBinder) {
                    val c = Conn(Messenger(service), this, context)
                    conn = c
                    if (cont.isActive) cont.resume(c) else c.close()
                }
                override fun onServiceDisconnected(name: ComponentName) { conn?.onLost?.invoke() }
                override fun onBindingDied(name: ComponentName) { conn?.onLost?.invoke() }
                override fun onNullBinding(name: ComponentName) {
                    if (cont.isActive) cont.resumeWithException(PacksException("The Packs app did not accept the connection."))
                }
            }
            val intent = Intent().setComponent(ComponentName(PACKAGE, SERVICE))
            val ok = try {
                context.bindService(intent, sc, Context.BIND_AUTO_CREATE)
            } catch (e: SecurityException) {
                false
            }
            if (!ok) {
                runCatching { context.unbindService(sc) }
                cont.resumeWithException(
                    PacksException(
                        "Could not connect to the Packs app. Make sure \"Python 3.x Packs\" is installed and was built together with this app " +
                            "(both apps must be signed with the same key).",
                    ),
                )
            } else {
                cont.invokeOnCancellation { runCatching { context.unbindService(sc) } }
            }
        }
    }

    private fun mainHandler(callback: (Message) -> Unit) = Handler(Looper.getMainLooper()) { m -> callback(m); true }

    suspend fun info(): PacksInfo {
        if (!isInstalled()) return PacksInfo(installed = false)
        return try {
            withTimeout(90_000) {
                val conn = connect()
                try {
                    val raw = suspendCancellableCoroutine<String> { cont ->
                        conn.onLost = { if (cont.isActive) cont.resumeWithException(PacksException("The Packs app stopped unexpectedly.")) }
                        val h = mainHandler { m ->
                            if (!cont.isActive) return@mainHandler
                            when (m.what) {
                                PacksProtocol.MSG_INFO_REPLY -> cont.resume(m.data.getString(PacksProtocol.K_JSON).orEmpty())
                                PacksProtocol.MSG_ERROR -> cont.resumeWithException(PacksException(m.data.getString(PacksProtocol.K_MESSAGE).orEmpty()))
                            }
                        }
                        try {
                            conn.messenger.send(Message.obtain(null, PacksProtocol.MSG_INFO).apply { replyTo = Messenger(h) })
                        } catch (e: RemoteException) {
                            cont.resumeWithException(PacksException("The Packs app could not be reached."))
                        }
                    }
                    val env = JSONObject(raw)
                    if (!env.optBoolean("ok")) return@withTimeout PacksInfo(true, problem = env.optString("error", "Unknown error"))
                    val data = env.getJSONObject("data")
                    if (data.getInt("protocol") != PacksProtocol.VERSION) {
                        return@withTimeout PacksInfo(
                            true, problem = "The Packs app speaks protocol ${data.getInt("protocol")}, this app expects ${PacksProtocol.VERSION}. Update both apps together.",
                        )
                    }
                    val arr = data.getJSONArray("packages")
                    PacksInfo(
                        installed = true,
                        python = data.getString("python"),
                        packages = (0 until arr.length()).map { arr.getJSONObject(it).let { o -> o.getString("name") to o.getString("version") } },
                    )
                } finally {
                    conn.close()
                }
            }
        } catch (e: PacksException) {
            PacksInfo(true, problem = e.message)
        } catch (e: kotlinx.coroutines.TimeoutCancellationException) {
            PacksInfo(true, problem = "The Packs app did not answer in time.")
        }
    }

    /**
     * Sends [zip] (the project) and runs a job. Cancelling the calling coroutine stops the job.
     * Streamed output is delivered through [onOutput] on the main thread.
     */
    suspend fun run(job: String, kind: String, arg: String, zip: File, onOutput: (stream: String, text: String) -> Unit): JobResult {
        val conn = connect()
        try {
            return suspendCancellableCoroutine { cont ->
                conn.onLost = { if (cont.isActive) cont.resumeWithException(PacksException("The Packs app stopped unexpectedly.")) }
                val h = mainHandler { m ->
                    when (m.what) {
                        PacksProtocol.MSG_OUTPUT -> onOutput(m.data.getString(PacksProtocol.K_STREAM).orEmpty(), m.data.getString(PacksProtocol.K_TEXT).orEmpty())
                        PacksProtocol.MSG_FINISH -> if (cont.isActive) {
                            val d = m.data.apply { classLoader = ParcelFileDescriptor::class.java.classLoader }
                            cont.resume(
                                JobResult(
                                    JSONObject(d.getString(PacksProtocol.K_JSON).orEmpty()),
                                    BundleCompat.getParcelable(d, PacksProtocol.K_ZIP, ParcelFileDescriptor::class.java),
                                ),
                            )
                        }
                        PacksProtocol.MSG_ERROR -> if (cont.isActive) {
                            cont.resumeWithException(PacksException(m.data.getString(PacksProtocol.K_MESSAGE).orEmpty()))
                        }
                    }
                }
                val pfd = ParcelFileDescriptor.open(zip, ParcelFileDescriptor.MODE_READ_ONLY)
                val request = Message.obtain(null, PacksProtocol.MSG_RUN).apply {
                    replyTo = Messenger(h)
                    data = Bundle().apply {
                        putString(PacksProtocol.K_JOB, job)
                        putString(PacksProtocol.K_KIND, kind)
                        putString(PacksProtocol.K_ARG, arg)
                        putParcelable(PacksProtocol.K_ZIP, pfd)
                    }
                }
                try {
                    conn.messenger.send(request)
                } catch (e: RemoteException) {
                    cont.resumeWithException(PacksException("The Packs app could not be reached."))
                } finally {
                    runCatching { pfd.close() }
                }
                cont.invokeOnCancellation { runCatching { conn.messenger.send(Message.obtain(null, PacksProtocol.MSG_STOP)) } }
            }
        } finally {
            conn.close()
        }
    }

    companion object {
        const val PACKAGE = "com.py3x.packs"
        const val SERVICE = "com.py3x.packs.PacksService"
    }
}
