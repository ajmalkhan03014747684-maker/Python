# Python calls these Java classes by name through Chaquopy; R8 must not rename or strip them.
-keep class com.py3x.ide.bridge.** { *; }
