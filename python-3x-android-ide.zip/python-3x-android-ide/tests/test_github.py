import base64
import io
import json
import re
import unittest
import zipfile

from github import GitHubClient, GitHubError, GitHubSync
from github.sync import blob_sha
from netutil import HttpClient, NetError, Response
from tests.helpers import AppCase


class FakeGitHub:
    """In-memory GitHub: one repo owner/repo with branches pointing at commits."""

    def __init__(self):
        self.files = {"main.py": b"print('hi')\n", "README.md": b"# demo\n", "lib/util.py": b"X = 1\n"}
        self.commits = {}
        self.blobs = {}
        self.n = 0
        self.branches = {}
        self.calls = []
        self.token_ok = True
        self.branches["main"] = self._commit(dict(self.files))

    def _commit(self, files):
        self.n += 1
        sha = f"{self.n:040x}"
        self.commits[sha] = dict(files)
        return sha

    def transport(self, method, url, headers, body, timeout, max_bytes):
        self.calls.append((method, url, dict(headers)))
        if not self.token_ok:
            return Response(401, {}, b'{"message":"Bad credentials"}')
        path = url.split("api.github.com", 1)[1]
        data = json.loads(body) if body else None
        ok = lambda obj, code=200: Response(code, {}, json.dumps(obj).encode())  # noqa: E731
        if path == "/user":
            return ok({"login": "me", "name": "Me"})
        if path.startswith("/user/repos"):
            return ok([{"owner": {"login": "me"}, "name": "demo", "private": True, "default_branch": "main", "description": None}])
        if path == "/repos/me/demo":
            return ok({"default_branch": "main"})
        m = re.fullmatch(r"/repos/me/demo/git/ref/heads/(.+)", path)
        if m:
            return ok({"object": {"sha": self.branches[m.group(1)]}}) if m.group(1) in self.branches else Response(404, {}, b"{}")
        m = re.fullmatch(r"/repos/me/demo/git/commits/(\w+)", path)
        if m and method == "GET":
            return ok({"tree": {"sha": "tree-" + m.group(1)}})
        m = re.fullmatch(r"/repos/me/demo/zipball/(\w+)", path)
        if m:
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "w") as zf:
                for rel, content in self.commits[m.group(1)].items():
                    zf.writestr(f"me-demo-abc/{rel}", content)
            return Response(200, {}, buf.getvalue())
        if path == "/repos/me/demo/git/blobs":
            raw = base64.b64decode(data["content"])
            sha = blob_sha(raw)
            self.blobs[sha] = raw
            return ok({"sha": sha}, 201)
        if path == "/repos/me/demo/git/trees":
            base = self.commits[data["base_tree"].removeprefix("tree-")]
            files = dict(base)
            for e in data["tree"]:
                if e["sha"] is None:
                    files.pop(e["path"], None)
                else:
                    files[e["path"]] = self.blobs[e["sha"]]
            self.pending_tree = files
            return ok({"sha": "newtree"}, 201)
        if path == "/repos/me/demo/git/commits" and method == "POST":
            assert data["tree"] == "newtree"
            return ok({"sha": self._commit(self.pending_tree)}, 201)
        if path == "/repos/me/demo/git/refs" and method == "POST":
            self.branches[data["ref"].removeprefix("refs/heads/")] = data["sha"]
            return ok({}, 201)
        m = re.fullmatch(r"/repos/me/demo/git/refs/heads/(.+)", path)
        if m and method == "PATCH":
            self.branches[m.group(1)] = data["sha"]
            return ok({})
        return Response(404, {}, b'{"message":"Not Found"}')


class GitHubTests(AppCase):
    def setUp(self):
        super().setUp()
        self.fake = FakeGitHub()
        self.gh = GitHubClient("tok", HttpClient({"api.github.com", "codeload.github.com"}, self.fake.transport))
        self.sync = GitHubSync(self.pm, self.auto, self.tmp)

    def clone(self):
        return self.sync.clone(self.gh, "me", "demo", None, None)

    def test_user_and_repos(self):
        self.assertEqual(self.gh.user()["login"], "me")
        self.assertEqual(self.gh.repos()[0]["name"], "demo")

    def test_clone_creates_linked_project(self):
        p = self.clone()
        d = self.pm.project_dir(p["id"])
        self.assertEqual((d / "lib" / "util.py").read_text(), "X = 1\n")
        self.assertEqual(p["main_file"], "main.py")
        st = self.sync.status(p["id"])
        self.assertTrue(st["linked"] and st["clean"])

    def test_status_detects_changes(self):
        p = self.clone()
        d = self.pm.project_dir(p["id"])
        (d / "main.py").write_text("changed")
        (d / "new.txt").write_text("n")
        (d / "README.md").unlink()
        st = self.sync.status(p["id"])
        self.assertEqual((st["modified"], st["added"], st["deleted"]), (["main.py"], ["new.txt"], ["README.md"]))

    def test_push_commits_changes_and_deletions(self):
        p = self.clone()
        d = self.pm.project_dir(p["id"])
        (d / "main.py").write_text("v2")
        (d / "README.md").unlink()
        (d / "new.txt").write_text("n")
        r = self.sync.push(self.gh, p["id"], "update")
        head = self.fake.commits[self.fake.branches["main"]]
        self.assertEqual(head["main.py"], b"v2")
        self.assertNotIn("README.md", head)
        self.assertEqual(head["new.txt"], b"n")
        self.assertEqual((r["added"], r["modified"], r["deleted"]), (1, 1, 1))
        self.assertTrue(self.sync.status(p["id"])["clean"])

    def test_push_nothing_and_empty_message(self):
        p = self.clone()
        with self.assertRaises(GitHubError):
            self.sync.push(self.gh, p["id"], "x")
        (self.pm.project_dir(p["id"]) / "a.txt").write_text("a")
        with self.assertRaises(GitHubError):
            self.sync.push(self.gh, p["id"], "  ")

    def test_push_refused_when_branch_moved_but_new_branch_works(self):
        p = self.clone()
        (self.pm.project_dir(p["id"]) / "a.txt").write_text("a")
        self.fake.branches["main"] = self.fake._commit({"other": b"1"})  # someone else pushed
        with self.assertRaises(GitHubError) as ctx:
            self.sync.push(self.gh, p["id"], "mine")
        self.assertIn("new commits", str(ctx.exception))
        r = self.sync.push(self.gh, p["id"], "mine", new_branch="work")
        self.assertEqual(r["branch"], "work")
        self.assertEqual(self.fake.commits[self.fake.branches["work"]]["a.txt"], b"a")
        self.assertEqual(self.sync.link(p["id"])["branch"], "work")

    def test_pull_updates_when_clean_and_refuses_when_dirty(self):
        p = self.clone()
        d = self.pm.project_dir(p["id"])
        new = dict(self.fake.commits[self.fake.branches["main"]])
        new["main.py"] = b"remote"
        del new["README.md"]
        self.fake.branches["main"] = self.fake._commit(new)
        (d / "x.txt").write_text("dirty")
        with self.assertRaises(GitHubError):
            self.sync.pull(self.gh, p["id"])
        (d / "x.txt").unlink()
        r = self.sync.pull(self.gh, p["id"])
        self.assertEqual((r["updated"], r["removed"]), (1, 1))
        self.assertEqual((d / "main.py").read_bytes(), b"remote")
        self.assertFalse((d / "README.md").exists())
        self.assertEqual(self.sync.pull(self.gh, p["id"])["updated"], 0)

    def test_bad_token_message(self):
        self.fake.token_ok = False
        with self.assertRaises(GitHubError) as ctx:
            self.gh.user()
        self.assertIn("token", str(ctx.exception))

    def test_validation(self):
        for bad in ("", "a/b", "../x", "a b"):
            with self.assertRaises(GitHubError):
                self.sync.clone(self.gh, bad, "demo", None, None)
        with self.assertRaises(GitHubError):
            self.sync.clone(self.gh, "me", "demo", "bad..branch", None)
        with self.assertRaises(GitHubError):
            GitHubClient("  ")

    def test_unlinked_project(self):
        self.assertFalse(self.sync.status(self.pid)["linked"])
        with self.assertRaises(GitHubError):
            self.sync.push(self.gh, self.pid, "m")


class NetTests(unittest.TestCase):
    def test_https_and_host_allowlist(self):
        c = HttpClient({"api.github.com"}, lambda *a: Response(200))
        for url in ("http://api.github.com/x", "https://evil.example/x", "ftp://api.github.com/x"):
            with self.assertRaises(NetError):
                c.request("GET", url)

    def test_redirect_drops_authorization_on_other_host(self):
        seen = []

        def transport(method, url, headers, body, timeout, max_bytes):
            seen.append((url, "Authorization" in headers))
            if "api.github.com" in url:
                return Response(302, {"location": "https://codeload.github.com/z"})
            return Response(200, {}, b"ok")

        c = HttpClient({"api.github.com", "codeload.github.com"}, transport)
        self.assertEqual(c.request("GET", "https://api.github.com/a", {"Authorization": "Bearer t"}).body, b"ok")
        self.assertEqual(seen, [("https://api.github.com/a", True), ("https://codeload.github.com/z", False)])

    def test_redirect_to_disallowed_host_blocked(self):
        c = HttpClient({"api.github.com"}, lambda *a: Response(302, {"location": "https://evil.example/"}))
        with self.assertRaises(NetError):
            c.request("GET", "https://api.github.com/a")


if __name__ == "__main__":
    unittest.main()
