import tempfile
import unittest
from pathlib import Path

from vision import OPERATIONS, VisionError, VisionStudio
from vision.studio import validate_pipeline

try:
    import cv2
    import numpy as np
except ImportError:  # the logic tests below still run
    cv2 = None


class PipelineValidationTests(unittest.TestCase):
    def test_unknown_op_rejected(self):
        with self.assertRaises(VisionError):
            validate_pipeline([{"op": "rm -rf"}])

    def test_params_clamped_and_defaulted(self):
        (step,) = validate_pipeline([{"op": "blur", "params": {"size": 9999}}])
        self.assertEqual(step["params"]["size"], 51)
        (step,) = validate_pipeline([{"op": "blur"}])
        self.assertEqual(step["params"]["size"], 5)

    def test_bad_shapes(self):
        for bad in ("x", [1], [{"op": "blur", "params": []}], [{"op": "blur", "params": {"size": "7"}}], [{"op": "invert"}] * 21):
            with self.assertRaises(VisionError):
                validate_pipeline(bad)

    def test_operation_catalogue_is_consistent(self):
        studio = VisionStudio(Path("."))
        self.assertEqual({o["op"] for o in studio.operations()}, set(OPERATIONS))

    def test_path_escape_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            s = VisionStudio(Path(d))
            for bad in ("../x.png", "/etc/passwd.png", "notes.txt"):
                with self.assertRaises(VisionError):
                    s._image_path(bad, must_exist=False)


@unittest.skipIf(cv2 is None, "OpenCV not installed on this machine")
class ProcessingTests(unittest.TestCase):
    def setUp(self):
        self._t = tempfile.TemporaryDirectory()
        self.addCleanup(self._t.cleanup)
        self.root = Path(self._t.name)
        img = np.zeros((40, 60, 3), np.uint8)
        img[10:30, 20:40] = (0, 200, 255)
        cv2.imwrite(str(self.root / "in.png"), img)
        self.s = VisionStudio(self.root)

    def test_info(self):
        self.assertEqual(self.s.info("in.png"), {"width": 60, "height": 40, "channels": 3})

    def test_every_operation_runs_with_defaults(self):
        for op in OPERATIONS:
            r = self.s.process("in.png", [{"op": op}], f"out/{op}.png")
            self.assertTrue((self.root / r["out"]).is_file(), op)

    def test_pipeline_and_sizes(self):
        r = self.s.process("in.png", [{"op": "resize", "params": {"percent": 50}}, {"op": "grayscale"}], "o.png")
        self.assertEqual((r["width"], r["height"]), (30, 20))
        out = cv2.imread(str(self.root / "o.png"), cv2.IMREAD_UNCHANGED)
        self.assertEqual(out.ndim, 2)

    def test_edges_find_the_square(self):
        self.s.process("in.png", [{"op": "edges"}], "e.png")
        edges = cv2.imread(str(self.root / "e.png"), cv2.IMREAD_GRAYSCALE)
        self.assertGreater(int((edges > 0).sum()), 20)

    def test_unreadable_image(self):
        (self.root / "bad.png").write_bytes(b"not an image")
        with self.assertRaises(VisionError):
            self.s.process("bad.png", [], "o.png")


class MissingOpenCVTests(unittest.TestCase):
    def test_clear_message_when_cv2_missing(self):
        import sys
        from unittest import mock

        with tempfile.TemporaryDirectory() as d, mock.patch.dict(sys.modules, {"cv2": None}):
            (Path(d) / "a.png").write_bytes(b"x")
            with self.assertRaises(VisionError) as ctx:
                VisionStudio(Path(d)).info("a.png")
            self.assertIn("opencv-python", str(ctx.exception))


class VisionApiTests(unittest.TestCase):
    def test_api_envelopes(self):
        import json

        from main import create_app

        with tempfile.TemporaryDirectory() as d:
            app = create_app(d)
            self.addCleanup(app.shutdown)
            pid = json.loads(app.create_project("V"))["data"]["id"]
            ops = json.loads(app.vision_operations())
            self.assertTrue(ops["ok"] and len(ops["data"]) == len(OPERATIONS))
            path = json.loads(app.vision_project_path(pid))["data"]
            self.assertTrue(Path(path).is_dir())
            bad = json.loads(app.vision_process(pid, "../x.png", "[]", "o.png"))
            self.assertFalse(bad["ok"])
            bad = json.loads(app.vision_process(pid, "a.png", '[{"op":"nope"}]', "o.png"))
            self.assertFalse(bad["ok"])


if __name__ == "__main__":
    unittest.main()
