import tempfile
import threading
import unittest
from pathlib import Path

from debugger import DebugSession

SCRIPT = """\
def add(a, b):
    total = a + b
    return total

x = 1
y = add(x, 2)
print("result", y)
"""


class Driver:
    """Collects events and answers each pause with a scripted command."""

    def __init__(self, tmp, commands):
        self.events, self.commands = [], list(commands)
        self.lock = threading.Lock()
        self.session = DebugSession(tmp, self.on_event)

    def on_event(self, ev):
        with self.lock:
            self.events.append(ev)
        if ev["event"] == "paused":
            # answer from another thread to mimic the UI; the debug thread is waiting for it
            cmd = self.commands.pop(0) if self.commands else "continue"
            threading.Timer(0.01, self.session.command, args=(cmd,)).start()

    def pauses(self):
        return [e for e in self.events if e["event"] == "paused"]

    def output(self):
        return "".join(e["text"] for e in self.events if e["event"] == "output")


class DebuggerTests(unittest.TestCase):
    def setUp(self):
        self._t = tempfile.TemporaryDirectory()
        self.addCleanup(self._t.cleanup)
        self.root = Path(self._t.name)
        (self.root / "main.py").write_text(SCRIPT)

    def run_debug(self, commands, breakpoints, **kw):
        d = Driver(self.root, commands)
        d.session.start("main.py", breakpoints, **kw)
        self.assertTrue(d.session.join(10), "debug session did not finish")
        return d

    def test_breakpoint_hit_with_variables(self):
        d = self.run_debug(["continue"], {"main.py": [6]})
        p = d.pauses()
        self.assertEqual([e["line"] for e in p], [6])
        self.assertEqual(p[0]["variables"]["x"], "1")
        self.assertIn("result 3", d.output())

    def test_breakpoint_inside_function_shows_stack_and_locals(self):
        d = self.run_debug(["continue"], {"main.py": [3]})
        p = d.pauses()[0]
        self.assertEqual(p["function"], "add")
        self.assertEqual(p["variables"]["total"], "3")
        self.assertEqual([s["function"] for s in p["stack"]][:2], ["add", "<module>"])

    def test_step_over_and_out(self):
        d = self.run_debug(["over", "continue"], {"main.py": [6]})
        self.assertEqual([e["line"] for e in d.pauses()], [6, 7])
        d = self.run_debug(["step", "out", "continue"], {"main.py": [6]})
        self.assertEqual(d.pauses()[1]["function"], "add")

    def test_stop_ends_session(self):
        d = self.run_debug(["stop"], {"main.py": [6]})
        self.assertNotIn("result 3", d.output())
        self.assertEqual(d.events[-1]["event"], "finished")

    def test_stop_on_entry(self):
        d = self.run_debug(["continue"], {}, stop_on_entry=True)
        self.assertEqual(d.pauses()[0]["line"], 1)

    def test_error_is_reported(self):
        (self.root / "main.py").write_text("x = 1\nraise ValueError('boom')\n")
        d = self.run_debug([], {})
        fin = d.events[-1]
        self.assertEqual(fin["exit_code"], 1)
        self.assertIn("ValueError", fin["error"])
        self.assertIn("boom", d.output())

    def test_syntax_error(self):
        (self.root / "main.py").write_text("def (:\n")
        d = self.run_debug([], {})
        self.assertIn("SyntaxError", d.events[-1]["error"])

    def test_rejects_bad_input(self):
        s = DebugSession(self.root, lambda e: None)
        with self.assertRaises(ValueError):
            s.start("../escape.py")
        with self.assertRaises(ValueError):
            s.command("explode")

    def test_cwd_restored(self):
        import os
        before = os.getcwd()
        self.run_debug([], {})
        self.assertEqual(os.getcwd(), before)


if __name__ == "__main__":
    unittest.main()
