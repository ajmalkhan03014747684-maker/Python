"""Test package. Adds ``python/`` (the Chaquopy source root) to sys.path."""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PY_SRC = ROOT / "python"
if str(PY_SRC) not in sys.path:
    sys.path.insert(0, str(PY_SRC))

# Safety net: if any test ever hangs, dump every thread's stack and exit instead of running forever.
import faulthandler as _fh

_fh.dump_traceback_later(600, exit=True)
