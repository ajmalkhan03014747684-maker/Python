import zipfile

from projects import PathError
from projects.paths import resolve_inside, validate_name

from .helpers import AppCase


class ProjectTests(AppCase):
    def test_create_has_runnable_main(self):
        self.assertEqual(self.project["main_file"], "main.py")
        text = self.pm.read_file(self.pid, "main.py")["content"]
        self.assertIn("Hello from Python 3.x", text)

    def test_unique_slugs(self):
        second = self.pm.create_project("Demo")
        self.assertNotEqual(second["slug"], self.project["slug"])

    def test_rename_project_keeps_files(self):
        self.pm.rename_project(self.pid, "Renamed")
        self.assertEqual(self.pm.get_project(self.pid)["name"], "Renamed")
        self.pm.read_file(self.pid, "main.py")

    def test_duplicate_copies_files(self):
        self.pm.create_file(self.pid, "a/b.txt", "hi")
        dup = self.pm.duplicate_project(self.pid)
        self.assertEqual(self.pm.read_file(dup["id"], "a/b.txt")["content"], "hi")
        self.assertNotEqual(dup["id"], self.pid)

    def test_delete_is_soft_and_restorable(self):
        self.pm.create_file(self.pid, "keep.txt", "data")
        self.pm.delete_project(self.pid)
        self.assertEqual(self.pm.list_projects(), [])
        self.assertEqual(len(self.pm.list_deleted_projects()), 1)
        restored = self.pm.restore_project(self.pid)
        self.assertEqual(self.pm.read_file(restored["id"], "keep.txt")["content"], "data")

    def test_purge_requires_trash(self):
        with self.assertRaises(PathError):
            self.pm.purge_project(self.pid)
        self.pm.delete_project(self.pid)
        self.pm.purge_project(self.pid)
        self.assertEqual(self.pm.list_deleted_projects(), [])

    def test_export_import_roundtrip(self):
        self.pm.create_file(self.pid, "pkg/mod.py", "x = 1")
        zpath = self.pm.export_project(self.pid, self.tmp / "out.zip")
        imported = self.pm.import_project(zpath, "Imported")
        self.assertEqual(self.pm.read_file(imported["id"], "pkg/mod.py")["content"], "x = 1")
        self.assertEqual(imported["main_file"], "main.py")

    def test_import_rejects_zip_slip(self):
        evil = self.tmp / "evil.zip"
        with zipfile.ZipFile(evil, "w") as zf:
            zf.writestr("../escape.txt", "no")
        with self.assertRaises(PathError):
            self.pm.import_project(evil)
        self.assertFalse((self.tmp / "escape.txt").exists())

    def test_import_rejects_non_zip(self):
        bad = self.tmp / "bad.zip"
        bad.write_text("not a zip")
        with self.assertRaises(PathError):
            self.pm.import_project(bad)


class FileTests(AppCase):
    def test_create_read_write(self):
        self.pm.create_file(self.pid, "notes.md", "# hi")
        self.assertEqual(self.pm.read_file(self.pid, "notes.md")["content"], "# hi")
        digest = self.pm.write_file(self.pid, "notes.md", "# changed")
        self.assertEqual(self.pm.read_file(self.pid, "notes.md")["hash"], digest)

    def test_create_duplicate_fails(self):
        with self.assertRaises(PathError):
            self.pm.create_file(self.pid, "main.py")

    def test_folders_and_listing_order(self):
        self.pm.create_folder(self.pid, "zdir")
        self.pm.create_file(self.pid, "b.py")
        self.pm.create_file(self.pid, "a.py")
        names = [e["name"] for e in self.pm.list_dir(self.pid)]
        self.assertEqual(names, ["zdir", "a.py", "b.py", "main.py"])

    def test_sort_by_type_and_unknown_sort(self):
        self.pm.create_file(self.pid, "x.txt")
        self.pm.create_file(self.pid, "y.json")
        names = [e["name"] for e in self.pm.list_dir(self.pid, sort="type")]
        self.assertEqual(names, ["y.json", "main.py", "x.txt"])
        with self.assertRaises(PathError):
            self.pm.list_dir(self.pid, sort="bogus")

    def test_rename_updates_recent_and_favorites(self):
        self.pm.touch_recent(self.pid, "main.py")
        self.pm.toggle_favorite(self.pid, "main.py")
        self.pm.rename(self.pid, "main.py", "app.py")
        self.assertEqual(self.pm.recent_files()[0]["rel"], "app.py")
        self.assertEqual(self.pm.favorites(self.pid), ["app.py"])

    def test_move_and_copy(self):
        self.pm.create_folder(self.pid, "sub")
        self.pm.create_file(self.pid, "f.txt", "1")
        self.pm.copy(self.pid, "f.txt", "")
        self.assertTrue(self.pm.read_file(self.pid, "f copy.txt"))
        self.pm.move(self.pid, "f.txt", "sub")
        self.assertEqual(self.pm.read_file(self.pid, "sub/f.txt")["content"], "1")

    def test_cannot_move_folder_into_itself(self):
        self.pm.create_folder(self.pid, "a/b")
        with self.assertRaises(PathError):
            self.pm.move(self.pid, "a", "a/b")

    def test_delete_goes_to_trash_and_restores(self):
        self.pm.create_file(self.pid, "gone.txt", "bye")
        tid = self.pm.delete(self.pid, "gone.txt")
        with self.assertRaises(PathError):
            self.pm.read_file(self.pid, "gone.txt")
        self.assertEqual(len(self.pm.list_trash(self.pid)), 1)
        self.pm.restore_from_trash(self.pid, tid)
        self.assertEqual(self.pm.read_file(self.pid, "gone.txt")["content"], "bye")

    def test_trash_not_listed_in_tree(self):
        self.pm.create_file(self.pid, "t.txt")
        self.pm.delete(self.pid, "t.txt")
        self.assertNotIn(".py3x_trash", [e["name"] for e in self.pm.list_dir(self.pid)])

    def test_search_by_name_and_content(self):
        self.pm.create_file(self.pid, "alpha.py", "needle = 1\n")
        self.assertEqual(self.pm.search_files(self.pid, "alph")[0]["rel"], "alpha.py")
        hits = self.pm.search_files(self.pid, "needle", content=True)
        self.assertEqual((hits[0]["rel"], hits[0]["line"]), ("alpha.py", 1))

    def test_binary_and_non_utf8_refused(self):
        path = self.pm.project_dir(self.pid) / "bin.dat"
        path.write_bytes(b"\x00\x01\x02")
        with self.assertRaises(PathError):
            self.pm.read_file(self.pid, "bin.dat")
        (self.pm.project_dir(self.pid) / "lat.txt").write_bytes(b"caf\xe9")
        with self.assertRaises(PathError):
            self.pm.read_file(self.pid, "lat.txt")

    def test_large_file_refused(self):
        big = self.pm.project_dir(self.pid) / "big.txt"
        big.write_text("x" * (2 * 1024 * 1024 + 1))
        with self.assertRaises(PathError):
            self.pm.read_file(self.pid, "big.txt")

    def test_crlf_normalized(self):
        (self.pm.project_dir(self.pid) / "w.txt").write_bytes(b"a\r\nb\r\n")
        self.assertEqual(self.pm.read_file(self.pid, "w.txt")["content"], "a\nb\n")


class PathSafetyTests(AppCase):
    def test_traversal_rejected(self):
        for bad in ("../x", "a/../../x", "/etc/passwd", "~/x", "C:/x", ".py3x_trash/1/x"):
            with self.subTest(bad=bad), self.assertRaises(PathError):
                self.pm.read_file(self.pid, bad)

    def test_symlink_escape_rejected(self):
        outside = self.tmp / "secret.txt"
        outside.write_text("secret")
        link = self.pm.project_dir(self.pid) / "link.txt"
        try:
            link.symlink_to(outside)
        except OSError:
            self.skipTest("symlinks unavailable")
        with self.assertRaises(PathError):
            self.pm.read_file(self.pid, "link.txt")

    def test_bad_names(self):
        for bad in ("", ".", "..", "a/b", "x\x00y", "n" * 300, ".py3x_trash"):
            with self.subTest(bad=bad), self.assertRaises(PathError):
                validate_name(bad)

    def test_resolve_inside_allows_nested(self):
        root = self.pm.project_dir(self.pid)
        self.assertEqual(resolve_inside(root, "a/b.py"), root.resolve() / "a" / "b.py")
