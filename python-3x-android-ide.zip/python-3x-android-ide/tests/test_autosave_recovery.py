from autosave import MAX_VERSIONS
from projects import content_hash

from .helpers import AppCase


class AutosaveTests(AppCase):
    def test_draft_does_not_touch_disk(self):
        base = self.pm.read_file(self.pid, "main.py")
        self.auto.update_draft(self.pid, "main.py", "print(1)\n", base["hash"])
        self.assertEqual(self.pm.read_file(self.pid, "main.py")["content"], base["content"])
        self.assertTrue(self.auto.has_unsaved_changes(self.pid, "main.py"))

    def test_draft_equal_to_disk_is_not_unsaved(self):
        base = self.pm.read_file(self.pid, "main.py")
        self.auto.update_draft(self.pid, "main.py", base["content"], base["hash"])
        self.assertFalse(self.auto.has_unsaved_changes(self.pid, "main.py"))

    def test_commit_writes_clears_draft_and_versions(self):
        self.auto.update_draft(self.pid, "main.py", "x = 1\n", "")
        result = self.auto.commit(self.pid, "main.py", "x = 1\n")
        self.assertEqual(result["hash"], content_hash("x = 1\n"))
        self.assertIsNone(self.auto.get_draft(self.pid, "main.py"))
        self.assertEqual(self.pm.read_file(self.pid, "main.py")["content"], "x = 1\n")
        self.assertEqual(len(self.auto.list_versions(self.pid, "main.py")), 1)

    def test_identical_content_not_versioned_twice(self):
        self.auto.commit(self.pid, "main.py", "a\n")
        self.auto.commit(self.pid, "main.py", "a\n")
        self.assertEqual(len(self.auto.list_versions(self.pid, "main.py")), 1)

    def test_version_history_pruned(self):
        for i in range(MAX_VERSIONS + 10):
            self.auto.commit(self.pid, "main.py", f"v{i}\n")
        versions = self.auto.list_versions(self.pid, "main.py")
        self.assertEqual(len(versions), MAX_VERSIONS)
        newest = self.auto.get_version(versions[0]["id"])["content"]
        self.assertEqual(newest, f"v{MAX_VERSIONS + 9}\n")

    def test_commit_all_drafts(self):
        self.pm.create_file(self.pid, "b.py", "old")
        self.auto.update_draft(self.pid, "main.py", "m\n", "")
        self.auto.update_draft(self.pid, "b.py", "new", "")
        self.assertEqual(sorted(self.auto.commit_all_drafts(self.pid)), ["b.py", "main.py"])
        self.assertEqual(self.pm.read_file(self.pid, "b.py")["content"], "new")
        self.assertEqual(self.auto.list_drafts(), [])

    def test_discard_keeps_text_in_history(self):
        self.auto.update_draft(self.pid, "main.py", "precious\n", "")
        self.auto.discard_draft(self.pid, "main.py")
        self.assertIsNone(self.auto.get_draft(self.pid, "main.py"))
        versions = self.auto.list_versions(self.pid, "main.py")
        self.assertEqual(versions[0]["reason"], "discarded_draft")
        self.assertEqual(self.auto.get_version(versions[0]["id"])["content"], "precious\n")

    def test_deleting_file_moves_its_draft_to_history(self):
        self.pm.create_file(self.pid, "gone.py", "disk")
        self.auto.update_draft(self.pid, "gone.py", "unsaved edit", "")
        self.pm.delete(self.pid, "gone.py")
        self.assertIsNone(self.auto.get_draft(self.pid, "gone.py"))
        self.assertEqual(self.rec.scan()["items"], [])  # not offered for recovery
        versions = self.auto.list_versions(self.pid, "gone.py")
        self.assertEqual(versions[0]["reason"], "deleted_draft")
        self.assertEqual(self.auto.get_version(versions[0]["id"])["content"], "unsaved edit")

    def test_atomic_write_leaves_no_temp_files(self):
        self.auto.commit(self.pid, "main.py", "z\n")
        names = [p.name for p in self.pm.project_dir(self.pid).iterdir()]
        self.assertFalse([n for n in names if n.startswith(".tmp-")])


class RecoveryTests(AppCase):
    def test_clean_exit_not_reported_as_crash(self):
        self.assertFalse(self.rec.begin_session())
        self.rec.end_session()
        self.assertFalse(self.rec.begin_session())

    def test_unclean_exit_reported(self):
        self.rec.begin_session()  # app "crashes": end_session never called
        again = type(self.rec)(self.db, self.pm, self.auto)
        self.assertTrue(again.begin_session())

    def test_scan_lists_only_real_changes(self):
        base = self.pm.read_file(self.pid, "main.py")
        self.auto.update_draft(self.pid, "main.py", base["content"], base["hash"])
        self.pm.create_file(self.pid, "x.py", "1")
        self.auto.update_draft(self.pid, "x.py", "2", "")
        scan = self.rec.scan()
        self.assertEqual([i["rel"] for i in scan["items"]], ["x.py"])

    def test_restore_writes_draft_and_keeps_old_version(self):
        self.pm.create_file(self.pid, "x.py", "disk")
        self.auto.update_draft(self.pid, "x.py", "recovered", "")
        self.rec.restore(self.pid, "x.py")
        self.assertEqual(self.pm.read_file(self.pid, "x.py")["content"], "recovered")
        contents = [self.auto.get_version(v["id"])["content"] for v in self.auto.list_versions(self.pid, "x.py")]
        self.assertIn("disk", contents)

    def test_diff_shows_changes(self):
        self.pm.create_file(self.pid, "x.py", "a\nb\n")
        self.auto.update_draft(self.pid, "x.py", "a\nc\n", "")
        diff = self.rec.diff(self.pid, "x.py")
        self.assertIn("-b", diff)
        self.assertIn("+c", diff)

    def test_discard_is_non_destructive(self):
        self.pm.create_file(self.pid, "x.py", "disk")
        self.auto.update_draft(self.pid, "x.py", "draft", "")
        self.rec.discard(self.pid, "x.py")
        self.assertEqual(self.pm.read_file(self.pid, "x.py")["content"], "disk")
        self.assertEqual(len(self.auto.list_versions(self.pid, "x.py")), 1)

    def test_draft_survives_reopening_database(self):
        from autosave import AutosaveService
        from projects import ProjectManager
        from storage import Database

        self.auto.update_draft(self.pid, "main.py", "unsaved work\n", "")
        self.db.close()
        db2 = Database(self.tmp / "ide.db")
        self.addCleanup(db2.close)
        auto2 = AutosaveService(db2, ProjectManager(db2, self.tmp / "projects"))
        self.assertEqual(auto2.get_draft(self.pid, "main.py")["content"], "unsaved work\n")
        self.db = db2  # let tearDown close cleanly
