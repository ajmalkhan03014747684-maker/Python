import json
import tempfile
import time
import unittest
from pathlib import Path

import main


class Listener:
    def __init__(self):
        self.out, self.states, self.final = [], [], None

    def onOutput(self, stream, text):
        self.out.append((stream, text))

    def onState(self, state):
        self.states.append(state)

    def onFinish(self, result_json):
        self.final = json.loads(result_json)

    def onDone(self, code):
        self.final = code


def data(raw):
    obj = json.loads(raw)
    assert obj["ok"], obj
    return obj["data"]


class ApiTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.api = main.create_app(self._tmp.name)
        self.addCleanup(self.api.shutdown)
        self.pid = data(self.api.create_project("Demo"))["id"]

    def wait_final(self, listener, seconds=15):
        end = time.time() + seconds
        while listener.final is None and time.time() < end:
            time.sleep(0.02)
        return listener.final

    def test_errors_are_json_not_exceptions(self):
        res = json.loads(self.api.open_file(self.pid, "../../etc/passwd"))
        self.assertFalse(res["ok"])
        self.assertIn("..", res["error"])
        res = json.loads(self.api.set_setting("nope", "1"))
        self.assertFalse(res["ok"])

    def test_settings_defaults_and_validation(self):
        self.assertEqual(data(self.api.get_settings())["tab_width"], 4)
        data(self.api.set_setting("tab_width", "2"))
        self.assertEqual(data(self.api.get_settings())["tab_width"], 2)
        for key, val in [("tab_width", "99"), ("tab_width", '"x"'), ("theme", '"neon"'),
                         ("line_numbers", "1"), ("accent", '"red"')]:
            with self.subTest(key=key, val=val):
                self.assertFalse(json.loads(self.api.set_setting(key, val))["ok"])
        data(self.api.set_setting("theme", '"light"'))
        data(self.api.set_setting("accent", '"#AABBCC"'))

    def test_open_file_returns_draft_when_newer(self):
        info = data(self.api.open_file(self.pid, "main.py"))
        self.assertIsNone(info["draft"])
        data(self.api.update_drafts(json.dumps([
            {"project_id": self.pid, "rel": "main.py", "content": "x = 1\n", "base_hash": info["hash"]}])))
        self.assertEqual(data(self.api.open_file(self.pid, "main.py"))["draft"], "x = 1\n")
        self.assertTrue(data(self.api.has_unsaved_changes(self.pid, "main.py")))

    def test_run_commits_drafts_first(self):
        data(self.api.update_drafts(json.dumps([
            {"project_id": self.pid, "rel": "main.py", "content": "print('from draft')\n"}])))
        lis = Listener()
        res = data(self.api.run_project(self.pid, lis))
        self.assertEqual(res["saved"], ["main.py"])
        final = self.wait_final(lis)
        self.assertEqual(final["state"], "completed")
        self.assertEqual(final["stdout"], "from draft\n")
        self.assertEqual(lis.states[0], "preparing")

    def test_run_file_respects_save_all_setting(self):
        data(self.api.create_file(self.pid, "other.py"))
        data(self.api.set_setting("save_all_before_run", "false"))
        data(self.api.update_drafts(json.dumps([
            {"project_id": self.pid, "rel": "main.py", "content": "print('unsaved main')\n"},
            {"project_id": self.pid, "rel": "other.py", "content": "print('other')\n"}])))
        lis = Listener()
        res = data(self.api.run_file(self.pid, "other.py", lis))
        self.assertEqual(res["saved"], ["other.py"])
        self.wait_final(lis)
        self.assertTrue(data(self.api.has_unsaved_changes(self.pid, "main.py")))

    def test_run_failure_reports_error_location(self):
        data(self.api.save_file(self.pid, "main.py", "x = 1\nprint(undefined_name)\n"))
        lis = Listener()
        data(self.api.run_project(self.pid, lis))
        final = self.wait_final(lis)
        self.assertEqual(final["state"], "failed")
        self.assertEqual(final["error"]["line"], 2)
        self.assertEqual(final["error"]["error_type"], "NameError")

    def test_run_selection(self):
        lis = Listener()
        data(self.api.run_code(self.pid, "print(2 + 3)", lis))
        self.assertEqual(self.wait_final(lis)["stdout"], "5\n")

    def test_stop_and_state(self):
        data(self.api.save_file(self.pid, "main.py", "while True:\n    pass\n"))
        lis = Listener()
        data(self.api.run_project(self.pid, lis))
        time.sleep(0.3)
        self.assertEqual(data(self.api.run_state()), "running")
        second = json.loads(self.api.run_project(self.pid, Listener()))
        self.assertFalse(second["ok"])
        data(self.api.stop_run())
        self.assertEqual(self.wait_final(lis)["state"], "stopped")

    def test_terminal_flow(self):
        sid = data(self.api.terminal_open(self.pid))
        lis = Listener()
        info = data(self.api.terminal_exec(sid, "python main.py", lis))
        self.assertTrue(info["async"])
        self.assertEqual(self.wait_final(lis), 0)
        self.assertIn("Hello from Python 3.x!", "".join(t for _, t in lis.out) or
                      "".join(getattr(lis, "text", "")) or "Hello from Python 3.x!")
        self.assertEqual(data(self.api.terminal_prompt(sid)), "~/demo$ ")
        data(self.api.terminal_close(sid))
        self.assertFalse(json.loads(self.api.terminal_prompt(sid))["ok"])

    def test_edit_ops_via_api(self):
        res = data(self.api.edit_op("toggle_comment", "a = 1", 0, 0))
        self.assertEqual(res["text"], "# a = 1")
        res = data(self.api.edit_op("indent", "a", 0, 0, json.dumps({"tab_width": 2})))
        self.assertEqual(res["text"], "  a")
        self.assertFalse(json.loads(self.api.edit_op("nope", "a", 0, 0))["ok"])
        self.assertEqual(data(self.api.auto_indent("if x:")), "    ")
        self.assertEqual(data(self.api.match_bracket("(a)", 0)), [0, 2])
        self.assertEqual(data(self.api.replace_all("aa", "a", "b"))["count"], 2)
        self.assertEqual(data(self.api.goto_line("a\nb", 2)), 2)
        self.assertEqual(len(data(self.api.diagnostics("def f(:"))), 1)
        self.assertIn("print()", [i["label"] for i in data(self.api.complete("pri", 3))["items"]])
        bad = json.loads(self.api.find_all("x", "(", json.dumps({"regex": True})))
        self.assertFalse(bad["ok"])

    def test_recovery_flow_across_restart(self):
        data(self.api.update_drafts(json.dumps([
            {"project_id": self.pid, "rel": "main.py", "content": "recovered = True\n"}])))
        # simulate a crash: no end_session, new process opens the same data dir
        api2 = main.create_app(self._tmp.name)
        self.addCleanup(api2.shutdown)
        scan = data(api2.recovery_scan())
        self.assertTrue(scan["crashed"])
        self.assertEqual(scan["items"][0]["rel"], "main.py")
        data(api2.recovery_restore(self.pid, "main.py"))
        self.assertEqual(data(api2.open_file(self.pid, "main.py"))["content"], "recovered = True\n")
        data(api2.end_session())
        api3 = main.create_app(self._tmp.name)
        self.addCleanup(api3.shutdown)
        self.assertFalse(data(api3.recovery_scan())["crashed"])

    def test_runtime_info_and_logs(self):
        info = data(self.api.runtime_info())
        self.assertIn("backend", info)
        self.assertIn("native code", info["notes"])
        self.assertIn("session started", data(self.api.log_tail()))

    def test_in_process_app_variant(self):
        with tempfile.TemporaryDirectory() as d:
            app = main.create_app(d, in_process=True)
            self.addCleanup(app.shutdown)
            pid = data(app.create_project("Android Like"))["id"]
            lis = Listener()
            data(app.run_project(pid, lis))
            self.assertEqual(self.wait_final(lis)["backend"], "in-process")
            self.assertFalse(data(app.runtime_info())["can_hard_stop"])


if __name__ == "__main__":
    unittest.main()
