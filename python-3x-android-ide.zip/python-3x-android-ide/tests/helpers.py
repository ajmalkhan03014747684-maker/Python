import tempfile
import unittest
from pathlib import Path

from autosave import AutosaveService
from projects import ProjectManager
from recovery import RecoveryManager
from storage import Database


class AppCase(unittest.TestCase):
    """Fresh database + projects folder per test."""

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.tmp = Path(self._tmp.name)
        self.db = Database(self.tmp / "ide.db")
        self.addCleanup(self.db.close)
        self.pm = ProjectManager(self.db, self.tmp / "projects")
        self.auto = AutosaveService(self.db, self.pm)
        self.rec = RecoveryManager(self.db, self.pm, self.auto)
        self.project = self.pm.create_project("Demo")
        self.pid = self.project["id"]
