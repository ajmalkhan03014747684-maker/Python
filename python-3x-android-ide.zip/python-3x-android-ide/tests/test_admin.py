import json
import tempfile
import unittest
from pathlib import Path

from admin import AdminService
from admin.service import AdminError, DEFAULT_SALT, DEFAULT_HASH, _hash
from main import create_app
from storage import Database

SALT = "00112233445566778899aabbccddeeff"


class Clock:
    def __init__(self):
        self.t = 1000.0

    def __call__(self):
        return self.t


class AdminTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.db = Database(Path(self._tmp.name) / "a.db")
        self.addCleanup(self.db.close)
        self.clock = Clock()
        self.svc = AdminService(self.db, self.clock, SALT, _hash("initial-pass", SALT, 1000), iterations=1000)

    def test_login_ok_and_wrong(self):
        self.assertTrue(self.svc.login("initial-pass"))
        with self.assertRaises(AdminError):
            self.svc.login("nope")

    def test_lockout_after_five_failures_then_expires(self):
        for _ in range(4):
            with self.assertRaises(AdminError):
                self.svc.login("bad")
        with self.assertRaises(AdminError):
            self.svc.login("bad")
        with self.assertRaises(AdminError) as ctx:
            self.svc.login("initial-pass")  # correct password still refused while locked
        self.assertIn("Too many", str(ctx.exception))
        self.clock.t += 31
        self.assertTrue(self.svc.login("initial-pass"))

    def test_session_expires(self):
        token = self.svc.login("initial-pass")
        self.svc.require(token)
        self.clock.t += 16 * 60
        with self.assertRaises(AdminError):
            self.svc.require(token)

    def test_requires_token(self):
        with self.assertRaises(AdminError):
            self.svc.set_ads_config("bogus", {"banner_enabled": False})
        with self.assertRaises(AdminError):
            self.svc.change_password("bogus", "a", "b" * 10)

    def test_change_password(self):
        token = self.svc.login("initial-pass")
        with self.assertRaises(AdminError):
            self.svc.change_password(token, "wrong", "new-password-1")
        with self.assertRaises(AdminError):
            self.svc.change_password(token, "initial-pass", "short")
        with self.assertRaises(AdminError):
            self.svc.change_password(token, "initial-pass", "initial-pass")
        self.svc.change_password(token, "initial-pass", "new-password-1")
        with self.assertRaises(AdminError):
            self.svc.require(token)  # old session ended
        with self.assertRaises(AdminError):
            self.svc.login("initial-pass")
        self.assertTrue(self.svc.login("new-password-1"))

    def test_password_not_stored_in_plain_text(self):
        token = self.svc.login("initial-pass")
        self.svc.change_password(token, "initial-pass", "secret-value-9")
        stored = self.db.get_setting("admin.credentials")
        self.assertNotIn("secret-value-9", stored)

    def test_ads_config_validation(self):
        token = self.svc.login("initial-pass")
        cfg = self.svc.set_ads_config(token, {"provider": "admob", "ads_enabled": True, "rewarded_unlock_minutes": 90})
        self.assertEqual(cfg["rewarded_unlock_minutes"], 90)
        self.assertEqual(cfg["ads_required"], 1)
        self.assertEqual(self.svc.set_ads_config(token, {"ads_required": 3})["ads_required"], 3)
        for bad in (0, 11):
            with self.assertRaises(AdminError):
                self.svc.set_ads_config(token, {"ads_required": bad})
        self.assertEqual(self.svc.get_ads_config()["provider"], "admob")
        for bad in ({"provider": "evil"}, {"nope": 1}, {"banner_enabled": "yes"},
                    {"rewarded_unlock_minutes": 1}, {"banner_unit_id": "has space"}):
            with self.assertRaises(AdminError):
                self.svc.set_ads_config(token, bad)
        self.svc.set_ads_config(token, {"provider": "none", "ads_enabled": False})
        with self.assertRaises(AdminError):
            self.svc.set_ads_config(token, {"ads_enabled": True})  # needs a provider

    def test_network_ids_validated(self):
        t = self.svc.login("initial-pass")
        good = {"admob_app_id": "ca-app-pub-4331119416318682~6804177458",
                "rewarded_unit_id": "ca-app-pub-4331119416318682/2484649335",
                "unity_game_id": "800385742", "unity_placement_id": "BP_Rewarded_Android"}
        cfg = self.svc.set_ads_config(t, good)
        for k, v in good.items():
            self.assertEqual(cfg[k], v)
        for bad in ({"admob_app_id": "ca-app-pub-1~2"}, {"rewarded_unit_id": "nope"},
                    {"unity_game_id": "abc"}, {"unity_placement_id": "has space"}):
            with self.assertRaises(AdminError):
                self.svc.set_ads_config(t, bad)

    def test_ads_default_off(self):
        self.assertFalse(self.svc.get_ads_config()["ads_enabled"])

    def test_unlock_expires(self):
        self.assertFalse(self.svc.unlock_status()["unlocked"])
        self.svc.grant_unlock()
        st = self.svc.unlock_status()
        self.assertTrue(st["unlocked"])
        self.assertEqual(st["remaining_seconds"], 3600)
        self.clock.t += 3601
        self.assertFalse(self.svc.unlock_status()["unlocked"])

    def test_default_hash_is_well_formed(self):
        self.assertEqual(len(DEFAULT_HASH), 64)
        self.assertEqual(len(DEFAULT_SALT), 32)


class AdminApiTests(unittest.TestCase):
    def test_envelope(self):
        with tempfile.TemporaryDirectory() as d:
            app = create_app(d)
            self.addCleanup(app.shutdown)
            bad = json.loads(app.admin_login("wrong"))
            self.assertFalse(bad["ok"])
            self.assertTrue(json.loads(app.ads_get_config())["ok"])
            self.assertFalse(json.loads(app.admin_set_ads_config("x", "{}"))["ok"])


if __name__ == "__main__":
    unittest.main()


class AdNetworkFieldTests(unittest.TestCase):
    def setUp(self):
        from admin.service import AdminService
        import tempfile
        from storage import Database
        self._t = tempfile.TemporaryDirectory()
        self.addCleanup(self._t.cleanup)
        self.db = Database(__import__("pathlib").Path(self._t.name) / "x.db")
        self.addCleanup(self.db.close)
        self.svc = AdminService(self.db)

    def test_network_fields_validated(self):
        from admin.service import AdminError
        ok = {"admob_app_id": "ca-app-pub-4331119416318682~6804177458", "unity_game_id": "800385742",
              "unity_placement_id": "BP_Rewarded_Android"}
        cfg = self.svc._apply(ok)
        self.assertEqual(cfg["unity_game_id"], "800385742")
        for bad in ({"admob_app_id": "nope"}, {"unity_game_id": "abc"}, {"unity_placement_id": "a b"}):
            with self.assertRaises(AdminError):
                self.svc._apply(bad)

    def test_unity_needs_both_ids_to_turn_on(self):
        from admin.service import AdminError
        with self.assertRaises(AdminError):
            self.svc._apply({"ads_enabled": True, "provider": "unity", "unity_game_id": "800385742"})
        cfg = self.svc._apply({"ads_enabled": True, "provider": "unity", "unity_game_id": "800385742", "unity_placement_id": "Rewarded"})
        self.assertEqual(cfg["provider"], "unity")
