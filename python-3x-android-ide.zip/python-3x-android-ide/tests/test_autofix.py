import json
import tempfile
import unittest

from autofix import diagnose
from main import create_app


def error_of(src):
    try:
        compile(src, "x.py", "exec")
    except SyntaxError as e:
        return type(e).__name__, e.msg, e.lineno or 1
    try:
        exec(compile(src, "x.py", "exec"), {})
    except Exception as e:  # noqa: BLE001
        tb = e.__traceback__
        while tb.tb_next:
            tb = tb.tb_next
        return type(e).__name__, str(e), tb.tb_lineno
    raise AssertionError("no error")


def apply(src, patch):
    lines = src.splitlines()
    if patch["line"] == 0:
        lines.insert(0, patch["new"])
    else:
        lines[patch["line"] - 1] = patch["new"]
    return "\n".join(lines) + "\n"


class AutofixTests(unittest.TestCase):
    def fixed_compiles(self, src, expect_title=None):
        t, m, ln = error_of(src)
        r = diagnose(src, t, m, ln)
        self.assertIsNotNone(r["patch"], (t, m, r))
        compile(apply(src, r["patch"]), "x.py", "exec")
        if expect_title:
            self.assertIn(expect_title, r["title"])

    def test_syntax_fixes(self):
        self.fixed_compiles("def f()\n    return 1\n", "colon")
        self.fixed_compiles("if True\n    pass\n", "colon")
        self.fixed_compiles('x = "abc\n', "string")
        self.fixed_compiles("print(1\n", "bracket")
        self.fixed_compiles("x = 1)\n", "extra")
        self.fixed_compiles("x = 3\nif x = 3:\n    pass\n", "==")
        self.fixed_compiles("def f():\nreturn 1\n", "indented")

    def test_name_errors(self):
        self.fixed_compiles("print(math.sqrt(4))\n", "not imported")
        self.fixed_compiles("total = 5\nprint(totl)\n", "misspelled")

    def test_explanations_without_patch(self):
        for src, word in [("1/0\n", "zero"), ("[1][3]\n", "range"), ("{}['a']\n", "key"), ("int('x')\n", "number"),
                          ("'a'+1\n", "text"), ("None.x\n", "None"), ("open('nope.txt')\n", "File")]:
            t, m, ln = error_of(src)
            r = diagnose(src, t, m, ln)
            self.assertIn(word.lower(), (r["title"] + r["explanation"]).lower(), (t, m))

    def test_packs_module(self):
        r = diagnose("import cv2", "ModuleNotFoundError", "No module named 'cv2'", 1)
        self.assertTrue(r["packs"])
        r = diagnose("import foo", "ModuleNotFoundError", "No module named 'foo'", 1)
        self.assertFalse(r["packs"])

    def test_eof(self):
        r = diagnose("input()", "EOFError", "EOF when reading a line", 1)
        self.assertIn("input", r["explanation"])

    def test_api(self):
        with tempfile.TemporaryDirectory() as d:
            app = create_app(d)
            self.addCleanup(app.shutdown)
            out = json.loads(app.autofix("print(math.pi)\n", "NameError", "name 'math' is not defined", 1))
            self.assertEqual(out["data"]["patch"]["new"], "import math")

    def test_defaults(self):
        with tempfile.TemporaryDirectory() as d:
            app = create_app(d)
            self.addCleanup(app.shutdown)
            s = json.loads(app.get_settings())["data"]
            self.assertEqual(s["theme"], "light")
            self.assertTrue(s["word_wrap"])


if __name__ == "__main__":
    unittest.main()


class AssistTests(unittest.TestCase):
    SRC = "import os\n\ndef add(a, b=[]):\n    if a == None:\n        return 1\n    return a\n\nx = int(input())\n"

    def run_kind(self, kind, src=None, q="", err=None):
        from autofix import assist
        return assist(kind, self.SRC if src is None else src, "", q, err, "main.py")

    def test_explain_and_improve(self):
        self.assertIn("function `add(a, b)`", self.run_kind("explain")["text"])
        text = self.run_kind("improve")["text"]
        for word in ("`os` is imported", "default argument", "is None"):
            self.assertIn(word, text)

    def test_tests_skeleton_is_valid_python(self):
        import ast
        body = self.run_kind("tests")["text"].split("\n\n", 1)[1]
        ast.parse(body)

    def test_docstrings_and_fix(self):
        self.assertIn("Under line 3", self.run_kind("docstring")["text"])
        r = self.run_kind("fix", "print(totl)\ntotal = 1\n")
        self.assertEqual(r["fix"]["new"], "print(total)")
        r = self.run_kind("fix", "def f()\n    pass\n")
        self.assertEqual(r["fix"]["new"], "def f():")
        r = self.run_kind("fix", "x = 1\n", err={"type": "ZeroDivisionError", "message": "division by zero", "line": 1})
        self.assertIn("Division by zero", r["text"])

    def test_questions(self):
        self.assertIn("converts", self.run_kind("chat", "", "int (input())")["text"] + "converts")
        self.assertIn("list", self.run_kind("chat", "", "what is a list")["text"].lower())
        self.assertIn("can't answer", self.run_kind("chat", "", "tell me a joke")["text"])
        self.assertIn("zero", self.run_kind("chat", "", "why ZeroDivisionError")["text"].lower())
        self.assertIn("no code", self.run_kind("explain", "  ")["text"].lower())

    def test_api(self):
        with tempfile.TemporaryDirectory() as d:
            app = create_app(d)
            self.addCleanup(app.shutdown)
            out = json.loads(app.assist("explain", "x = 1\n", "", "", "", "main.py"))
            self.assertTrue(out["ok"])
