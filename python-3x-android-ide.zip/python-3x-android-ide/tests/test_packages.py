import unittest

from packages import PackageCatalog


class PackageTests(unittest.TestCase):
    def setUp(self):
        self.cat = PackageCatalog()

    def test_stdlib(self):
        self.assertEqual(self.cat.check("json")["status"], "stdlib")

    def test_unsupported_is_reported_not_hidden(self):
        r = self.cat.check("pygame")
        self.assertEqual(r["status"], "unsupported")
        self.assertEqual(r["action"], "")

    def test_buildable_never_claims_installed(self):
        r = self.cat.check("numpy")
        if r["status"] != "bundled":  # numpy may exist on the dev machine; the app build does not have it
            self.assertEqual(r["status"], "buildable")
            self.assertIn("py3xPackages", r["action"])

    def test_unknown_claims_nothing(self):
        r = self.cat.check("totally-made-up-pkg")
        self.assertEqual(r["status"], "unknown")
        self.assertEqual(r["action"], "")

    def test_packs_only_packages_point_to_the_companion_app(self):
        self.cat.installed = lambda: []  # the dev machine may have these installed; the app build does not
        r = self.cat.check("opencv-python")
        self.assertEqual(r["status"], "packs")
        self.assertIn("Packs", r["action"])

    def test_package_reported_by_packs_app(self):
        self.cat.installed = lambda: []  # the dev machine may have these installed; the app build does not
        r = self.cat.check("scipy", [{"name": "SciPy", "version": "1.8.1"}])
        self.assertEqual((r["status"], r["version"]), ("in-packs", "1.8.1"))
        self.assertEqual(self.cat.check("scipy")["status"], "packs")  # without the app it stays "packs"

    def test_catalog_passes_packs_list(self):
        self.cat.installed = lambda: []  # the dev machine may have these installed; the app build does not
        rows = {r["name"]: r for r in self.cat.catalog([{"name": "opencv-python", "version": "4.5"}])}
        self.assertEqual(rows["opencv-python"]["status"], "in-packs")

    def test_name_normalisation(self):
        self.assertEqual(self.cat.check("Scikit_Learn")["name"], "scikit-learn")

    def test_rejects_garbage(self):
        for bad in ("", "../x", "a b", "x;rm"):
            with self.assertRaises(ValueError):
                self.cat.check(bad)

    def test_search_and_lists(self):
        self.assertTrue(any(p["name"] == "opencv-python" for p in self.cat.search("opencv")))
        self.assertIsInstance(self.cat.installed(), list)
        self.assertGreater(len(self.cat.catalog()), 10)


if __name__ == "__main__":
    unittest.main()
