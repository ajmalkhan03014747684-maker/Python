import base64
import json
import tempfile
import unittest

from backend import BackendError, SupabaseClient, normalize_url
from main import create_app
from netutil import HttpClient, Response

URL = "https://abcdefgh.supabase.co"


def jwt(role):
    b = lambda d: base64.urlsafe_b64encode(json.dumps(d).encode()).decode().rstrip("=")  # noqa: E731
    return f"{b({'alg': 'HS256'})}.{b({'role': role})}.sig"


class FakeSupabase:
    def __init__(self):
        self.calls = []
        self.ads = None
        self.role = "user"

    def transport(self, method, url, headers, body, timeout, max_bytes):
        self.calls.append((method, url, dict(headers), json.loads(body) if body else None))
        path = url.split("supabase.co", 1)[1]
        ok = lambda o, c=200: Response(c, {}, json.dumps(o).encode())  # noqa: E731
        data = json.loads(body) if body else {}
        if path == "/auth/v1/signup":
            return ok({"id": "u1", "email": data["email"]})
        if path.startswith("/auth/v1/token?grant_type=password"):
            if data["password"] != "goodpassword":
                return ok({"error_description": "Invalid login credentials"}, 400)
            return ok({"access_token": "AT", "refresh_token": "RT", "expires_in": 3600, "user": {"id": "u1", "email": data["email"]}})
        if path.startswith("/auth/v1/token?grant_type=refresh_token"):
            return ok({"access_token": "AT2", "refresh_token": "RT2", "user": {"id": "u1", "email": "a@b.co"}})
        if path == "/auth/v1/logout":
            return Response(204)
        if path.startswith("/rest/v1/profiles"):
            return ok([{"email": "a@b.co", "role": self.role}])
        if path.startswith("/rest/v1/app_settings") and method == "GET":
            return ok([{"value": self.ads}] if self.ads else [])
        if path.startswith("/rest/v1/app_settings"):
            if headers["Authorization"] == "Bearer ANON" or self.role != "admin":
                return ok({"message": "row-level security"}, 403)
            self.ads = data["value"]
            return Response(201)
        if path == "/rest/v1/rpc/admin_stats":
            return ok({"users": 3, "events_7d": 10})
        if path == "/rest/v1/events":
            return Response(201)
        return ok({}, 404)


class BackendTests(unittest.TestCase):
    def setUp(self):
        self.fake = FakeSupabase()
        self.c = SupabaseClient(URL, "ANON", HttpClient({"abcdefgh.supabase.co"}, self.fake.transport))

    def test_url_validation(self):
        self.assertEqual(normalize_url(URL + "/"), URL)
        for bad in ("http://abcdefgh.supabase.co", "https://evil.com", "https://abcdefgh.supabase.co.evil.com",
                    "https://abcdefgh.supabase.co/x", "https://u@abcdefgh.supabase.co", ""):
            with self.assertRaises(BackendError, msg=bad):
                normalize_url(bad)

    def test_service_role_key_refused(self):
        with self.assertRaises(BackendError):
            SupabaseClient(URL, jwt("service_role"))
        with self.assertRaises(BackendError):
            SupabaseClient(URL, "sb_secret_abc")
        SupabaseClient(URL, jwt("anon"))

    def test_sign_up_in_and_validation(self):
        self.assertTrue(self.c.sign_up("A@B.co", "goodpassword")["needs_confirmation"])
        self.assertEqual(self.fake.calls[-1][3]["email"], "a@b.co")
        s = self.c.sign_in("a@b.co", "goodpassword")
        self.assertEqual((s["access_token"], s["user_id"]), ("AT", "u1"))
        with self.assertRaises(BackendError):
            self.c.sign_in("a@b.co", "wrongpassword")
        with self.assertRaises(BackendError):
            self.c.sign_in("bad", "goodpassword")
        with self.assertRaises(BackendError):
            self.c.sign_in("a@b.co", "short")
        self.assertEqual(self.c.refresh("RT")["access_token"], "AT2")

    def test_ads_admin_only(self):
        with self.assertRaises(BackendError):
            self.c.set_ads_config("AT", {"ads_enabled": False})
        self.fake.role = "admin"
        self.c.set_ads_config("AT", {"provider": "none"})
        self.assertEqual(self.c.get_ads_config(), {"provider": "none"})
        self.assertEqual(self.c.admin_stats("AT")["users"], 3)

    def test_event_name_checked(self):
        self.c.log_event(None, "app_open")
        with self.assertRaises(BackendError):
            self.c.log_event(None, "Bad Name; drop")

    def test_auth_header_uses_anon_when_signed_out(self):
        self.c.get_ads_config()
        self.assertEqual(self.fake.calls[-1][2]["Authorization"], "Bearer ANON")


class BackendApiTests(unittest.TestCase):
    def setUp(self):
        self._t = tempfile.TemporaryDirectory()
        self.addCleanup(self._t.cleanup)
        self.app = create_app(self._t.name)
        self.addCleanup(self.app.shutdown)
        self.fake = FakeSupabase()

    def call(self, name, *a):
        return json.loads(getattr(self.app, name)(*a))

    def configure(self):
        from backend import SupabaseClient as C
        self.app._backend_client = C(URL, "ANON", HttpClient({"abcdefgh.supabase.co"}, self.fake.transport))

    def test_not_configured_is_honest(self):
        self.assertFalse(self.call("backend_configure", "", "")["data"]["configured"])
        r = self.call("backend_sign_in", "a@b.co", "goodpassword")
        self.assertFalse(r["ok"])
        self.assertIn("not set up", r["error"])
        self.assertFalse(self.call("backend_configure", "https://evil.com", "k")["ok"])

    def test_sign_in_returns_role_and_pull_applies_valid_ads(self):
        self.configure()
        self.fake.role = "admin"
        r = self.call("backend_sign_in", "a@b.co", "goodpassword")["data"]
        self.assertEqual(r["role"], "admin")
        pushed = self.call("backend_push_ads", r["access_token"], json.dumps({"provider": "admob", "ads_enabled": True}))
        self.assertTrue(pushed["ok"])
        self.fake.ads = {"provider": "admob", "ads_enabled": True, "rewarded_unlock_minutes": 1, "evil": 1}
        bad = self.call("backend_pull_ads")
        self.assertFalse(bad["ok"])  # invalid unlock minutes rejected, not applied
        self.fake.ads["rewarded_unlock_minutes"] = 30
        self.assertEqual(self.call("backend_pull_ads")["data"]["rewarded_unlock_minutes"], 30)
        self.assertNotIn("evil", self.call("ads_get_config")["data"])

    def test_non_admin_cannot_push(self):
        self.configure()
        r = self.call("backend_push_ads", "AT", json.dumps({"provider": "admob", "ads_enabled": True}))
        self.assertFalse(r["ok"])


if __name__ == "__main__":
    unittest.main()
