import ast
import json
import tempfile
import unittest

from main import create_app
from templates import TEMPLATES


class TemplateTests(unittest.TestCase):
    def setUp(self):
        self._t = tempfile.TemporaryDirectory()
        self.addCleanup(self._t.cleanup)
        self.app = create_app(self._t.name)
        self.addCleanup(self.app.shutdown)

    def test_every_template_is_valid_python(self):
        for key, t in TEMPLATES.items():
            for rel, content in t["files"].items():
                if rel.endswith(".py"):
                    ast.parse(content, filename=f"{key}/{rel}")
            self.assertIn(t["runs_in"], ("main", "packs"))

    def test_list_and_create(self):
        rows = json.loads(self.app.templates_list())["data"]
        self.assertEqual({r["key"] for r in rows}, set(TEMPLATES))
        p = json.loads(self.app.templates_create("statistics"))["data"]
        self.assertEqual(p["main_file"], "main.py")
        text = json.loads(self.app.open_file(p["id"], "main.py"))["data"]["content"]
        self.assertIn("statistics", text)
        self.assertTrue(json.loads(self.app.open_file(p["id"], "README.md"))["ok"])

    def test_unknown_template(self):
        self.assertFalse(json.loads(self.app.templates_create("nope"))["ok"])

    def test_statistics_example_runs(self):
        # Pure standard library plus numpy; skip the run if numpy is not on this machine.
        try:
            import numpy  # noqa: F401
        except ImportError:
            self.skipTest("numpy not installed")
        ns: dict = {}
        exec(compile(TEMPLATES["statistics"]["files"]["main.py"], "stats", "exec"), ns)  # noqa: S102 - our own template

    def _play(self, key, inputs, patches=None):
        import builtins
        import contextlib
        import io
        from unittest import mock
        src = TEMPLATES[key]["files"]["main.py"]
        feed = iter(inputs)
        out = io.StringIO()
        with mock.patch.object(builtins, "input", lambda prompt="": next(feed)), contextlib.redirect_stdout(out):
            with contextlib.ExitStack() as st:
                for target, value in (patches or {}).items():
                    st.enter_context(mock.patch(target, value))
                exec(compile(src, key, "exec"), {"__name__": "__main__"})
        return out.getvalue()

    def test_games_play_to_the_end(self):
        out = self._play("game-guess", ["x", "10", "90", "42"], {"random.randint": lambda a, b: 42})
        self.assertIn("Higher!", out)
        self.assertIn("Lower!", out)
        self.assertIn("Correct! You needed 3 tries.", out)
        out = self._play("game-tictactoe", ["1", "4", "2", "5", "3"])
        self.assertIn("X wins!", out)
        out = self._play("game-hangman", list("python"), {"random.choice": lambda seq: "python"})
        self.assertIn("You won!", out)
        out = self._play("game-hangman", list("zxqjkw"), {"random.choice": lambda seq: "python"})
        self.assertIn("You lost. The word was python.", out)

    def test_categories(self):
        rows = {r["key"]: r["category"] for r in json.loads(self.app.templates_list())["data"]}
        self.assertEqual(rows["game-guess"], "game")
        self.assertEqual(rows["statistics"], "data")


if __name__ == "__main__":
    unittest.main()
