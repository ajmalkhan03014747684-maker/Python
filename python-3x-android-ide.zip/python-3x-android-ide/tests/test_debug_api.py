import json
import tempfile
import threading
import time
import unittest

from main import create_app


class Listener:
    def __init__(self, api):
        self.api, self.events, self.paused = api, [], threading.Event()
        self.done = threading.Event()

    def onEvent(self, raw):
        ev = json.loads(raw)
        self.events.append(ev)
        if ev["event"] == "paused":
            self.paused.set()
        if ev["event"] == "finished":
            self.done.set()


class DebugApiTests(unittest.TestCase):
    def setUp(self):
        self._t = tempfile.TemporaryDirectory()
        self.addCleanup(self._t.cleanup)
        self.app = create_app(self._t.name)
        self.addCleanup(self.app.shutdown)
        p = json.loads(self.app.create_project("Dbg"))["data"]
        self.pid = p["id"]
        json.loads(self.app.save_file(self.pid, "main.py", "import helper\nv = helper.f(2)\nprint(v)\n"))
        json.loads(self.app.create_file(self.pid, "helper.py"))
        json.loads(self.app.save_file(self.pid, "helper.py", "def f(n):\n    return n * 21\n"))

    def test_debug_roundtrip_and_project_imports(self):
        lis = Listener(self.app)
        r = json.loads(self.app.debug_start(self.pid, "main.py", json.dumps({"main.py": [3]}), False, lis))
        self.assertTrue(r["ok"], r)
        self.assertTrue(lis.paused.wait(5))
        ev = [e for e in lis.events if e["event"] == "paused"][0]
        self.assertEqual(ev["variables"]["v"], "42")
        self.assertTrue(json.loads(self.app.debug_command("continue"))["ok"])
        self.assertTrue(lis.done.wait(5))
        self.assertEqual(lis.events[-1]["exit_code"], 0)

    def test_second_session_refused_while_active(self):
        lis = Listener(self.app)
        json.loads(self.app.debug_start(self.pid, "main.py", json.dumps({"main.py": [3]}), False, lis))
        self.assertTrue(lis.paused.wait(5))
        again = json.loads(self.app.debug_start(self.pid, "main.py", "{}", False, Listener(self.app)))
        self.assertFalse(again["ok"])
        self.app.debug_command("stop")
        self.assertTrue(lis.done.wait(5))

    def test_command_without_session(self):
        self.assertFalse(json.loads(self.app.debug_command("step"))["ok"])

    def test_packages_api(self):
        self.assertTrue(json.loads(self.app.packages_check("pygame"))["ok"])
        self.assertFalse(json.loads(self.app.packages_check("bad name!"))["ok"])


if __name__ == "__main__":
    unittest.main()
