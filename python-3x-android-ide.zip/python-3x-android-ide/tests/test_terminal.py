import tempfile
import unittest
from pathlib import Path

from runtime import InProcessBackend, ScriptRunner
from terminal import TerminalSession


class TerminalTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.root = Path(self._tmp.name) / "projects"
        (self.root / "demo").mkdir(parents=True)
        (self.root / "demo" / "hello.py").write_text("print('hi from file')\n")
        (self.root / "demo" / "note.txt").write_text("note text\n")
        self.term = TerminalSession(self.root, self.root / "demo", scratch=Path(self._tmp.name) / "s")
        self.addCleanup(self.term.interrupt)

    def run_cmd(self, line, wait=True):
        out, codes = [], []
        info = self.term.execute(line, out.append, codes.append)
        if info["async"] and wait:
            self.term.runner.wait(15)
        return "".join(out), codes, info

    def test_help_and_unknown(self):
        out, codes, _ = self.run_cmd("help")
        self.assertIn("python", out)
        out, codes, _ = self.run_cmd("rm -rf /")
        self.assertIn("command not found", out)
        self.assertEqual(codes, [127])

    def test_ls_pwd_cat_echo(self):
        self.assertIn("hello.py", self.run_cmd("ls")[0])
        self.assertEqual(self.run_cmd("pwd")[0].strip(), "~/demo")
        self.assertEqual(self.run_cmd("cat note.txt")[0], "note text\n")
        self.assertEqual(self.run_cmd("echo a   b")[0], "a b\n")

    def test_cd_stays_in_sandbox(self):
        self.run_cmd("cd ..")
        self.assertEqual(self.term.cwd, self.root.resolve())
        out, codes, _ = self.run_cmd("cd ..")
        self.assertIn("outside the sandbox", out)
        self.assertEqual(codes, [1])
        out, _, _ = self.run_cmd("cat /etc/passwd")
        self.assertIn("outside the sandbox", out)

    def test_mkdir_touch(self):
        self.run_cmd("mkdir sub")
        self.run_cmd("touch sub/x.txt")
        self.assertTrue((self.root / "demo" / "sub" / "x.txt").exists())

    def test_python_file_runs_and_reports_exit(self):
        out, codes, info = self.run_cmd("python hello.py")
        self.assertTrue(info["async"])
        self.assertEqual(out, "hi from file\n")
        self.assertEqual(codes, [0])

    def test_python3_c(self):
        out, codes, _ = self.run_cmd('python3 -c "print(6*7)"')
        self.assertEqual(out, "42\n")

    def test_python_failure_exit_code(self):
        (self.root / "demo" / "bad.py").write_text("raise SystemExit(4)\n")
        _, codes, _ = self.run_cmd("python bad.py")
        self.assertEqual(codes, [4])

    def test_python_missing_file(self):
        out, codes, _ = self.run_cmd("python nope.py")
        self.assertIn("can't open file", out)
        self.assertEqual(codes, [2])

    def test_busy_rejects_second_command_and_interrupt(self):
        (self.root / "demo" / "slow.py").write_text("while True:\n    pass\n")
        self.term.runner = ScriptRunner(InProcessBackend())
        self.run_cmd("python slow.py", wait=False)
        out, codes, _ = self.run_cmd("echo hi")
        self.assertIn("still running", out)
        done = []
        self.term.interrupt()
        self.assertIsNotNone(self.term.runner.wait(10))
        self.assertFalse(self.term.busy)
        del done

    def test_history_and_clear(self):
        self.run_cmd("echo one")
        self.run_cmd("echo two")
        self.assertEqual(self.term.history, ["echo one", "echo two"])
        out, _, _ = self.run_cmd("history")
        self.assertIn("echo two", out)
        _, _, info = self.run_cmd("clear")
        self.assertTrue(info["clear"])

    def test_pip_list_show_and_install_message(self):
        out, codes, _ = self.run_cmd("pip --version")
        self.assertIn("pip", out)
        out, codes, _ = self.run_cmd("pip install requests")
        self.assertIn("not available", out)
        self.assertEqual(codes, [1])
        out, _, _ = self.run_cmd("pip show definitely-not-installed-xyz")
        self.assertIn("not found", out)

    def test_bad_quoting(self):
        out, codes, _ = self.run_cmd('echo "unterminated')
        self.assertIn("syntax error", out)
        self.assertEqual(codes, [1])

    def test_completion(self):
        self.assertEqual(self.term.complete("pyt"), ["python", "python3"])
        self.assertEqual(self.term.complete("cat he"), ["hello.py"])
        self.assertEqual(self.term.complete("cat ../../"), [])

    def test_prompt(self):
        self.assertEqual(self.term.prompt(), "~/demo$ ")


if __name__ == "__main__":
    unittest.main()
