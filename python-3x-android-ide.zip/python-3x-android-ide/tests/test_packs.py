import json
import tempfile
import threading
import unittest
import zipfile
from pathlib import Path

from packs_main import create_app
from packsvc import JobError, PacksJobs
from packsvc.jobs import apply_result, pack_changes, safe_extract

try:
    import cv2
    import numpy as np
except ImportError:
    cv2 = None


def make_zip(path: Path, files: dict[str, bytes | str]) -> Path:
    with zipfile.ZipFile(path, "w") as zf:
        for name, data in files.items():
            zf.writestr(name, data)
    return path


class Collector:
    def __init__(self):
        self.out, self.result = [], None
        self.done = threading.Event()

    def on_output(self, stream, text):
        self.out.append((stream, text))

    def on_finish(self, result):
        self.result = result
        self.done.set()

    def text(self, stream="stdout"):
        return "".join(t for s, t in self.out if s == stream)


class JobTests(unittest.TestCase):
    def setUp(self):
        self._t = tempfile.TemporaryDirectory()
        self.addCleanup(self._t.cleanup)
        self.tmp = Path(self._t.name)
        self.jobs = PacksJobs(self.tmp / "work")

    def run_job(self, files, kind="script", arg="main.py", job_id="job1"):
        z = make_zip(self.tmp / f"{job_id}.zip", files)
        c = Collector()
        self.jobs.start(job_id, z, kind, arg, c.on_output, c.on_finish)
        self.assertTrue(c.done.wait(20), "job did not finish")
        return c

    def test_script_output_and_changed_files_returned(self):
        c = self.run_job({
            "main.py": "print('hello from packs')\nopen('result.txt','w').write('42')\n",
            "keep.txt": "unchanged",
        })
        self.assertIn("hello from packs", c.text())
        self.assertEqual(c.result["exit_code"], 0)
        self.assertEqual(c.result["changed"], ["result.txt"])  # unchanged inputs are not sent back
        with zipfile.ZipFile(c.result["result_zip"]) as zf:
            self.assertEqual(zf.read("result.txt"), b"42")

    def test_script_error_is_reported(self):
        c = self.run_job({"main.py": "raise ValueError('nope')\n"})
        self.assertNotEqual(c.result["exit_code"], 0)
        self.assertIn("ValueError", c.text("stderr"))
        self.assertIsNone(c.result["result_zip"])

    def test_missing_or_bad_script(self):
        for arg in ("missing.py", "../x.py", "notes.txt"):
            c = self.run_job({"main.py": "x=1", "notes.txt": "t"}, arg=arg, job_id="j" + str(abs(hash(arg)) % 1000))
            self.assertIn("error", c.result, arg)

    def test_one_job_at_a_time(self):
        z = make_zip(self.tmp / "slow.zip", {"main.py": "import time\ntime.sleep(1.5)\n"})
        c = Collector()
        self.jobs.start("slow", z, "script", "main.py", c.on_output, c.on_finish)
        with self.assertRaises(JobError):
            self.jobs.start("other", z, "script", "main.py", c.on_output, c.on_finish)
        self.assertTrue(c.done.wait(20))

    def test_stop(self):
        z = make_zip(self.tmp / "loop.zip", {"main.py": "import time\nwhile True: time.sleep(0.05)\n"})
        c = Collector()
        self.jobs.start("loop", z, "script", "main.py", c.on_output, c.on_finish)
        threading.Timer(0.5, self.jobs.stop).start()
        self.assertTrue(c.done.wait(20))
        self.assertEqual(c.result["state"], "stopped")

    def test_bad_job_id_and_kind(self):
        z = make_zip(self.tmp / "a.zip", {"main.py": ""})
        c = Collector()
        for jid, kind in (("../evil", "script"), ("ok", "shell")):
            with self.assertRaises(JobError):
                self.jobs.start(jid, z, kind, "main.py", c.on_output, c.on_finish)

    def test_busy_flag_resets_after_failed_start(self):
        c = Collector()
        with self.assertRaises(Exception):
            self.jobs.start("x1", self.tmp / "nope.zip", "script", "main.py", c.on_output, c.on_finish)
        self.assertFalse(self.jobs.busy)


class ExtractTests(unittest.TestCase):
    def test_zip_slip_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            d = Path(d)
            for evil in ("../evil.py", "/abs.py", "a/../../b.py"):
                z = make_zip(d / "e.zip", {evil: "x"})
                with self.assertRaises(JobError, msg=evil):
                    safe_extract(z, d / "out")
            self.assertFalse((d / "evil.py").exists())

    def test_too_many_files(self):
        with tempfile.TemporaryDirectory() as d:
            d = Path(d)
            z = make_zip(d / "m.zip", {f"f{i}.txt": "" for i in range(5001)})
            with self.assertRaises(JobError):
                safe_extract(z, d / "out")

    def test_apply_result_writes_files_and_skips_internals(self):
        with tempfile.TemporaryDirectory() as d:
            d = Path(d)
            z = make_zip(d / "r.zip", {"out/a.png": "img", "__pycache__/x.pyc": "x", "ok.txt": "1"})
            written = apply_result(z, d / "project")
            self.assertEqual(sorted(written), ["ok.txt", "out/a.png"])
            self.assertTrue((d / "project" / "out" / "a.png").is_file())
            self.assertFalse((d / "project" / "__pycache__").exists())

    def test_apply_result_rejects_zip_slip(self):
        with tempfile.TemporaryDirectory() as d:
            d = Path(d)
            z = make_zip(d / "r.zip", {"../evil.txt": "x"})
            with self.assertRaises(JobError):
                apply_result(z, d / "project")
            self.assertFalse((d / "evil.txt").exists())

    def test_pack_changes_detects_modified_and_new(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            (root / "a.txt").write_text("1")
            from packsvc.jobs import _snapshot

            before = _snapshot(root)
            (root / "a.txt").write_text("22")
            (root / "sub").mkdir()
            (root / "sub" / "b.txt").write_text("b")
            (root / "__pycache__").mkdir()
            (root / "__pycache__" / "x.pyc").write_text("c")
            changed = pack_changes(root, before, root.parent / "r.zip")
            self.assertEqual(sorted(changed), ["a.txt", "sub/b.txt"])


@unittest.skipIf(cv2 is None, "OpenCV not installed here")
class VisionJobTests(unittest.TestCase):
    def test_vision_job_returns_output_image(self):
        with tempfile.TemporaryDirectory() as d:
            d = Path(d)
            img = np.zeros((20, 30, 3), np.uint8)
            ok, buf = cv2.imencode(".png", img)
            z = make_zip(d / "v.zip", {"images/in.png": buf.tobytes()})
            jobs = PacksJobs(d / "w")
            c = Collector()
            arg = {"rel": "images/in.png", "steps": [{"op": "grayscale"}], "out": "opencv_out/result.png"}
            jobs.start("v1", z, "vision", arg, c.on_output, c.on_finish)
            self.assertTrue(c.done.wait(20))
            self.assertEqual(c.result["exit_code"], 0, c.result)
            self.assertEqual(c.result["changed"], ["opencv_out/result.png"])


class ApiTests(unittest.TestCase):
    def test_envelopes_and_info(self):
        with tempfile.TemporaryDirectory() as d:
            app = create_app(d, in_process=False)
            info = json.loads(app.info())
            self.assertTrue(info["ok"])
            self.assertEqual(info["data"]["protocol"], 1)
            self.assertIn("packages", info["data"])
            bad = json.loads(app.start_job("../x", "/nonexistent.zip", "script", "main.py", None))
            self.assertFalse(bad["ok"])

    def test_api_job_with_listener(self):
        with tempfile.TemporaryDirectory() as d:
            d = Path(d)
            z = make_zip(d / "j.zip", {"main.py": "print('via api')"})
            app = create_app(str(d / "data"), in_process=False)
            c = Collector()

            class L:
                def onOutput(self, s, t):
                    c.on_output(s, t)

                def onFinish(self, raw):
                    c.on_finish(json.loads(raw))

            self.assertTrue(json.loads(app.start_job("j9", str(z), "script", "main.py", L()))["ok"])
            self.assertTrue(c.done.wait(20))
            self.assertIn("via api", c.text())
            self.assertTrue(json.loads(app.cleanup("j9"))["ok"])


if __name__ == "__main__":
    unittest.main()
