import sys
import tempfile
import textwrap
import time
import unittest
from pathlib import Path

from runtime import InProcessBackend, RunState, ScriptRunner, SubprocessBackend, parse_traceback


class RunnerMixin:
    """Behaviour every backend must share. Subclasses set ``backend_cls``."""

    backend_cls = None

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.dir = Path(self._tmp.name)
        self.runner = ScriptRunner(self.backend_cls())
        self.addCleanup(self.runner.stop)
        self.chunks = []
        self.states = []

    def run_code(self, code, timeout=None, wait=15):
        script = self.dir / "script.py"
        script.write_text(textwrap.dedent(code))
        self.runner.start(
            script, self.dir,
            on_output=lambda s, t: self.chunks.append((s, t)),
            on_state=self.states.append,
            timeout=timeout,
        )
        return self.runner.wait(wait)

    def test_stdout_and_completion(self):
        r = self.run_code("print('hello'); print('world')")
        self.assertEqual(r.state, RunState.COMPLETED)
        self.assertEqual(r.exit_code, 0)
        self.assertEqual(r.stdout, "hello\nworld\n")
        self.assertGreaterEqual(r.duration, 0)
        self.assertEqual(self.states[0], "preparing")
        self.assertEqual(self.states[1], "running")
        self.assertEqual(self.states[-1], "completed")

    def test_stderr_kept_separate(self):
        r = self.run_code("import sys; print('o'); print('e', file=sys.stderr)")
        self.assertEqual((r.stdout, r.stderr), ("o\n", "e\n"))

    def test_exception_fails_with_traceback_and_line(self):
        r = self.run_code("""
            def boom():
                raise ValueError("bad value")
            boom()
        """)
        self.assertEqual(r.state, RunState.FAILED)
        self.assertEqual(r.exit_code, 1)
        self.assertIn("ValueError: bad value", r.stderr)
        self.assertEqual(r.error["error_type"], "ValueError")
        self.assertEqual(r.error["line"], 3)
        self.assertTrue(r.error["file"].endswith("script.py"))

    def test_syntax_error_reported(self):
        r = self.run_code("def broken(:\n    pass\n")
        self.assertEqual(r.state, RunState.FAILED)
        self.assertIn("SyntaxError", r.stderr)
        self.assertEqual(r.error["line"], 1)

    def test_sys_exit_code(self):
        r = self.run_code("import sys; sys.exit(3)")
        self.assertEqual((r.state, r.exit_code), (RunState.FAILED, 3))

    def test_sys_exit_zero_is_completed(self):
        r = self.run_code("import sys; sys.exit(0)")
        self.assertEqual(r.state, RunState.COMPLETED)

    def test_stop_infinite_loop(self):
        self.run_code("print('start', flush=True)\nwhile True:\n    pass\n", wait=0)
        deadline = time.time() + 5
        while not any("start" in t for _, t in self.chunks) and time.time() < deadline:
            time.sleep(0.02)
        self.runner.stop()
        r = self.runner.wait(10)
        self.assertIsNotNone(r)
        self.assertEqual(r.state, RunState.STOPPED)
        self.assertFalse(r.stuck)
        self.assertFalse(self.runner.is_running)

    def test_stop_is_not_swallowed_by_bare_except(self):
        # A sleep keeps the loop interruptible: CPython 3.10 never yields the GIL inside `while True: try: pass`
        # (fixed in 3.11), which would freeze the whole interpreter and is not what this test is about.
        self.run_code("import time\nwhile True:\n    try:\n        time.sleep(0.001)\n    except Exception:\n        pass\n", wait=0)
        time.sleep(0.3)
        self.runner.stop()
        r = self.runner.wait(10)
        self.assertEqual(r.state, RunState.STOPPED)

    def test_timeout_stops_script(self):
        r = self.run_code("while True:\n    pass\n", timeout=0.5)
        self.assertTrue(r.timed_out)
        self.assertEqual(r.state, RunState.FAILED)
        self.assertIn("maximum run time", r.stderr)

    def test_stdin_input(self):
        self.run_code("name = input('name? ')\nprint('hi', name)\n", wait=0)
        deadline = time.time() + 5
        while not any("name?" in t for _, t in self.chunks) and time.time() < deadline:
            time.sleep(0.02)
        self.runner.send_input("Ada\n")
        r = self.runner.wait(10)
        self.assertEqual(r.state, RunState.COMPLETED)
        self.assertIn("hi Ada", r.stdout)

    def test_input_unblocks_on_stop(self):
        self.run_code("input()\n", wait=0)
        time.sleep(0.3)
        self.runner.stop()
        r = self.runner.wait(10)
        self.assertEqual(r.state, RunState.STOPPED)

    def test_output_streams_before_finish(self):
        self.run_code("import time\nprint('first', flush=True)\ntime.sleep(0.6)\nprint('second')\n", wait=0)
        deadline = time.time() + 5
        while not self.chunks and time.time() < deadline:
            time.sleep(0.02)
        self.assertTrue(self.runner.is_running)
        self.assertTrue(self.chunks[0][1].startswith("first"))
        self.runner.wait(10)

    def test_output_cap(self):
        self.runner.max_output = 1000
        r = self.run_code("print('x' * 5000)")
        self.assertTrue(r.truncated)
        self.assertLessEqual(len(r.stdout), 1000)

    def test_cwd_is_project_dir(self):
        (self.dir / "data.txt").write_text("found")
        r = self.run_code("print(open('data.txt').read())")
        self.assertEqual(r.stdout.strip(), "found")

    def test_import_sibling_module_and_reload_on_rerun(self):
        (self.dir / "helper.py").write_text("VALUE = 1\n")
        r = self.run_code("import helper\nprint(helper.VALUE)\n")
        self.assertEqual(r.stdout.strip(), "1")
        (self.dir / "helper.py").write_text("VALUE = 2\n")
        self.chunks.clear()
        r = self.run_code("import helper\nprint(helper.VALUE)\n")
        self.assertEqual(r.stdout.strip(), "2")

    def test_missing_script_fails_cleanly(self):
        self.runner.start(self.dir / "nope.py", self.dir)
        r = self.runner.wait(5)
        self.assertEqual(r.state, RunState.FAILED)
        self.assertIn("not found", r.stderr)

    def test_cannot_start_twice(self):
        self.run_code("import time; time.sleep(5)", wait=0)
        with self.assertRaises(RuntimeError):
            self.runner.start(self.dir / "script.py", self.dir)

    def test_restart_runs_again(self):
        self.run_code("print('again')")
        self.chunks.clear()
        self.runner.restart()
        r = self.runner.wait(10)
        self.assertEqual(r.state, RunState.COMPLETED)
        self.assertEqual(r.stdout, "again\n")

    def test_callbacks_that_raise_do_not_break_runner(self):
        script = self.dir / "s.py"
        script.write_text("print('ok')")

        def bad(*_):
            raise RuntimeError("ui bug")

        self.runner.start(script, self.dir, on_output=bad, on_state=bad, on_finish=bad)
        self.assertEqual(self.runner.wait(10).state, RunState.COMPLETED)


class SubprocessRunnerTests(RunnerMixin, unittest.TestCase):
    backend_cls = SubprocessBackend

    def test_child_process_group_killed(self):
        code = """
            import subprocess, sys, time
            subprocess.Popen([sys.executable, "-c", "import time; time.sleep(60)"])
            print("spawned", flush=True)
            time.sleep(60)
        """
        self.run_code(code, wait=0)
        deadline = time.time() + 5
        while not any("spawned" in t for _, t in self.chunks) and time.time() < deadline:
            time.sleep(0.02)
        self.runner.stop()
        self.assertEqual(self.runner.wait(10).state, RunState.STOPPED)

    def test_sleeping_script_is_hard_stopped(self):
        self.run_code("import time; time.sleep(60)", wait=0)
        time.sleep(0.3)
        self.runner.stop()
        r = self.runner.wait(10)
        self.assertEqual(r.state, RunState.STOPPED)
        self.assertFalse(r.stuck)

    def test_environment_is_scrubbed(self):
        import os

        os.environ["PY3X_SECRET_TEST"] = "leak"
        self.addCleanup(os.environ.pop, "PY3X_SECRET_TEST", None)
        r = self.run_code("import os; print(os.environ.get('PY3X_SECRET_TEST'))")
        self.assertEqual(r.stdout.strip(), "None")


class InProcessRunnerTests(RunnerMixin, unittest.TestCase):
    backend_cls = InProcessBackend

    def test_host_stdout_untouched_for_other_threads(self):
        r = self.run_code("print('captured')")
        self.assertEqual(r.stdout, "captured\n")
        print("", end="")  # host thread still writes to the original stream without error

    def test_blocking_native_call_reports_stuck(self):
        from runtime.backends import _InProcessHandle

        script = self.dir / "blocker.py"
        script.write_text("import time; time.sleep(3)")
        self.runner.start(script, self.dir)
        time.sleep(0.3)
        handle = self.runner._handle
        self.assertIsInstance(handle, _InProcessHandle)
        handle.stop(grace=0.3)
        self.assertTrue(handle.stuck)
        self.runner.wait(10)  # thread ends once the sleep returns

    def test_run_works_after_working_directory_was_deleted(self):
        import os
        import shutil

        doomed = Path(tempfile.mkdtemp())
        keep = os.getcwd()
        self.addCleanup(os.chdir, keep)
        os.chdir(doomed)
        shutil.rmtree(doomed)  # process cwd now points at a deleted directory
        r = self.run_code("print('still runs')", wait=10)
        self.assertIsNotNone(r)
        self.assertEqual(r.stdout.strip(), "still runs")

    def test_sys_state_restored_after_run(self):
        argv, path, cwd = list(sys.argv), list(sys.path), __import__("os").getcwd()
        self.run_code("import sys; print(sys.argv)")
        self.assertEqual(sys.argv, argv)
        self.assertEqual(sys.path, path)
        self.assertEqual(__import__("os").getcwd(), cwd)


class TracebackParserTests(unittest.TestCase):
    TB = (
        "Traceback (most recent call last):\n"
        '  File "/proj/main.py", line 7, in <module>\n    run()\n'
        '  File "/proj/util.py", line 3, in run\n    1/0\n'
        "ZeroDivisionError: division by zero\n"
    )

    def test_innermost_frame(self):
        info = parse_traceback(self.TB)
        self.assertEqual((info["file"], info["line"]), ("/proj/util.py", 3))
        self.assertEqual(info["error_type"], "ZeroDivisionError")
        self.assertEqual(info["message"], "division by zero")

    def test_prefers_project_frames(self):
        tb = self.TB.replace("/proj/util.py", "/usr/lib/python3/json/decoder.py")
        info = parse_traceback(tb, project_dir="/proj")
        self.assertEqual(info["file"], "/proj/main.py")

    def test_no_traceback(self):
        self.assertIsNone(parse_traceback("just output\n"))


if __name__ == "__main__":
    unittest.main()
