import json
import tempfile
import unittest

from main import create_app


class ServicesApiTests(unittest.TestCase):
    def setUp(self):
        self._t = tempfile.TemporaryDirectory()
        self.addCleanup(self._t.cleanup)
        self.app = create_app(self._t.name)
        self.addCleanup(self.app.shutdown)

    def call(self, name, *args):
        return json.loads(getattr(self.app, name)(*args))

    def test_github_requires_token_and_valid_names(self):
        self.assertFalse(self.call("github_user", "")["ok"])
        r = self.call("github_clone", "tok", "../x", "demo", "", "")
        self.assertFalse(r["ok"])
        self.assertFalse(self.call("github_status", 1)["data"]["linked"] if self.call("github_status", 1)["ok"] else False)

    def test_github_push_unlinked_project(self):
        p = self.call("create_project", "Demo")["data"]
        r = self.call("github_push", "tok", p["id"], "msg", "")
        self.assertFalse(r["ok"])
        self.assertIn("not linked", r["error"])

    def test_rewarded_unlock_without_admin(self):
        self.assertFalse(self.call("ads_unlock_status")["data"]["unlocked"])
        self.assertTrue(self.call("ads_grant_unlock")["data"]["unlocked"])
        self.assertTrue(self.call("ads_unlock_status")["data"]["unlocked"])


if __name__ == "__main__":
    unittest.main()
