import unittest

from editor import completion, diagnostics, ops


class CommentTests(unittest.TestCase):
    def test_comment_and_uncomment_roundtrip(self):
        text = "a = 1\nb = 2\n"
        commented, s, e = ops.toggle_comment(text, 0, len(text) - 1)
        self.assertEqual(commented, "# a = 1\n# b = 2\n")
        restored, _, _ = ops.toggle_comment(commented, 0, len(commented) - 1)
        self.assertEqual(restored, text)

    def test_comment_keeps_indent_and_skips_blank_lines(self):
        text = "if x:\n    a = 1\n\n    b = 2"
        out, _, _ = ops.toggle_comment(text, 6, len(text))
        self.assertEqual(out, "if x:\n    # a = 1\n\n    # b = 2")

    def test_single_line_no_selection(self):
        out, _, _ = ops.toggle_comment("x = 1\ny = 2", 8, 8)
        self.assertEqual(out, "x = 1\n# y = 2")

    def test_mixed_selection_comments_all(self):
        out, _, _ = ops.toggle_comment("# a\nb", 0, 5)
        self.assertEqual(out, "# # a\n# b")


class IndentTests(unittest.TestCase):
    def test_indent_outdent(self):
        out, _, _ = ops.indent("a\nb", 0, 3)
        self.assertEqual(out, "    a\n    b")
        back, _, _ = ops.outdent(out, 0, len(out))
        self.assertEqual(back, "a\nb")

    def test_indent_tabs_and_width(self):
        self.assertEqual(ops.indent("a", 0, 0, use_spaces=False)[0], "\ta")
        self.assertEqual(ops.indent("a", 0, 0, tab_width=2)[0], "  a")

    def test_outdent_partial_and_tab(self):
        self.assertEqual(ops.outdent("  a", 0, 0)[0], "a")
        self.assertEqual(ops.outdent("\ta", 0, 0)[0], "a")
        self.assertEqual(ops.outdent("a", 0, 0)[0], "a")

    def test_indent_skips_blank_lines(self):
        self.assertEqual(ops.indent("a\n\nb", 0, 4)[0], "    a\n\n    b")

    def test_selection_stays_in_bounds(self):
        out, s, e = ops.indent("abc", 1, 2)
        self.assertTrue(0 <= s <= e <= len(out))


class LineOpsTests(unittest.TestCase):
    def test_duplicate_line(self):
        out, s, _ = ops.duplicate_line("a\nb\nc", 2, 2)
        self.assertEqual(out, "a\nb\nb\nc")
        self.assertEqual(s, 4)

    def test_delete_middle_first_last_only(self):
        self.assertEqual(ops.delete_line("a\nb\nc", 2, 2)[0], "a\nc")
        self.assertEqual(ops.delete_line("a\nb\nc", 0, 0)[0], "b\nc")
        self.assertEqual(ops.delete_line("a\nb\nc", 4, 4)[0], "a\nb")
        self.assertEqual(ops.delete_line("only", 1, 1)[0], "")

    def test_delete_multiple_selected_lines(self):
        self.assertEqual(ops.delete_line("a\nb\nc\nd", 2, 5)[0], "a\nd")

    def test_move_lines(self):
        self.assertEqual(ops.move_lines("a\nb\nc", 2, 2, -1)[0], "b\na\nc")
        self.assertEqual(ops.move_lines("a\nb\nc", 2, 2, 1)[0], "a\nc\nb")
        self.assertEqual(ops.move_lines("a\nb", 0, 0, -1)[0], "a\nb")
        self.assertEqual(ops.move_lines("a\nb", 2, 2, 1)[0], "a\nb")

    def test_select_all_and_clamping(self):
        self.assertEqual(ops.select_all("abc"), (0, 3))
        self.assertEqual(ops.duplicate_line("x", -5, 99)[0], "x\nx")


class AutoIndentTests(unittest.TestCase):
    def test_keep_indent(self):
        self.assertEqual(ops.auto_indent("    x = 1"), "    ")

    def test_colon_adds_level(self):
        self.assertEqual(ops.auto_indent("def f():"), "    ")
        self.assertEqual(ops.auto_indent("    if x:"), "        ")
        self.assertEqual(ops.auto_indent("if x:  # comment"), "    ")

    def test_colon_inside_string_or_comment_ignored(self):
        self.assertEqual(ops.auto_indent("x = 'a:'"), "")
        self.assertEqual(ops.auto_indent("x = 1  # note:"), "")

    def test_open_bracket(self):
        self.assertEqual(ops.auto_indent("foo(", tab_width=2), "  ")

    def test_dedent_after_return_and_friends(self):
        self.assertEqual(ops.auto_indent("        return x"), "    ")
        self.assertEqual(ops.auto_indent("    pass"), "")
        self.assertEqual(ops.auto_indent("    raise ValueError('x')"), "")

    def test_tabs(self):
        self.assertEqual(ops.auto_indent("def f():", use_spaces=False), "\t")


class BracketTests(unittest.TestCase):
    def test_pairs_both_directions(self):
        self.assertEqual(ops.match_bracket("f(a[1])", 1), (1, 6))
        self.assertEqual(ops.match_bracket("f(a[1])", 7), (6, 1))
        self.assertEqual(ops.match_bracket("f(a[1])", 3), (3, 5))

    def test_brackets_in_strings_and_comments_ignored(self):
        text = "x = (')' + 1)  # )\n"
        self.assertEqual(ops.match_bracket(text, 4), (4, 12))

    def test_triple_quoted_string(self):
        text = 'a = ("""(\n""")'
        self.assertEqual(ops.match_bracket(text, 4), (4, len(text) - 1))

    def test_unbalanced_returns_none(self):
        self.assertIsNone(ops.match_bracket("f(", 1))
        self.assertIsNone(ops.match_bracket("abc", 1))

    def test_mismatched_types_not_paired(self):
        self.assertIsNone(ops.match_bracket("(]", 0))

    def test_huge_text_skipped(self):
        self.assertIsNone(ops.match_bracket("(" * 10 + ")" * 10, 0, max_chars=5))


class SearchTests(unittest.TestCase):
    TEXT = "foo Foo foobar\nfoo"

    def test_case_insensitive_default(self):
        self.assertEqual(len(ops.find_all(self.TEXT, "foo")), 4)

    def test_case_sensitive_and_whole_word(self):
        self.assertEqual(len(ops.find_all(self.TEXT, "foo", case_sensitive=True)), 3)
        self.assertEqual(len(ops.find_all(self.TEXT, "foo", whole_word=True)), 3)

    def test_regex(self):
        self.assertEqual(ops.find_all("a1 b22", r"\d+", regex=True), [(1, 2), (4, 6)])

    def test_bad_regex_raises_value_error(self):
        with self.assertRaises(ValueError):
            ops.find_all("x", "(", regex=True)
        with self.assertRaises(ValueError):
            ops.find_all("x", "")

    def test_find_next_prev_and_wrap(self):
        self.assertEqual(ops.find_next(self.TEXT, "foo", 1), (4, 7))
        self.assertEqual(ops.find_next(self.TEXT, "foo", 100), (0, 3))
        self.assertIsNone(ops.find_next(self.TEXT, "foo", 100, wrap=False))
        self.assertEqual(ops.find_next(self.TEXT, "foo", 4, forward=False), (0, 3))
        self.assertEqual(ops.find_next(self.TEXT, "foo", 0, forward=False), (15, 18))
        self.assertIsNone(ops.find_next(self.TEXT, "zzz", 0))

    def test_replace_next(self):
        text, pos, ok = ops.replace_next("a a a", "a", "bb", 2)
        self.assertEqual((text, pos, ok), ("a bb a", 4, True))
        self.assertFalse(ops.replace_next("abc", "z", "y", 0)[2])

    def test_replace_all_literal_does_not_interpret_backslashes(self):
        out, n = ops.replace_all("a.b a.b", "a.b", r"\1")
        self.assertEqual((out, n), (r"\1 \1", 2))

    def test_replace_all_regex_groups(self):
        out, n = ops.replace_all("x1 y2", r"([a-z])(\d)", r"\2\1", regex=True)
        self.assertEqual((out, n), ("1x 2y", 2))

    def test_replace_bad_group_raises(self):
        with self.assertRaises(ValueError):
            ops.replace_all("a", "a", r"\5", regex=True)

    def test_positions(self):
        text = "ab\ncd\nef"
        self.assertEqual(ops.goto_line(text, 2), 3)
        self.assertEqual(ops.goto_line(text, 99), 6)
        self.assertEqual(ops.goto_line(text, 0), 0)
        self.assertEqual(ops.line_col(text, 4), (2, 1))
        self.assertEqual(ops.line_col(text, 999), (3, 2))


class DiagnosticsTests(unittest.TestCase):
    def test_valid_code(self):
        self.assertEqual(diagnostics.check_syntax("x = 1\n"), [])

    def test_syntax_error_location(self):
        (err,) = diagnostics.check_syntax("x = 1\ndef f(:\n    pass\n")
        self.assertEqual(err["line"], 2)
        self.assertEqual(err["severity"], "error")
        self.assertTrue(err["message"])

    def test_indentation_error(self):
        (err,) = diagnostics.check_syntax("def f():\nreturn 1\n")
        self.assertEqual(err["line"], 2)

    def test_null_bytes(self):
        self.assertEqual(len(diagnostics.check_syntax("x = 1\x00")), 1)

    def test_huge_file_skipped(self):
        self.assertEqual(diagnostics.check_syntax("(" * (diagnostics.MAX_CHARS + 1)), [])


class CompletionTests(unittest.TestCase):
    def labels(self, text, cursor=None):
        res = completion.suggest(text, len(text) if cursor is None else cursor)
        return [i["label"] for i in res["items"]], res

    def test_pri_suggests_print(self):
        labels, res = self.labels("pri")
        self.assertEqual(res["prefix"], "pri")
        self.assertIn("print()", labels)
        self.assertEqual(labels[0], "print()")

    def test_buffer_names_rank_first(self):
        labels, _ = self.labels("def printer(): pass\npri")
        self.assertEqual(labels[0], "printer")

    def test_keywords(self):
        labels, _ = self.labels("whi")
        self.assertIn("while", labels)

    def test_exact_token_not_suggested_alone(self):
        labels, _ = self.labels("zzqq")
        self.assertEqual(labels, [])

    def test_no_prefix_no_suggestions(self):
        self.assertEqual(self.labels("x = ")[0], [])

    def test_comment_context_disabled(self):
        self.assertEqual(self.labels("# pri")[0], [])

    def test_module_members(self):
        labels, res = self.labels("import os\nos.pa")
        self.assertEqual(res["prefix"], "pa")
        self.assertIn("path", [i["insert"] for i in res["items"]])

    def test_module_alias(self):
        labels, _ = self.labels("import json as j\nj.dum")
        self.assertIn("dumps()", labels)

    def test_unknown_or_blocked_module_gives_nothing(self):
        self.assertEqual(self.labels("import antigravity\nantigravity.")[0], [])
        self.assertEqual(self.labels("import notamodule\nnotamodule.x")[0], [])

    def test_self_attributes(self):
        text = "class A:\n    def f(self):\n        self.count = 1\n        self.co"
        _, res = self.labels(text)
        self.assertIn("count", [i["insert"] for i in res["items"]])

    def test_limit(self):
        self.assertLessEqual(len(completion.suggest("s", 1, limit=3)["items"]), 3)


if __name__ == "__main__":
    unittest.main()
