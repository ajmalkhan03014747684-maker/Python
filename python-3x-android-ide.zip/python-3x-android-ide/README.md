# Python 3.x — on-device Python IDE for Android

Kotlin + Jetpack Compose UI with CPython embedded through [Chaquopy](https://chaquo.com/chaquopy/).
Original branding, code and assets.

## Status: milestone 1 — Core IDE

| Area | State |
|---|---|
| Projects (create/rename/duplicate/delete→recoverable, zip import/export) | Implemented |
| File tree, search, copy/cut/paste, favorites, trash | Implemented |
| Editor (highlighting, line numbers, autocomplete, find/replace, undo/redo, bracket match, syntax errors) | Implemented |
| Autosave, version history, crash recovery | Implemented |
| Run / stop / restart, stdin, tracebacks, exit code, timing | Implemented |
| Sandboxed terminal | Implemented (`pip install` is intentionally refused) |
| Python backend tests | 255 passing (`python3 -m unittest discover -s tests -t .`) |
| **Android build** | **Written but not yet compiled or run by the author** — see below |
| Package manager, debugger, OpenCV Studio, hidden local admin/ad settings | Implemented (Kotlin only compiled by CI) |
| Two apps: IDE (Python 3.12) + Packs companion (Python 3.10: OpenCV, SciPy, scikit-learn) | Implemented, first build pending |
| GitHub (clone/push/pull), AI assistant (bring your own key), AdMob ads with rewarded unlock | Implemented, first build pending |
| Supabase backend, accounts, cloud sync | Not built yet (last milestone) |

## Build
1. Install Android Studio (JDK 17, Android SDK 35).
2. Open `android/`, let Gradle sync (Chaquopy and Compose are downloaded from Maven).
3. If the Gradle wrapper is missing, run `gradle wrapper` once inside `android/`.
4. Build `:packs:assembleFast`, copy its APK to `app/src/main/assets/packs/python3x-packs.apk`, then `:app:assembleFast` (see docs/android-build.md; the CI workflow does this).

Because the first compile has not happened yet, expect to fix a few Kotlin/Compose compile errors on first sync.

## Test
```
python3 -m unittest discover -s tests -t .      # Python backend, no Android needed
cd android && gradle testDebugUnitTest          # Kotlin pure-logic tests
```

See `docs/` for architecture, runtime, security, privacy and roadmap.
